import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersModule } from './users/users.module';
import { MenuModule } from './CMS/menu/menu.module';
import { PatentScrollerModule } from './CMS/patent-scroller/patent-scroller.module';
import { AppController } from './app.controller';

import { DatabaseConfig } from './common/constants/db.configuration';
import { LoggerModule } from './common/helpers/logger/Logger.Module';
import GetWinstonConfig from './common/helpers/logger/WinstonConfig';
import { MailService } from './common/helpers/mail/mail.service';
import { MailerModule } from '@nestjs-modules/mailer';
import { HandlebarsAdapter } from '@nestjs-modules/mailer/dist/adapters/handlebars.adapter';
import { join } from 'path';
import { LogoScrollerModule } from './CMS/logo-scroller/logo-scroller.module';
import { NewsModule } from './CMS/news/news.module';
import { BlogModule } from './CMS/blog/blog.module';
import { BlogCategoryModule } from './CMS/blog-category/blog-category.module';
import { FrontpageContentModule } from './CMS/frontpage-content/frontpage-content.module';
import { HomepageSliderModule } from './CMS/homepage-slider/homepage-slider.module';
import { CaseStudyModule } from './CMS/case-study/case-study.module';
import { HomepageBackgroundImageModule } from './CMS/homepage-background-image/homepage-background-image.module';
import { CommonFooterModule } from './CMS/common-footer/common-footer.module';
import { OurFirmModule } from './our-firm/our-firm.module';
import { CategoryModule } from './category/category.module';

import { HeaderModule } from './CMS/header/header.module';
import { FooterModule } from './CMS/footer/footer.module';
import { PagecontentModule } from './CMS/pagecontent/pagecontent.module';
import { SettingModule } from './CMS/setting/setting.module';
import { PageModule } from './CMS/page/page.module';
import { SocialModule } from './CMS/social/social.module';
import { GroupMenuModule } from './CMS/group-menu/group-menu.module';
import { OurPeopleModule } from './CMS/our-people/our-people.module';
import { FooterLogoScrollerModule } from './CMS/footer-logo-scroller/footer-logo-scroller.module';
import { ProductModule } from './CMS/product/product.module';

import { MarketingModule } from './CMS/marketing/marketing.module';
import { ReputationModule } from './CMS/reputation/reputation.module';
import { CartModule } from './CMS/cart/cart.module';
import { OrderModule } from './CMS/order/order.module';
import { OrderDetailModule } from './CMS/order-detail/order-detail.module';
import { ProductCategoryModule } from './CMS/product-category/product-category.module';
import { ProductCategoryMatrixModule } from './CMS/product-category-matrix/product-category-matrix.module';
import { ColumnDetailModule } from './CMS/manage-columns/column-detail/column-detail.module';
import { CasesModule } from './CMS/cases/cases.module';
import { FolderModule } from './CMS/folder/folder.module';
import { CaseAssignModule } from './CMS/case-assign/case-assign.module';
import { CaseDeliveryDocsModule } from './CMS/case-delivery-docs/case-delivery-docs.module';
import { RoleModule } from './CMS/role/role.module';
import { EmployeeModule } from './CMS/employee/employee.module';
import { ClientModule } from './CMS/client/client.module';
import { CaseFileModule } from './CMS/case-file/case-file.module';
import { ManageInvoiceModule } from './CMS/manage-invoice/manage-invoice.module';
import { ColumnPermissionModule } from './CMS/column-permission/column-permission.module';
import { MenuPermissionModule } from './CMS/menu-permission/menu-permission.module';
import { FolderPermissionModule } from './CMS/folder-permission/folder-permission.module';
import { OrderPriorityClaimsModule } from './CMS/order-priority-claims/order-priority-claims.module';
import { OrderInventorsModule } from './CMS/order-inventors/order-inventors.module';
import { ManagerServiceFormModule } from './CMS/manage-service-form/manager-service-form/manager-service-form.module';
import { ManageServiceFormDetailModule } from './CMS/manage-service-form/manage-service-form-detail/manage-service-form-detail.module';
import { ProductServiceFormModule } from './CMS/product-service-form/product-service-form.module';
import { ProductPriceLevelModule } from './CMS/product-price-level/product-price-level.module';
import { ProductOrderDetailFormModule } from './CMS/product-order-detail-form/product-order-detail-form.module';
import { NotificationModule } from './CMS/notification/notification.module';
import { ScheduleModule } from '@nestjs/schedule';
import { Order } from './CMS/order/entities/order.entity';
import { Notification } from 'src/CMS/notification/entities/notification.entity';
import { TaskInstructionModule } from './CMS/task-instruction/task-instruction.module';
import { EventLogModule } from './CMS/event-log/event-log.module';
import { ClientUploadsInstructionModule } from './CMS/client-uploads-instruction/client-uploads-instruction.module';
import { ProductPriceLevelDecayModule } from './CMS/product-price-level-decay/product-price-level-decay.module';
import { OrderInventorDocumentModule } from './CMS/order-inventor-document/order-inventor-document.module';
import { FinalIdInstructionsModule } from './CMS/final-id-instructions/final-id-instructions.module';
import { StatusLookupModule } from './CMS/status-lookup/status-lookup.module';
import { ShoppingCartInstructionModule } from './CMS/shopping-cart-instruction/shopping-cart-instruction.module';
import { Setting } from './CMS/setting/entities/setting.entity';
import { CaseAssociationModule } from './CMS/case-association/case-association.module';
import { OrderPaymentModule } from './CMS/order-payment/order-payment.module';
import { OrderAssigneeDocumentModule } from './CMS/order-assignee-document/order-assignee-document.module';
import { ManageServiceFormGroupNameModule } from './CMS/manage-service-form/manage-service-form-group-name/manage-service-form-group-name.module';
import { CaseLegacyModule } from './CMS/case-legacy/case-legacy.module';
import { GlobalInstructionModule } from './CMS/global-instruction/global-instruction.module';
import { OrderDetailService } from './CMS/order-detail/order-detail.service';
import { OrderDetail } from './CMS/order-detail/entities/order-detail.entity';
import { configuration } from './config/configuration';
import { PaymentInstructionModule } from './CMS/payment-instruction/payment-instruction.module';
import { ClientBillingContactModule } from './CMS/client-billing-contact/client-billing-contact.module';
import { ProductBillingCodeModule } from './CMS/product-billing-code/product-billing-code.module';
import { OrderExtraModule } from './CMS/order-extra/order-extra.module';
import { OrderPaymentAdjustmentModule } from './CMS/order-payment-adjustment/order-payment-adjustment.module';
import { EmailTemplateModule } from './CMS/email-template/email-template.module';
import { PdfInvoiceModule } from './CMS/pdf-invoice/pdf-invoice.module';


@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: `${process.cwd()}/src/config/${process.env.NODE_ENV}.env`,
      load: [configuration],
      isGlobal: true,
    }),
    TypeOrmModule.forFeature([Notification, Order,Setting]),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService) => config.get('database'),
      inject: [ConfigService], 
    }),
    MailerModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService) => config.get('mail'),
      inject: [ConfigService],
    }),
    LoggerModule.forRoot(GetWinstonConfig()),
    AuthModule,
    UsersModule,
    MenuModule,
    PatentScrollerModule,
    LogoScrollerModule,
    NewsModule,
    BlogModule,
    BlogCategoryModule,
    FrontpageContentModule,
    HomepageSliderModule,
    CaseStudyModule,
    HomepageBackgroundImageModule,
    CommonFooterModule,
    OurFirmModule,
    CategoryModule,
    PageModule,
    HeaderModule,
    FooterModule,
    PagecontentModule,
    SettingModule,
    SocialModule,
    GroupMenuModule,
    OurPeopleModule,
    FooterLogoScrollerModule,
    ClientModule,
    ProductModule,
    MarketingModule,
    ReputationModule,
    LogoScrollerModule,
    CartModule,
    ProductCategoryModule,
    OrderModule,
    OrderDetailModule,
    ProductCategoryModule,
    ProductCategoryMatrixModule,
    ColumnDetailModule,
    CasesModule,
    CaseAssignModule,
    CaseDeliveryDocsModule,
    FolderModule,
    RoleModule,
    EmployeeModule,
    CaseFileModule,
    ManageInvoiceModule,
    ColumnPermissionModule,
    MenuPermissionModule,
    FolderPermissionModule,
    OrderPriorityClaimsModule,
    OrderInventorsModule,
    ManagerServiceFormModule,
    ManageServiceFormDetailModule,
    ProductServiceFormModule,
    ProductPriceLevelModule,
    ProductOrderDetailFormModule,
    NotificationModule,
    TaskInstructionModule,
    ScheduleModule.forRoot(),
    EventLogModule,
    ClientUploadsInstructionModule,
    ProductPriceLevelDecayModule,
    OrderInventorDocumentModule,
    FinalIdInstructionsModule,
    StatusLookupModule,
    ShoppingCartInstructionModule,
    CaseAssociationModule,
    OrderPaymentModule,
    OrderAssigneeDocumentModule,
    ManageServiceFormGroupNameModule,
    CaseLegacyModule,
    GlobalInstructionModule,
    PaymentInstructionModule,
    ClientBillingContactModule,
    ProductBillingCodeModule,
    OrderExtraModule,
    OrderPaymentAdjustmentModule,
    EmailTemplateModule,
    PdfInvoiceModule


  ],
  controllers: [AppController],
  providers: [AppService, MailService],
  exports: [MailService]
})
export class AppModule { }
