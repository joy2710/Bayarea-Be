import { Module } from '@nestjs/common';
import { BlogService } from './blog.service';
import { BlogController } from './blog.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Blog } from './entities/blog.entity';
import { BlogCategoryModule } from '../blog-category/blog-category.module';
import { BlogCategory } from '../blog-category/entities/blog-category.entity';
import { BlogCategoryService } from '../blog-category/blog-category.service';

@Module({
  imports:[
    TypeOrmModule.forFeature([Blog, BlogCategory]),
    BlogCategoryModule
  ],
  controllers: [BlogController],
  providers: [BlogService, BlogCategoryService]
})
export class BlogModule {}
