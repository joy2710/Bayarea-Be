import { Controller, Get, Post, Body, Param, Delete, UseGuards, UseInterceptors, UploadedFile } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { Observable, of } from 'rxjs';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { BlogParentRoute, BlogRoutes } from './blog.http.routes';

import { BlogService } from './blog.service';
import { CreateBlogDto } from './dto/request/create-blog.dto';
import { UpdateBlogDto } from './dto/request/update-blog.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Blog')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: BlogParentRoute })
// @Public()
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class BlogController {
  constructor(private readonly blogService: BlogService) { }

  @Post(BlogRoutes.create)
  createBlog(@Body() body: CreateBlogDto) {
    return this.blogService.create(body);
  }

  @Public()
  @Get(BlogRoutes.view_all)
  findAllBlog() {
    return this.blogService.findAll();
  }

  @Public()
  @Get(BlogRoutes.view_one)
  findBlogById(@Param('blogId') id: string) {
    return this.blogService.findOne(+id);
  }

  @Public()
  @Get(BlogRoutes.view_by_category)
  findBlogByIdTag(@Param('categoryId') id:number){
    return this.blogService.findBlogId(id);
  }                                                                                                                                                                  

  @Post(BlogRoutes.update)
  updateBlogById(@Param('blogId') id: string, @Body() body: UpdateBlogDto) {
    return this.blogService.update(+id, body);
  }

  @Delete(BlogRoutes.delete)
  removeBlogById(@Param('blogId') id: string) {
    return this.blogService.remove(+id);
  }

  @Public()
  @Post(BlogRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {
    return of({ imagePath: `${file.destination}/${file.filename}` })
  }
}
