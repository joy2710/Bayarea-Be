import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator"
import { BlogStatus } from "../../entities/status.enum";

export class CreateBlogDto {
    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;

    @ApiProperty({ default: BlogStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(BlogStatus)
    status: BlogStatus;

    @ApiProperty()
    @IsOptional()
    imageUrl: string;

    @ApiProperty()
    @IsOptional()
    postingDate: string;

    @ApiProperty({example: [0], isArray: true})
    @IsNotEmpty()
    categoryIds: number[];


    @ApiProperty()
    @IsOptional()
    pageTitleUrl: string;
}

