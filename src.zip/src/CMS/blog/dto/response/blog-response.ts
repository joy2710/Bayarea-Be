import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { BlogStatus } from '../../entities/status.enum';

export class BlogResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ example: BlogStatus })
  @Expose()
  status: BlogStatus;

  
  @ApiProperty()
  @Expose()
  postingDate: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

  @ApiProperty()
  @Expose()
  imageUrl: string; 

  @ApiProperty()
  @Expose()
  pageTitleUrl: string;
}
