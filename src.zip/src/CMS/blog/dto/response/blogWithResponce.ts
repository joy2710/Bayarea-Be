import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BlogResponse } from './blog-response';

export class BlogWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: BlogResponse | BlogResponse[];

  constructor(message: string, data: BlogResponse | BlogResponse[]) {
    this.data = data;
    this.message = message;
  }
}
