export const BlogParentRoute = 'blog';

export const BlogRoutes = {
  create: '',
  update: 'update/:blogId',
  delete: ':blogId',
  view_one: ':blogId',
  view_all: '',
  upload_image: 'uploadImage',
  view_by_category:'blogCat/:categoryId'
};
