import {
  HttpException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateBlogDto } from './dto/request/create-blog.dto';
import { UpdateBlogDto } from './dto/request/update-blog.dto';
import { Blog } from './entities/blog.entity';
import { BlogWithMessageResponse } from './dto/response/blogWithResponce';
import { CreateBlogCategoryDto } from '../blog-category/dto/request/create-blog-category.dto';
import { BlogCategoryService } from '../blog-category/blog-category.service';
import { NotFoundException } from 'src/common/helpers/exception/NotFoundException';

@Injectable()
export class BlogService {
  constructor(
    @InjectRepository(Blog) private blogRepository: Repository<Blog>,
    private readonly blogCategoryService: BlogCategoryService,
  ) {}

  async create(request: CreateBlogDto): Promise<BlogWithMessageResponse> {
    request.pageTitleUrl = request.title.replace(/[^a-zA-Z0-9]/g, "_")
    const result = await this.blogRepository.save(request);
    if (result) {
      const res = [];
      if (result.categoryIds.length > 0) {
        for (let i = 0; i < result.categoryIds.length; i++) {
          const categoryId = result.categoryIds[i];
          const createBlogCategoryDto: CreateBlogCategoryDto = {
            blogId: result.id,
            categoryId: categoryId,
          };
          const data = await this.blogCategoryService.create(
            createBlogCategoryDto,
          );
          res.push(data);
        }
      }
      return {
        message: `${Messages.Resource.Created} : Blog`,
        data: result,
      };
    }
  }
  async findAll(): Promise<BlogWithMessageResponse> {
    const result = await this.blogRepository
      .createQueryBuilder('blog')
      .leftJoinAndSelect('blog.blogCategory', 'blogCategory')
      .leftJoinAndSelect('blogCategory.category', 'category')
      .getMany();

    if (result) {
      return {
        message: `${Messages.Resource.Found} : Blog`,
        data: result,
      };
    }
  }

  async findBlogId(categoryId: number) {
    let blogIds = [];
    try{
      const blogIdByCategory = await this.blogRepository
      .createQueryBuilder('blog')
      .leftJoinAndSelect('blog.blogCategory', 'blogCategory')
      .where(`blogCategory.categoryId = '${categoryId}'`)
      .getMany();

    blogIdByCategory.map(async (value: any) => {
      value.blogCategory.map(async (z: any) => {
        blogIds.push(z.blogId);
      });
    });
    
    if(blogIdByCategory.length == 0) {
      throw new HttpException(`${Messages.Resource.NotFound} : Blog`, HttpStatus.NOT_FOUND);
    }
    const blogs = await this.blogRepository
      .createQueryBuilder('blog')
      .leftJoinAndSelect('blog.blogCategory', 'blogCategory')
      .leftJoinAndSelect('blogCategory.category', 'category')
      .where('blog.id IN (:...ids)', { ids: blogIds })
      .getMany();
    if(blogs) {
      return {
        message: `${Messages.Resource.Found} : Blog`,
        data: blogs,
      };
    }
    }
    catch (error) {
      throw error;
    }
  }

  async findOne(blogId: number): Promise<BlogWithMessageResponse> {
    try {
      const result = await this.blogRepository
        .createQueryBuilder('blog')
        .leftJoinAndSelect('blog.blogCategory', 'blogCategory')
        .where('blog.id = :id', { id: blogId })
        .leftJoinAndSelect('blogCategory.category', 'category')
        .getMany();
      if (!result)
        throw new HttpException(
          `${Messages.Resource.NotFound}: Blog`,
          HttpStatus.NOT_FOUND,
        );
      return {
        message: `${Messages.Resource.Found} : Blog`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }
  async getBlogByCategoryId(categoryId: number) {
    const res = await this.blogRepository.find({
      relations: ['blog', 'category'],
      where: {
        categoryId: categoryId,
      },
    });
    return res;
  }

  async update(
    blogId: number,
    request: UpdateBlogDto,
  ): Promise<BlogWithMessageResponse> {
    const result = await this.blogRepository.update(blogId, {
      title: request.title,
      description: request.description,
      status: request.status,
      imageUrl: request.imageUrl,
      postingDate: request.postingDate,
      updatedDate: new Date(),
      pageTitleUrl : request.title.replace(/[^a-zA-Z0-9]/g, "_"),
    });
    if (!result) {
      throw new HttpException(
        `${Messages.Resource.NotFound} : Blog`,
        HttpStatus.NOT_FOUND,
      );
    }
    const response = await this.blogRepository.findOne(blogId);
    await this.blogCategoryService.removeByBlogId(blogId);
    if (result) {
      const res = [];
      if (request.categoryIds.length > 0) {
        for (let i = 0; i < request.categoryIds.length; i++) {
          const categoryId = request.categoryIds[i];
          const createBlogCategoryDto: CreateBlogCategoryDto = {
            blogId: response.id,
            categoryId: categoryId,
          };
          const data = await this.blogCategoryService.create(
            createBlogCategoryDto,
          );
          res.push(data);
        }
      }
    }
    return {
      message: `${Messages.Resource.Updated} : Blog`,
      data: response,
    };
  }

  async remove(blogId: number): Promise<BlogWithMessageResponse> {
    try {
      const deleteBlog = await this.blogRepository.delete(blogId);
      if (deleteBlog.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Blog`,
        };
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
