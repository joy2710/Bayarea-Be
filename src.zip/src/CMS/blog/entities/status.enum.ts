export enum BlogStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}