import { BlogCategory } from "src/CMS/blog-category/entities/blog-category.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { BlogStatus } from "./status.enum";

@Entity()
export class Blog {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column({type: 'longtext'})
    description: string;

    @Column()
    postingDate: string;

    // @Column()
    // categoryId: number;

    @Column({ default: BlogStatus.INACTIVE })
    status: BlogStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column()
    imageUrl: string;

    //relation blogcategory and blog
    @OneToMany(() => BlogCategory, (blogCategory: BlogCategory) => blogCategory.blog)
    blogCategory: BlogCategory;

    // @OneToMany(() => Category, (category: Category) => category.blogCategory)
    // category: Category;

    @Column()
    pageTitleUrl: string;
}