import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateClientUploadsInstructionDto } from './dto/request/create-client-uploads-instruction.dto';
import { UpdateClientUploadsInstructionDto } from './dto/request/update-client-uploads-instruction.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { clientUploadsInstructionWithMessageResponse } from './dto/response/clientUploadInstructionContentWithResponce';
import { ClientUploadsInstruction } from './entities/client-uploads-instruction.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ClientUploadsInstructionService {
  constructor(
    @InjectRepository(ClientUploadsInstruction) private taskInstructionResponse: Repository<ClientUploadsInstruction>,
  ) { }


  async create(request: CreateClientUploadsInstructionDto): Promise<clientUploadsInstructionWithMessageResponse> {
    try {
      const taskInstruction = await this.taskInstructionResponse.create(request);
      const result = await this.taskInstructionResponse.save(taskInstruction);

        return {
          message: `${Messages.Resource.Created}:Client-Uploads-Instruction`,
          data: result
        }
      
    } catch (error) {
      if (error.code == 'ER_DUP_ENTRY') {
        throw new HttpException(
          error.message,
          HttpStatus.BAD_REQUEST,
        );
      }
    }
  }

  async findAll(): Promise<clientUploadsInstructionWithMessageResponse> {
    const result = await this.taskInstructionResponse.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Client-Uploads-Instruction`,
        data: result
      }
    }
  }

  async findOne(clientUploadInstructionId: number) {
    try {
      const result = await this.taskInstructionResponse.findOne(
        {
          where:
            { id: clientUploadInstructionId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Client-Uploads-Instruction`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Client-Uploads-Instruction`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(clientUploadInstructionId: number, request: UpdateClientUploadsInstructionDto): Promise<clientUploadsInstructionWithMessageResponse> {
    const data = await this.taskInstructionResponse.findOne(clientUploadInstructionId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound}: Client-Uploads-Instruction`, HttpStatus.NOT_FOUND);
    }
    await this.taskInstructionResponse.update(clientUploadInstructionId, request);

    return {
      message: `${Messages.Resource.Updated} : Client-Uploads-Instruction`,
    }
  }

  async remove(clientUploadInstructionId: number) {
    try {
      const deleteTaskInstruction = await this.taskInstructionResponse.delete(clientUploadInstructionId);
        if (deleteTaskInstruction.affected > 0) {
          return {
            message: `${Messages.Resource.Deleted} : Client-Uploads-Instruction`
          }
        }
      
    } catch (error) {
      throw new InternalServerErrorException(error.message);

    }
  }
}
