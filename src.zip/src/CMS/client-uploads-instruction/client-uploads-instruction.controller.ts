import { Controller, Get, Post, Body, Param, Delete, UseGuards } from '@nestjs/common';
import { ClientUploadsInstructionService } from './client-uploads-instruction.service';
import { CreateClientUploadsInstructionDto } from './dto/request/create-client-uploads-instruction.dto';
import { UpdateClientUploadsInstructionDto } from './dto/request/update-client-uploads-instruction.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ClientUploadsInstructionRoute, ClientUploadsInstuctionRoutes } from './client-uploads-instruction.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Client-Uploads-Instruction')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:ClientUploadsInstructionRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
export class ClientUploadsInstructionController {
  constructor(private readonly clientUploadsInstructionService: ClientUploadsInstructionService) {}

  @Post(ClientUploadsInstuctionRoutes.create)
  create(@Body() createClientUploadsInstructionDto: CreateClientUploadsInstructionDto) {
    return this.clientUploadsInstructionService.create(createClientUploadsInstructionDto);
  }

  @Get(ClientUploadsInstuctionRoutes.view_all)
  findAll() {
    return this.clientUploadsInstructionService.findAll();
  }

  @Get(ClientUploadsInstuctionRoutes.view_one)
  findOne(@Param('clientUploadInstructionId') id: string) {
    return this.clientUploadsInstructionService.findOne(+id);
  }

  @Post(ClientUploadsInstuctionRoutes.update)
  update(@Param('clientUploadInstructionId') id: string, @Body() updateClientUploadsInstructionDto: UpdateClientUploadsInstructionDto) {
    return this.clientUploadsInstructionService.update(+id, updateClientUploadsInstructionDto);
  }

  @Delete(ClientUploadsInstuctionRoutes.delete)
  remove(@Param('clientUploadInstructionId') id: string) {
    return this.clientUploadsInstructionService.remove(+id);
  }
}
