import { Module } from '@nestjs/common';
import { ClientUploadsInstructionService } from './client-uploads-instruction.service';
import { ClientUploadsInstructionController } from './client-uploads-instruction.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ClientUploadsInstruction } from './entities/client-uploads-instruction.entity';

@Module({
  imports:[TypeOrmModule.forFeature([ClientUploadsInstruction])],
  controllers: [ClientUploadsInstructionController],
  providers: [ClientUploadsInstructionService]
})
export class ClientUploadsInstructionModule {}
