import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import {  ClientUploadInstructionType } from "./upload-field-name.enum";
import {  ClientUploadInstructionStatus } from "./status.enum";


@Entity()
export class ClientUploadsInstruction {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({type: 'longtext'})
    content: string;

    @Column({ default: ClientUploadInstructionType.CASE, unique: true })
    typeOfContent: ClientUploadInstructionType;

    @Column({ default: ClientUploadInstructionStatus.INACTIVE })
    status: ClientUploadInstructionStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
}
