export enum ClientUploadInstructionStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}