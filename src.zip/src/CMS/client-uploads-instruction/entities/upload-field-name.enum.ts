export enum ClientUploadInstructionType{
    CASE = 'Case',
    DOC_TYPE = 'Doc Type',
    CHOOSE_FILE = 'Choose file',
    DESCRIPTION = 'Description',
  
}