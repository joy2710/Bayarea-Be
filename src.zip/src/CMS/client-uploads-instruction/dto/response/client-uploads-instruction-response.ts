import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import {  ClientUploadInstructionStatus } from '../../entities/status.enum';
import { ClientUploadInstructionType } from '../../entities/upload-field-name.enum';


export class TaskInstructionResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  content: string;

  @ApiProperty({ example: ClientUploadInstructionType})
  @Expose()
  typeOfContent: ClientUploadInstructionType;

  @ApiProperty({ example: ClientUploadInstructionStatus })
  @Expose()
  status: ClientUploadInstructionStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;
} 
