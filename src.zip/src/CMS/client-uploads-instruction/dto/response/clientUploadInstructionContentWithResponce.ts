import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TaskInstructionResponse } from './client-uploads-instruction-response';


export class clientUploadsInstructionWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: TaskInstructionResponse | TaskInstructionResponse[];

  constructor(message: string, data: TaskInstructionResponse | TaskInstructionResponse[]) {
    this.data = data;
    this.message = message;
  }
}
