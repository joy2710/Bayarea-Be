import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import {  ClientUploadInstructionStatus } from "../../entities/status.enum";
import { ClientUploadInstructionType } from "../../entities/upload-field-name.enum";

export class CreateClientUploadsInstructionDto {
   
    @ApiProperty()
    @IsNotEmpty()
    content: string;

    @ApiProperty({default: ClientUploadInstructionType.CASE})
    @IsNotEmpty()
    @IsEnum(ClientUploadInstructionType)
    typeOfContent: ClientUploadInstructionType;

    @ApiProperty({ default: ClientUploadInstructionStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(ClientUploadInstructionStatus)
    status: ClientUploadInstructionStatus;
}
