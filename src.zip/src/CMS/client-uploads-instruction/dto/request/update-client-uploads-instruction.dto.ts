import { CreateClientUploadsInstructionDto } from './create-client-uploads-instruction.dto';

export class UpdateClientUploadsInstructionDto extends (CreateClientUploadsInstructionDto) {}
