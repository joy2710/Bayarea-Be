import { Test, TestingModule } from '@nestjs/testing';
import { ClientUploadsInstructionController } from './client-uploads-instruction.controller';
import { ClientUploadsInstructionService } from './client-uploads-instruction.service';

describe('ClientUploadsInstructionController', () => {
  let controller: ClientUploadsInstructionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ClientUploadsInstructionController],
      providers: [ClientUploadsInstructionService],
    }).compile();

    controller = module.get<ClientUploadsInstructionController>(ClientUploadsInstructionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
