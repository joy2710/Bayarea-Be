export const ClientUploadsInstructionRoute = 'client-upload-instruction';

export const ClientUploadsInstuctionRoutes = {
  create: '',
  update: 'update/:clientUploadInstructionId',
  delete: ':clientUploadInstructionId',
  view_one: ':clientUploadInstructionId',   
  view_all: '',
};
