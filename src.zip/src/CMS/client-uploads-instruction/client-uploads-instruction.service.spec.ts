import { Test, TestingModule } from '@nestjs/testing';
import { ClientUploadsInstructionService } from './client-uploads-instruction.service';

describe('ClientUploadsInstructionService', () => {
  let service: ClientUploadsInstructionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ClientUploadsInstructionService],
    }).compile();

    service = module.get<ClientUploadsInstructionService>(ClientUploadsInstructionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
