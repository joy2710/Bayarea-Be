import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { MarketingStatus } from '../../entities/status.enum';
export class MarketingResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  imageurl: string;

  @ApiProperty()
  @Expose()
  navigationurl: string;

  @ApiProperty()
  @Expose()
  alttext: string;

  @ApiProperty({ example: MarketingStatus })
  @Expose()
  status: MarketingStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

  @ApiProperty()
  @Expose()
  sequenceNumber: number;
  
}
