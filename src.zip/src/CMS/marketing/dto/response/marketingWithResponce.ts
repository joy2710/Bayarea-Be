import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { MarketingResponse } from './marketing-response';

export class MarketingWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: MarketingResponse | MarketingResponse[];

  constructor(message: string, data: MarketingResponse | MarketingResponse[]) {
    this.data = data;
    this.message = message;
  }
}
