
import { CreateMarketingDto } from './create-marketing.dto';

export class UpdateMarketingDto extends CreateMarketingDto {}
