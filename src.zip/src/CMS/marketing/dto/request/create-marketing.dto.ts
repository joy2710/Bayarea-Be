import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { MarketingStatus } from "../../entities/status.enum";

export class CreateMarketingDto {
    @ApiProperty()
    @IsNotEmpty()
    imageurl: string;

    @ApiProperty()
    @IsNotEmpty()
    navigationurl: string;

    @ApiProperty()
    @IsNotEmpty()
    alttext: string;

    @ApiProperty({ default: MarketingStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(MarketingStatus)
    status: MarketingStatus;

    @ApiProperty()
    @IsNotEmpty()
    sequenceNumber: number;
}
