import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { getConnection, Repository } from 'typeorm';
import { CreateMarketingDto } from './dto/request/create-marketing.dto';
import { UpdateMarketingDto } from './dto/request/update-marketing.dto';
import { MarketingWithMessageResponse } from './dto/response/marketingWithResponce';
import { Marketing } from './entities/marketing.entity';
@Injectable()
export class MarketingService {
  constructor(
    @InjectRepository(Marketing) private MarketingRepository: Repository<Marketing>
  ) { }

  async create(request: CreateMarketingDto): Promise<MarketingWithMessageResponse> {
    const marketing = await this.MarketingRepository.create(request);
    const result = await this.MarketingRepository.save(marketing);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Marketing`,
        data: result
      }
    }
  }

  async findAll(): Promise<MarketingWithMessageResponse> {
    const result = await this.MarketingRepository
    .createQueryBuilder()
    .orderBy('sequenceNumber', "ASC")
    .getMany();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Marketing`,
        data: result
      }
    }
  }

  async findOne(marketingId: number): Promise<MarketingWithMessageResponse> {
    try {
      const result = await this.MarketingRepository.findOne(
        {
          where:
            { id: marketingId }
        }
      );
      if (!result) 
        throw new HttpException(`${Messages.Resource.NotFound}: Logo-scroller`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Marketing`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(marketingId: number, request: UpdateMarketingDto): Promise<MarketingWithMessageResponse> {
    const data = await this.MarketingRepository.findOne(marketingId)
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Marketing`,HttpStatus.NOT_FOUND);
    }
    await this.MarketingRepository.update(marketingId, request);
    return {
      message: `${Messages.Resource.Updated} : Marketing`,     
    }
  }

  async remove(logoScrollerId: number): Promise<MarketingWithMessageResponse> {
    try {
      const deleteLogoScroller = await this.MarketingRepository.delete(logoScrollerId)
      if (deleteLogoScroller.affected > 0) {
        return {
          message:`${Messages.Resource.Deleted} : Marketing`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(Marketing)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Marketing)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Marketing)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(Marketing)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Marketing)
      .set({ sequenceNumber: () => "sequenceNumber - 1" })
      .where('sequenceNumber > :currSequenceNumber AND sequenceNumber <= :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Marketing)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }
}
