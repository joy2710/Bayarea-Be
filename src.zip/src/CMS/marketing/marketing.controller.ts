import { Controller, Get, Post, Body, Patch, Param, Delete, UseInterceptors, UploadedFile, Query, UseGuards } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { Observable, of } from 'rxjs';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { CreateMarketingDto } from './dto/request/create-marketing.dto';
import { UpdateMarketingDto } from './dto/request/update-marketing.dto';
import { MarketingParentRoute, MarketingRoutes } from './marketing.http.routes';
import { MarketingService } from './marketing.service';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Marketing-Logo')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path:MarketingParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

// @Public()
@Controller('marketing')
export class MarketingController {
  constructor(private readonly marketingService: MarketingService) {}

  @Post(MarketingRoutes.create)
  createReputation(@Body() body: CreateMarketingDto) {
    return this.marketingService.create(body);
  }
 
  @Public()
  @Get(MarketingRoutes.view_all)
  findAllReputation() {
    return this.marketingService.findAll();
  }

  @Public()
  @Get(MarketingRoutes.view_one)
  findReputationById(@Param('marketingId') id: string) {
    return this.marketingService.findOne(+id);
  }

  @Post(MarketingRoutes.update)
  updateReputationById(@Param('marketingId') id: string, @Body() body: UpdateMarketingDto) {
    return this.marketingService.update(+id, body);
  }

  @Delete(MarketingRoutes.delete)
  removeReputationById(@Param('marketingId') id: string) {
    return this.marketingService.remove(+id);
  }

  @Public()
  @Post(MarketingRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {

    return of({ imagePath: `${file.destination}/${file.filename}` })
  }

  @Public()
  @Post(MarketingRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.marketingService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }
}
