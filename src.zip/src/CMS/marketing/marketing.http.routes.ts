export const MarketingParentRoute = 'marketing';

export const MarketingRoutes = {
  create: '',
  update: 'update/:marketingId',
  delete: ':marketingId',
  view_one: ':marketingId',
  view_all: '',
  upload_image: 'image-upload',
  updateDragAndDrop: 'dragandDrop'
};
