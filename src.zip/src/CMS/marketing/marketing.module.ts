import { Module } from '@nestjs/common';
import { MarketingService } from './marketing.service';
import { MarketingController } from './marketing.controller';
import { Marketing } from './entities/marketing.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports:[TypeOrmModule.forFeature([Marketing])],
  controllers: [MarketingController],
  providers: [MarketingService]
})
export class MarketingModule {}
