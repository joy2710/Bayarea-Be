import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { MarketingStatus } from "./status.enum";

@Entity({ name:'marketing'})
export class Marketing {

    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    imageurl:string;

    @Column()
    navigationurl:string;

    @Column( )
    alttext:string;

    @Column({default:MarketingStatus.INACTIVE})
    status:MarketingStatus;

    @CreateDateColumn({name:'createdDate'})
    createdDate: Date;

    @Column()
    createdBy:number;

    @UpdateDateColumn({name:'updatedDate',nullable:true,default:()=>'null'})
    updatedDate:Date;

    @Column({ nullable:true })
    updatedBy: string;

    @Column()
    sequenceNumber: number;


}
