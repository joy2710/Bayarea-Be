export enum MarketingStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}