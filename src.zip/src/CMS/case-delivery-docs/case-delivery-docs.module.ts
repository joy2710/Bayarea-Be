import { forwardRef, Module } from '@nestjs/common';
import { CaseDeliveryDocsService } from './case-delivery-docs.service';
import { CaseDeliveryDocsController } from './case-delivery-docs.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CaseDeliveryDoc } from './entities/case-delivery-doc.entity';
import { EmployeeService } from '../employee/employee.service';
import { CasesService } from '../cases/cases.service';
import { Cases } from '../cases/entities/cases.entity';
import { Employee } from '../employee/entities/employee.entity';
import { CasesModule } from '../cases/cases.module';
import { EmployeeModule } from '../employee/employee.module';
import { ClientService } from '../client/client.service';
import { CaseAssignService } from '../case-assign/case-assign.service';
import { Client } from '../client/entities/client.entity';
import { Order } from '../order/entities/order.entity';
import { CaseAssign } from '../case-assign/entities/case-assign.entity';
import { TaskInstruction } from '../task-instruction/entities/task-instruction.entity';
import { CaseAssociation } from '../case-association/entities/case-association.entity';
import { OrderPayment } from '../order-payment/entities/order-payment.entity';
import { OrderInventorsService } from '../order-inventors/order-inventors.service';
import { OrderInventor } from '../order-inventors/entities/order-inventor.entity';
import { OrderAssigneeDocumentService } from '../order-assignee-document/order-assignee-document.service';
import { OrderAssigneeDocument } from '../order-assignee-document/entities/order-assignee-document.entity';
import { CaseFileService } from '../case-file/case-file.service';
import { CaseFile } from '../case-file/entities/case-file.entity';
import { Folder } from '../folder/entities/folder.entity';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { ClientModule } from '../client/client.module';
import { ConfigService } from '@nestjs/config';
import { StatusLookupModule } from '../status-lookup/status-lookup.module';

@Module({
  imports: [TypeOrmModule.forFeature([CaseDeliveryDoc,OrderInventor,CaseAssociation,Folder,ProductOrderDetailForm, Employee,Cases, Client, Order,OrderAssigneeDocument,CaseFile, CaseAssign,OrderPayment, TaskInstruction]),ClientModule,EmployeeModule,CasesModule,forwardRef(() => StatusLookupModule)],
  controllers: [CaseDeliveryDocsController],
  providers: [CaseDeliveryDocsService,EmployeeService,CasesService, CaseAssignService,OrderInventorsService,OrderAssigneeDocumentService,ConfigService]
})
export class CaseDeliveryDocsModule {}
