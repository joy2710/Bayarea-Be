import { Test, TestingModule } from '@nestjs/testing';
import { CaseDeliveryDocsService } from './case-delivery-docs.service';

describe('CaseDeliveryDocsService', () => {
  let service: CaseDeliveryDocsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CaseDeliveryDocsService],
    }).compile();

    service = module.get<CaseDeliveryDocsService>(CaseDeliveryDocsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
