import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CasesService } from '../cases/cases.service';
import { EmployeeService } from '../employee/employee.service';
import { CreateCaseDeliveryDocDto } from './dto/request/create-case-delivery-doc.dto';
import { UpdateCaseDeliveryDocDto } from './dto/request/update-case-delivery-doc.dto';
import { CaseDeliveryDocsWithMessageResponse } from './dto/response/caseDeliveryDocsWithResponse';
import { CaseDeliveryDoc } from './entities/case-delivery-doc.entity';

@Injectable()
export class CaseDeliveryDocsService {
  constructor(
    @InjectRepository(CaseDeliveryDoc) private caseDeliveryDocsRepository: Repository<CaseDeliveryDoc>,
    private caseRepository:CasesService,
    private employeeRepository:EmployeeService,
    ) {}
  async create(createCaseDeliveryDocDto: CreateCaseDeliveryDocDto): Promise<CaseDeliveryDocsWithMessageResponse> {
    await this.caseRepository.findOne(createCaseDeliveryDocDto.caseId);
    await this.employeeRepository.findOne(createCaseDeliveryDocDto.employeeId);
    const result = await this.caseDeliveryDocsRepository.save(createCaseDeliveryDocDto);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Case-delivery-docs`,
        data: result
      }
    }
  }

  async findAll(): Promise<CaseDeliveryDocsWithMessageResponse> {
    const result = await this.caseDeliveryDocsRepository.find({ relations:['employee']});
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Case-delivery-docs`,
        data: result
      }
    }
  }

  async findOne(caseDeliveryDocId: number): Promise<CaseDeliveryDocsWithMessageResponse> {
    try {
      const result = await this.caseDeliveryDocsRepository.findOne(
        {
         relations:['employee'],
          where:
            { id: caseDeliveryDocId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Case-delivery-docs`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Case-delivery-docs`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(caseDeliveryDocId: number, updateCaseDeliveryDocDto: UpdateCaseDeliveryDocDto): Promise<CaseDeliveryDocsWithMessageResponse> {
    await this.caseRepository.findOne(updateCaseDeliveryDocDto.caseId);
    await this.employeeRepository.findOne(updateCaseDeliveryDocDto.employeeId);
    const data = await this.caseDeliveryDocsRepository.findOne(caseDeliveryDocId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Case-delivery-docs`, HttpStatus.NOT_FOUND);
    }
    await this.caseDeliveryDocsRepository.update(caseDeliveryDocId, updateCaseDeliveryDocDto)
    return {
      message: `${Messages.Resource.Updated} : Case-delivery-docs`,
    }
  }

  async remove(caseDeliveryDocId: number): Promise<CaseDeliveryDocsWithMessageResponse> {
    try {
      const deleteCaseDeliveryDocs = await this.caseDeliveryDocsRepository.delete(caseDeliveryDocId)
      if (deleteCaseDeliveryDocs.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Case-delivery-docs`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async findByCaseId(caseId: number): Promise<CaseDeliveryDocsWithMessageResponse> {
    try {
      const result = await this.caseDeliveryDocsRepository.find(
        {
          relations: ['employee', 'case'],
          where:
            { caseId: caseId }
        }
      );

      if (result)
        return {
          message: `${Messages.Resource.Found} : Case-delivery-docs by case-id`,
          data: result
        }
    } catch (error) {
      throw error;
    }
  }
}
