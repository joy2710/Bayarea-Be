import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CaseDeliverDocsResponse } from './case-deliver-docs.response';

export class CaseDeliveryDocsWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CaseDeliverDocsResponse | CaseDeliverDocsResponse[];

  constructor(message: string, data: CaseDeliverDocsResponse | CaseDeliverDocsResponse[]) {
    this.data = data;
    this.message = message;
  }
}
