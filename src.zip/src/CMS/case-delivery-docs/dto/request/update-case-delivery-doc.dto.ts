import { PartialType } from '@nestjs/swagger';
import { CreateCaseDeliveryDocDto } from './create-case-delivery-doc.dto';

export class UpdateCaseDeliveryDocDto extends PartialType(CreateCaseDeliveryDocDto) {}
