import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { CaseDeliverDocStatus } from "../../entities/status.enum";

export class CreateCaseDeliveryDocDto {
    @ApiProperty()
    @IsNotEmpty()
    caseId: number;

    @ApiProperty()
    @IsNotEmpty()
    employeeId: number;

    @ApiProperty()
    @IsOptional()
    docsDelivered: string;

    @ApiProperty()
    @IsOptional()
    notes: string;

    @ApiProperty({ default: CaseDeliverDocStatus.FIRSTREVSUBMITTED })
    @IsNotEmpty()
    @IsEnum(CaseDeliverDocStatus)
    status: CaseDeliverDocStatus;
}


