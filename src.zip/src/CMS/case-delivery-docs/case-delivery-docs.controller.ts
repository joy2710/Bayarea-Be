import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CaseDeliveryDocsParentRoute, CaseDeliveryDocsRoutes } from './case-delivery-docs.http.routes';
import { CaseDeliveryDocsService } from './case-delivery-docs.service';
import { CreateCaseDeliveryDocDto } from './dto/request/create-case-delivery-doc.dto';
import { UpdateCaseDeliveryDocDto } from './dto/request/update-case-delivery-doc.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Case-delivery-docs')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CaseDeliveryDocsParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class CaseDeliveryDocsController {
  constructor(private readonly caseDeliveryDocsService: CaseDeliveryDocsService) {}

  @Post(CaseDeliveryDocsRoutes.create)
  create(@Body() createCaseDeliveryDocDto: CreateCaseDeliveryDocDto) {
    return this.caseDeliveryDocsService.create(createCaseDeliveryDocDto);
  }

  @Public()
  @Get(CaseDeliveryDocsRoutes.view_all)
  findAll() {
    return this.caseDeliveryDocsService.findAll();
  }

  @Public()
  @Get(CaseDeliveryDocsRoutes.view_one)
  findOne(@Param('caseDeliveryDocId') id: string) {
    return this.caseDeliveryDocsService.findOne(+id);
  }

  @Post(CaseDeliveryDocsRoutes.update)
  update(@Param('caseDeliveryDocId') id: string, @Body() updateCaseDeliveryDocDto: UpdateCaseDeliveryDocDto) {
    return this.caseDeliveryDocsService.update(+id, updateCaseDeliveryDocDto);
  }

  @Delete(CaseDeliveryDocsRoutes.delete)
  remove(@Param('caseDeliveryDocId') id: string) {
    return this.caseDeliveryDocsService.remove(+id);
  }

  @Get(CaseDeliveryDocsRoutes.get_by_caseId)
  findByCaseId(@Param('caseId') id: string) {
    return this.caseDeliveryDocsService.findByCaseId(+id);
  }
}
