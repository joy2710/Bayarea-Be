import { Test, TestingModule } from '@nestjs/testing';
import { CaseDeliveryDocsController } from './case-delivery-docs.controller';
import { CaseDeliveryDocsService } from './case-delivery-docs.service';

describe('CaseDeliveryDocsController', () => {
  let controller: CaseDeliveryDocsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CaseDeliveryDocsController],
      providers: [CaseDeliveryDocsService],
    }).compile();

    controller = module.get<CaseDeliveryDocsController>(CaseDeliveryDocsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
