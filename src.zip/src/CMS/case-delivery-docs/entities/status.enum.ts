export enum CaseDeliverDocStatus {
    FIRSTREVSUBMITTED = '1st Rev Submitted',
    ACCEPTED = 'Accepted',
    IDSUBMITTED = 'ID Submitted',
    READYTOFILE = 'Ready to file',
    WAITINGAUTHORIZATION = 'Waiting Authorization',
}
