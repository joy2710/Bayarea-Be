import { Cases } from "src/CMS/cases/entities/cases.entity";
import { Employee } from "src/CMS/employee/entities/employee.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { CaseDeliverDocStatus } from "./status.enum";

@Entity({ name: 'case-delivery-docs' })
export class CaseDeliveryDoc {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    caseId: number;

    @Column()
    employeeId: number;

    @Column()
    docsDelivered: string;

    @Column()
    notes: string;

    @Column({ default: CaseDeliverDocStatus.FIRSTREVSUBMITTED })
    status: CaseDeliverDocStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @ManyToOne(() => Employee, (employee: Employee) => employee.caseAssign,
    {
        eager: false,
        onDelete: 'CASCADE'
    })
    employee: Employee[];
    
    @ManyToOne(() => Cases, (cases: Cases) => cases.caseDeliveryDoc,
    {
        eager: false,
        onDelete: 'CASCADE'
    })
    case: Cases[];
}
