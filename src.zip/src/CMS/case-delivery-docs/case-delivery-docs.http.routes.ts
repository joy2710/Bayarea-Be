export const CaseDeliveryDocsParentRoute = 'case-delivery-docs';

export const CaseDeliveryDocsRoutes = {
  create: '',
  update: 'update/:caseDeliveryDocId',
  delete: ':caseDeliveryDocId',
  view_one: ':caseDeliveryDocId',
  view_all: '',
  get_by_caseId: 'case-id/:caseId',
};
