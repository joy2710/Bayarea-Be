import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CreateManageInvoiceDto } from './dto/request/create-manage-invoice.dto';
import { UpdateManageInvoiceDto } from './dto/request/update-manage-invoice.dto';
import { ManageInvoiceWithMessageResponse } from './dto/response/manageInvoiceWithResponce';
import { ManageInvoice } from './entities/manage-invoice.entity';


@Injectable()
export class ManageInvoiceService {
  constructor(
    @InjectRepository(ManageInvoice) private manageInvoiceRepository: Repository<ManageInvoice>
  ) {}
  async create(createManageInvoiceDto: CreateManageInvoiceDto): Promise<ManageInvoiceWithMessageResponse> {
    const manageInvoice = await this.manageInvoiceRepository.create(createManageInvoiceDto);
    const result = await this.manageInvoiceRepository.save(manageInvoice);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Manage-invoice`,
        data: result
      }
    }
  }

  async findAll(): Promise<ManageInvoiceWithMessageResponse> {
    const result = await this.manageInvoiceRepository.find()
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Manage-invoice`,
        data: result
      }
    }
  }

  async findOne(manageInvoiceId: number): Promise<ManageInvoiceWithMessageResponse> {
    try {
      const result = await this.manageInvoiceRepository.findOne(
        {
          where:
            { id: manageInvoiceId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Manage-invoice`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Manage-invoice`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(manageInvoiceId: number, updateManageInvoiceDto: UpdateManageInvoiceDto): Promise<ManageInvoiceWithMessageResponse> {
    const data = await this.manageInvoiceRepository.findOne(manageInvoiceId);

    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Manage-invoice`, HttpStatus.NOT_FOUND);
    }
    await this.manageInvoiceRepository.update(manageInvoiceId, updateManageInvoiceDto)
    return {
      message: `${Messages.Resource.Updated} : Manage-invoice`,
    }
  }

  async remove(manageInvoiceId: number): Promise<ManageInvoiceWithMessageResponse> {
    try {
      const deletemanageInvoice = await this.manageInvoiceRepository.delete(manageInvoiceId);
      if (deletemanageInvoice.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Manage-invoice`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
