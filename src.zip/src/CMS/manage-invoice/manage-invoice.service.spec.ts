import { Test, TestingModule } from '@nestjs/testing';
import { ManageInvoiceService } from './manage-invoice.service';

describe('ManageInvoiceService', () => {
  let service: ManageInvoiceService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ManageInvoiceService],
    }).compile();

    service = module.get<ManageInvoiceService>(ManageInvoiceService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
