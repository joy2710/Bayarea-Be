
import { CreateManageInvoiceDto } from './create-manage-invoice.dto';

export class UpdateManageInvoiceDto extends (CreateManageInvoiceDto) {}
