import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { ManageInvoiceStatus } from "../../entities/status.enum";

export class CreateManageInvoiceDto {
  
    @ApiProperty()
    @IsNotEmpty()
    item: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;

    @ApiProperty()
    @IsNotEmpty()
    fee: number;

    @ApiProperty({ default: ManageInvoiceStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(ManageInvoiceStatus)
    status: ManageInvoiceStatus;   
} 

