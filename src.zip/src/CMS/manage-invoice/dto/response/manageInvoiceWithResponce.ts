import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ManageInvoiceResponse } from './manage-invoice-response';



export class ManageInvoiceWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: ManageInvoiceResponse | ManageInvoiceResponse[];

  constructor(message: string, data: ManageInvoiceResponse | ManageInvoiceResponse[]) {
    this.data = data;
    this.message = message;
  }
}
