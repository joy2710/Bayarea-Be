import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CreateManageInvoiceDto } from './dto/request/create-manage-invoice.dto';
import { UpdateManageInvoiceDto } from './dto/request/update-manage-invoice.dto';
import { ManageInvoiceParentRoute, ManageInvoiceRoutes } from './manage-invoice-http.routes';
import { ManageInvoiceService } from './manage-invoice.service';
/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Manage-Invoice')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:ManageInvoiceParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()
export class ManageInvoiceController {
  constructor(private readonly manageInvoiceService: ManageInvoiceService) {}

  @Post(ManageInvoiceRoutes.create)
  create(@Body() createManageInvoiceDto: CreateManageInvoiceDto) {
    return this.manageInvoiceService.create(createManageInvoiceDto);
  }

  @Public()
  @Get(ManageInvoiceRoutes.view_all)
  findAll() {
    return this.manageInvoiceService.findAll();
  }

  @Public()
  @Get(ManageInvoiceRoutes.view_one)
  findOne(@Param('manageInvoiceId') id: string) {
    return this.manageInvoiceService.findOne(+id);
  }

  @Post(ManageInvoiceRoutes.update)
  update(@Param('manageInvoiceId') id: string, @Body() updateManageInvoiceDto: UpdateManageInvoiceDto) {
    return this.manageInvoiceService.update(+id, updateManageInvoiceDto);
  }

  @Delete(ManageInvoiceRoutes.delete)
  remove(@Param('manageInvoiceId') id: string) {
    return this.manageInvoiceService.remove(+id);
  }
}
