import { Module } from '@nestjs/common';
import { ManageInvoiceService } from './manage-invoice.service';
import { ManageInvoiceController } from './manage-invoice.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManageInvoice } from './entities/manage-invoice.entity';

@Module({
  imports:[TypeOrmModule.forFeature([ManageInvoice])],
  controllers: [ManageInvoiceController],
  providers: [ManageInvoiceService]
})
export class ManageInvoiceModule {}
