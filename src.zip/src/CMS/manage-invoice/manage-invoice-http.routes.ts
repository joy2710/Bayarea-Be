export const ManageInvoiceParentRoute = 'manage-invoice';

export const ManageInvoiceRoutes = {
  create: '',
  update: 'update/:manageInvoiceId',
  delete: ':manageInvoiceId',
  view_one: ':manageInvoiceId',
  view_all: '',
};