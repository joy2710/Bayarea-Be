import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { ManageInvoiceStatus } from "./status.enum";

@Entity({ name: 'manage-invoice' }) 
export class ManageInvoice {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    item: string;

    @Column({type: 'longtext'})
    description: string;

    @Column()
    fee: number;

    @Column({ default: ManageInvoiceStatus.INACTIVE })
    status: ManageInvoiceStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
}
