export enum ManageInvoiceStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}