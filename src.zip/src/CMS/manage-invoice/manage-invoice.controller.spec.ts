import { Test, TestingModule } from '@nestjs/testing';
import { ManageInvoiceController } from './manage-invoice.controller';
import { ManageInvoiceService } from './manage-invoice.service';

describe('ManageInvoiceController', () => {
  let controller: ManageInvoiceController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ManageInvoiceController],
      providers: [ManageInvoiceService],
    }).compile();

    controller = module.get<ManageInvoiceController>(ManageInvoiceController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
