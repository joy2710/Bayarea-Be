import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { NewsStatus } from "./status.enum";

@Entity()
export class News {
    
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column({type: 'longtext'})
    description: string;

    @Column({ default: NewsStatus.INACTIVE })
    status: NewsStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column()
    imageUrl: string;

    @Column()
    postingDate: Date;

    @Column()
    pageTitleUrl: string;
}

