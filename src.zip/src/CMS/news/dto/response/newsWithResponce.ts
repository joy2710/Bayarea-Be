import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { NewsResponse } from './news-response';

export class NewsWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: NewsResponse | NewsResponse[];

  constructor(message: string, data: NewsResponse | NewsResponse[]) {
    this.data = data;
    this.message = message;
  }
}
