import { CreateNewsDto } from './create-news.dto';

export class UpdateNewsDto extends CreateNewsDto {}
