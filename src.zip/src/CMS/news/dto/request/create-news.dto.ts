import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { NewsStatus } from "../../entities/status.enum";


export class CreateNewsDto {

    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;

    @ApiProperty({ default: NewsStatus.INACTIVE})
    @IsNotEmpty()
    @IsEnum(NewsStatus)
    status: NewsStatus;

    @ApiProperty()
    @IsOptional()
    imageUrl: string;

    @ApiProperty()
    @IsNotEmpty()
    postingDate: Date;

    @ApiProperty()
    @IsOptional()
    pageTitleUrl: string;

}
