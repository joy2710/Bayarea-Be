import { Controller, Get, Post, Body, Param, Delete,Request, UseGuards, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CasesParentRoute, CasesRoutes } from './cases.http.routes';
import { CasesService } from './cases.service';
import { CreateCasesDto } from './dto/request/create-cases.dto';
import { UpdateCasesDto } from './dto/request/update-cases.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Cases')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path:CasesParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class CasesController {
  constructor(private readonly casesService: CasesService) {}

  @Public()
  @Post(CasesRoutes.create)
  createCases(@Body() body: CreateCasesDto,@Request() req, @Req() req1) {
    let employeeLogin= req.user;
    return this.casesService.create(body,employeeLogin,req1);
  }

  @Public()
  @Get(CasesRoutes.view_all)
  findAllCases() {
    return this.casesService.findAll();
  }

  @Get(CasesRoutes.view_one)
  findCasesById(@Param('caseId') id: string) {
    return this.casesService.findOne(+id);
  }

  @Post(CasesRoutes.update)
  updateCasesById(@Param('caseId') id: string, @Body() body: UpdateCasesDto,@Req() req) {
    return this.casesService.update(+id, body,req);
  }

  @Delete(CasesRoutes.delete)
  removeCasesById(@Param('caseId') id: string, @Req() req) {
    return this.casesService.remove(+id, req);
  }
  @Get(CasesRoutes.get_by_userId)
  findByUserId(@Param('userType') userType: string,@Param('userId') id:string) {
    return this.casesService.findByUserId(+id,userType);
  }
  // find by Base Case Number
  @Public()
  @Post(CasesRoutes.find_by_basecase_number)
  findByBaseCase(@Req() request: any) {
    return this.casesService.findByBaseCase(request.body);
  }
  @Get(CasesRoutes.get_by_clientId)
  getCaseByClientId(@Param('clientId') clientId: string) {
    return this.casesService.getCaseByClientId(+clientId);
  }

  @Post(CasesRoutes.caseAssociation)
  createCaseAssociation(@Req() req ) {
    return this.casesService.createCaseAssociation(req);
  }

  @Post(CasesRoutes.caseDissociation)
  dissociateCasesById(@Param('caseId') id: string, @Body() body) {
    return this.casesService.dissociateCasesById(+id, body);
  }
  @Post(CasesRoutes.update_all_cases)
  updateAll(@Req() req) {
    return this.casesService.updateAll(req);
  }

  @Get(CasesRoutes.get_case_details)
   getCaseDetails(@Param('caseId') id: string) {
    return this.casesService.getCaseDetails(+id);
  }
}
