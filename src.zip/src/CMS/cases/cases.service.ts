import { HttpException, HttpStatus, InternalServerErrorException, Injectable, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { getRepository,Repository } from 'typeorm';
import { CaseAssignService } from '../case-assign/case-assign.service';
import { JobAssigned } from '../case-assign/entities/job-assign.enum';
import { CaseAssignStatus } from '../case-assign/entities/status.enum';
import { ClientService } from '../client/client.service';
import { CreateCasesDto } from './dto/request/create-cases.dto';
import { UpdateCasesDto } from './dto/request/update-cases.dto';
import { CasesWithMessageResponse } from './dto/response/casesWithResponse';
import { Cases } from './entities/cases.entity';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { LoggerService } from 'src/common/helpers/logger/Logger.service';
import { CaseAssociation } from '../case-association/entities/case-association.entity';
import { ConfigService } from '@nestjs/config';
import { StatusLookupService } from '../status-lookup/status-lookup.service';
import { CasesStatus } from './entities/status.enum';
var moment = require('moment');
var btoa = require('btoa');

@Injectable()
export class CasesService {
  constructor(
    @InjectRepository(Cases) private casesRepository: Repository<Cases>,
    private clientRepository:ClientService,
    @InjectRepository(CaseAssociation) private casesAssociationRepository:Repository<CaseAssociation>,
    @Inject(forwardRef(() => CaseAssignService))
    private caseAssignService: CaseAssignService,
    private readonly mailsService: MailService,
    private configService: ConfigService,
    @Inject(forwardRef(() => StatusLookupService))
    private statusLookupService: StatusLookupService,

  ) { }

  async create(request: CreateCasesDto,employeeLogin,req  ): Promise<any> {
    try {
      await this.clientRepository.findOne(request.clientId);
      const cases = await this.casesRepository.create(request);
      const result = await this.casesRepository.save(cases);
   
      // FOR-EMPLOYEE-LOGIN
      if(result && employeeLogin?.roleEmployee){
        const caseAssignReq={
          caseId:result.id, 
          employeeId:employeeLogin.userId,
          jobAssigned:JobAssigned.CLAIMS,
          cost:0,
          dateAssigned: (new Date(new Date().toString().split('GMT')[0]).toISOString().split('T')[0]),
          notes:'',
          status:CaseAssignStatus.PENDING_ACCEPTANCE,
        }
         await this.caseAssignService.create(caseAssignReq);
    
      }
      const mailNewData = {
        'case number': result.caseNumber, 'other data type': result.otherDataValue, 'origin type .': result.originType,
       
      }
      if(req !=''){
        const caseId = result.id
        const caseOrderDetailData = await this.casesRepository
          .createQueryBuilder('case')
          .leftJoinAndSelect('case.orderDetail', 'orderDetail')
          .leftJoinAndSelect('orderDetail.order', 'order')
          .where('case.id = :caseId', { caseId})
          .select([
            'case.id',             
            'orderDetail.id',      
            'order',             
          ])
          .getOne();
          let orderData;
          if (caseOrderDetailData && caseOrderDetailData.orderDetail) {
             orderData = caseOrderDetailData.orderDetail[0]?.order;
          }
        let frontUrl = this.configService.get<string>('FRONT_URL');
      var mail: IMail = {
        to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
        subject: `CIS Update: case created, case # ${result.caseNumber}  ${ (orderData)? (orderData?.firstName + ' ' + (orderData?.middleName ?? '') + ' ' + orderData?.lastName ):''}  ${(orderData?.id) ? btoa(orderData?.id).replace(/=+$/, ''):''}`,
        url: req.headers['userdetail']+ ' ' + 'has created a new case',
        data: mailNewData,
        requestdata: req.headers['userdetailid'],
        fronturl:frontUrl,

      };
      await this.mailsService.sendingMail(mail, TemplateTypes.cis_change);
    }
      return {
        message: `${Messages.Resource.Created} : Cases`,
        data: result
        
      }
      
    } catch (error) {
      if (error.response) {
        return {
          message: error?.response,
        }
      } else {
        return {
          message: error?.sqlMessage,
        }
      }
    }
  }

  async createCase(request: CreateCasesDto): Promise<any> {
    try {
      
      const cases = await this.casesRepository.create(request);
      const result = await this.casesRepository.save(cases);
      return {
        message: `${Messages.Resource.Created} : Cases`,
        data: result
      }   
    }catch (error) {
      if (error.response) {
        return {
          message: error?.response,
        }
      } else {
        return { 
          message: error?.sqlMessage,
        }
      }
    } 
  }
  async findAll(): Promise<CasesWithMessageResponse> {
    const result = await this.casesRepository.find({relations: ['client']});
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Cases`,
        data: result
      }
    }
  }

  async findOne(caseId: number): Promise<CasesWithMessageResponse> {
    try {
      const result = await this.casesRepository.findOne(
        {        
          relations: ['client'],
          where:
            { id: caseId }
        }
      );  
      if (!result)
        throw new HttpException(``, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Cases`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(caseId: number, request: UpdateCasesDto, req): Promise<CasesWithMessageResponse> {
    await this.clientRepository.findOne(request.clientId);
    const data = await this.casesRepository.findOne(caseId);
    if (!data) {
      throw new HttpException(`Case-id not exist`, HttpStatus.NOT_FOUND);
    }
    await this.casesRepository.update(caseId, request)
    const result = await this.casesRepository.findOne(
      {        
        relations: ['client', 'caseFile'],
        where:
          { id: caseId }
      }
    ); 
    const oldData = JSON.stringify(data);
    const newData = JSON.stringify(result);
    const oldCase = JSON.parse(oldData);
    const newCase = JSON.parse(newData);
    const otherData = result?.otherDataValue ? JSON.parse(result.otherDataValue) : {};
    const CasetypeValue = otherData["1"];
    const qualityVlaue = otherData["4"];
    const caseStatusValue = otherData["8"];
    const newCaseData = {
      'case number': newCase.caseNumber,
      'case type': CasetypeValue,
      'Quality': qualityVlaue,
      'Case Status': caseStatusValue,
      'origin type': newCase.originType,
  };
  const oldOtherData = oldCase?.otherDataValue? JSON.parse(oldCase?.otherDataValue):{};
  const oldCasetypeValue = oldOtherData["1"];
  const oldQualityVlaue = oldOtherData["4"];
  const oldCaseStatusValue = oldOtherData["8"];

  const oldCaseData = {
    'case number': oldCase.caseNumber,
      'case type': oldCasetypeValue,
      'Quality': oldQualityVlaue,
      'Case Status': oldCaseStatusValue,
      'origin type': oldCase.originType,
  };
  let changes: { key: string; oldValue: any; newValue: any }[] = [];
  let notChanges: { key: string; oldValue: any; newValue: any }[] = [];
  let finalChanges = {};
  
  const deepEqual = (a, b) => {
    if (Array.isArray(a) && Array.isArray(b)) {
      return JSON.stringify(a) === JSON.stringify(b);
    }
    return a === b;
  };  
  if (newData !== oldData) {
    Object.keys(newCaseData).forEach(key => {
      if (!deepEqual(oldCaseData[key], newCaseData[key])) {
        changes.push({
          key: key,
          oldValue: oldCaseData[key],
          newValue: key === 'clientRootPath' ? '' : newCaseData[key]
        });
      } else {
        notChanges.push({
          key: key,
          oldValue: oldCaseData[key],
          newValue: ''
        });
      }
    });
    finalChanges = [...changes, ...notChanges];

  }
  const pathPrefix = `${this.configService.get<string>(
    'FOLDER_PATH',
  )}/`;
    const statusLookup: any = await this.statusLookupService.getByStatusName('Upload Document Page');
    const updatedCaseFiles = (Array.isArray(result.caseFile) ? result.caseFile : [result.caseFile]).map((file: any) => {
      const status = statusLookup.data.find(status => status.id.toString() === file.status);
    const createdDate = file.createdDate ? moment(new Date(file.createdDate)).format(
      'YYYY-MM-DD',
    ): null;
    const description = file.description ? file.description.replace(/<\/?[^>]+(>|$)/g, "") : "";
    const filePath =
    pathPrefix + file.filePath.replace(/ /g, '%20');
      return {
        ...file,
        status: status ? status.displayName : file.status, 
        createdDate,
        description,
        filePath
      };
    });
    const caseOrderDetailData = await this.casesRepository
      .createQueryBuilder('case')
      .leftJoinAndSelect('case.orderDetail', 'orderDetail')
      .leftJoinAndSelect('orderDetail.order', 'order')
      .where('case.id = :caseId', { caseId})
      .select([
        'case.id',             
        'orderDetail.id',      
        'order',             
      ])
      .getOne();
      let orderData;
      if (caseOrderDetailData && caseOrderDetailData.orderDetail) {
         orderData = caseOrderDetailData.orderDetail[0]?.order;
      }
    let frontUrl = this.configService.get<string>('FRONT_URL');
    var mail: IMail = {
      to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
      subject: `CIS Update: case updated, case # ${data.caseNumber}  ${ (orderData)? (orderData?.firstName + ' ' + (orderData?.middleName ?? '') + ' ' + orderData?.lastName ):''}  ${(orderData?.id) ? btoa(orderData?.id).replace(/=+$/, ''):''}`,
      url: req.headers['userdetail']+ ' ' + 'has updated case',
      data: finalChanges,
      orderdata: updatedCaseFiles,
      requestdata: req.headers['userdetailid'],
      fronturl: frontUrl,
    };
    await this.mailsService.sendingMail(mail, TemplateTypes.case_changes_details);
    return {
      message: `${Messages.Resource.Updated} : Cases`,
    }
  }

  async remove(caseId: number, req) {
    try {
     const updatedData = {
        status: CasesStatus.DELETED,
      };
      const deleteCases = await this.casesRepository.update(caseId,updatedData);
      let frontUrl = this.configService.get<string>('FRONT_URL');
      var mail: IMail = {
        to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
        subject: `CIS Update: case deleted`,
        data: 'A case deleted',
        cc: '',
        requestdata: req.headers['userdetailid'],
        fronturl: frontUrl,
      };
      await this.mailsService.sendingMail(mail, TemplateTypes.cis_change);
      if (deleteCases) {
        return {
          message: `${Messages.Resource.Deleted} : Cases`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async findByUserId(empId: number,userType:string): Promise<CasesWithMessageResponse> {
    try {
      let result:any
      // FOR-ADMIN-LOGIN
      if(userType === 'Admin' || userType === 'CAdmin' || userType === 'CISAdmin'){
        result = await getRepository(Cases)
          .createQueryBuilder('cases')
          .select(['DISTINCT cases.id,cases.clientId,cases.caseNumber,cases.baseCaseNumber,cases.originType,cases.otherDataValue,cases.status,cases.caseAssociationId,client.email,client.firstName,client.middleName,client.lastName,client.phone,order.leadType,order.isDeleted,cases.createdDate,order.id AS orderId'])
          .innerJoin('cases.client', 'client')
          .leftJoin('order_detail', 'orderDetail', 'orderDetail.caseId = cases.id')
          .leftJoin('order', 'order', 'orderDetail.orderId = order.id')
          .where('(order.isArchive IS NULL OR order.isArchive = 0)')
          .addSelect((subQuery) => {
            return subQuery
              .select('count(id) as ordercount')
              .from('order', 'order')
              .where('order.clientId = client.id')
          }, 'ordercount')
          .getRawMany();
      } else if(userType === 'employee') {
        // FOR-EMPLOYEE-LOGIN
        result = await getRepository(Cases)
          .createQueryBuilder('cases')
          .select(['DISTINCT cases.id,cases.clientId,cases.caseNumber,cases.baseCaseNumber,cases.originType,cases.otherDataValue,cases.status,cases.caseAssociationId,client.email,client.firstName,client.middleName,client.lastName,client.phone,order.leadType,order.isDeleted,cases.createdDate'])
          .innerJoin('cases.caseAssign', 'case-assign')
          .innerJoin('cases.client', 'client')
          .leftJoin('order_detail', 'orderDetail', 'orderDetail.caseId = cases.id')
          .leftJoin('order', 'order', 'orderDetail.orderId = order.id')
          .where('(order.isArchive IS NULL OR order.isArchive = 0)')
          .addSelect((subQuery) => {
            return subQuery
              .select('count(id) as ordercount')
              .from('order', 'order')
              .where('order.clientId = client.id')
          }, 'ordercount')
          .where('case-assign.employeeId=:empId', { empId: empId })
          .getRawMany();
      }
      if (result)
        return {
          message: `${Messages.Resource.Found} : Case-assign`,
          data: result
        }
    } catch (error) {
      throw error;
    }
  }

   // find by Base Case Number
   async findByBaseCase(datajson: any) {
    try {
      let result = await this.casesRepository.find({where: {baseCaseNumber: datajson.baseCaseNumber}})
      if(result.length !=0){
        return true
      }
      else if(result.length==0){
        return false
      }
   
    } catch (error) {
      throw error;
    }
  }

  async getCaseByClientId(clientId: number) {
    const result = await this.casesRepository
      .createQueryBuilder('case')
      .leftJoinAndSelect('case.client', 'client')
      .leftJoinAndSelect('case.orderDetail', 'orderDetail')
      .leftJoinAndSelect('orderDetail.product', 'product')
      .leftJoinAndSelect('orderDetail.order', 'order')
      .where('case.clientId = :clientId', { clientId })
      .andWhere('(order.id IS NULL OR (order.isDeleted = false AND (order.isArchive = false OR order.isArchive IS NULL)))')
      .getMany();
    return result;
  }

  async caseByClientId(clientId: number ) {
    const query  = await this.casesRepository.createQueryBuilder('case')
    .leftJoinAndSelect('case.client', 'client')
    .where('client.id = :clientId', {clientId: clientId});
    const [result, count] = await query.getManyAndCount();
    return {
      totalCount: count,
      data: result
    }
  }
 
  
  async createCaseAssociation(req:any){
   const idsToUpdate =req.body.ids
    const caseAssociationData = await this.casesAssociationRepository.save({
      name:moment().format('yyyy-mm-dd:hh:mm:ss')
    })
    idsToUpdate.map(async (id: any) => {
     const  updatedData = {
      caseAssociationId: caseAssociationData.id
        };
      await this.casesRepository.update(id, updatedData);
    })
    return {
      message: `${Messages.Resource.Updated} : case`,
    };
  }

  async dissociateCasesById(caseId: number, request:any){
    const data = await this.casesRepository.findOne(caseId);
    if (!data) {
      throw new HttpException(`Case-id not exist`, HttpStatus.NOT_FOUND);
    }
    await this.casesRepository.update(caseId, request)
    return {
      message: `${Messages.Resource.Updated} : Cases`,
    }
  }

  async updateAll(req: any): Promise<any> {
    const ids = req.body.id;
    let updatedData: any;
    const action = req.body.action;
    if (action == 'archive' || action == 'delete' ) {
      if (action === 'archive') {
        updatedData = {
          status: CasesStatus.ARCHIVED,
        };
      } else if (action === 'delete') {
        updatedData = {
          status: CasesStatus.DELETED,
        };
      } 
    }
    for (let id of ids) {
      await this.casesRepository.update(id,updatedData);
    }
    return {
      message: `${Messages.Resource.Updated} : case`,
    };
  }

  //  case id 

  async getCaseDetails(caseId: number): Promise<CasesWithMessageResponse> {
    try {
      const result = await this.casesRepository.findOne(
        {        
          relations: ['orderDetail','orderDetail.product'],
          where:
            { id: caseId }
        }
      );  
      if (!result)
        throw new HttpException(``, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Cases`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }
}
