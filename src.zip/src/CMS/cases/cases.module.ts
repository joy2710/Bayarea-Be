import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CasesService } from './cases.service';
import { CasesController } from './cases.controller';
import { Cases } from './entities/cases.entity';
import { Client } from '../client/entities/client.entity';
import { ClientModule } from '../client/client.module';
import { ClientService } from '../client/client.service';
import { CaseAssign } from '../case-assign/entities/case-assign.entity';
import { CaseAssignModule } from '../case-assign/case-assign.module';
import { CaseAssignService } from '../case-assign/case-assign.service';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { Order } from '../order/entities/order.entity';
import { TaskInstruction } from '../task-instruction/entities/task-instruction.entity';
import { Setting } from '../setting/entities/setting.entity';
import { CaseAssociation } from '../case-association/entities/case-association.entity';
import { OrderPayment } from '../order-payment/entities/order-payment.entity';
import { OrderInventorsService } from '../order-inventors/order-inventors.service';
import { OrderInventor } from '../order-inventors/entities/order-inventor.entity';
import { OrderAssigneeDocumentService } from '../order-assignee-document/order-assignee-document.service';
import { OrderAssigneeDocument } from '../order-assignee-document/entities/order-assignee-document.entity';
import { CaseFile } from '../case-file/entities/case-file.entity';
import { CaseFileService } from '../case-file/case-file.service';
import { Folder } from '../folder/entities/folder.entity';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { ConfigService } from '@nestjs/config';
import { StatusLookupModule } from '../status-lookup/status-lookup.module';
import { StatusLookupService } from '../status-lookup/status-lookup.service';
import { StatusLookup } from '../status-lookup/entities/status-lookup.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Cases,Client,CaseAssign,OrderInventor, Order,OrderPayment,OrderAssigneeDocument,CaseFile,Folder,ProductOrderDetailForm, TaskInstruction,Setting,CaseAssociation]),ClientModule, forwardRef(() => CaseAssignModule),forwardRef(() => StatusLookupModule)],
  controllers: [CasesController],
  providers: [CasesService,CaseAssignService,MailService,OrderInventorsService,OrderAssigneeDocumentService,ConfigService],
  exports: [CasesService]
})
export class CasesModule { }
