export const CasesParentRoute = 'cases';

export const CasesRoutes = {
  create: '',
  update: 'update/:caseId',
  delete: ':caseId',
  view_one: ':caseId',
  view_all: '',
  get_by_userId: 'userType-id/:userType/:userId',
  find_by_basecase_number:'findByBaseCaseNumber',
  get_by_clientId: 'getCaseByClientId/:clientId',
  caseAssociation:'caseAssociation',
  caseDissociation:'caseDissociation/:caseId',
  update_all_cases:'updateCase',
  get_case_details:'getCaseDetails/:caseId',
};
