export enum CasesStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
    ARCHIVED= 'Archived',
    DELETED = 'Deleted'
}