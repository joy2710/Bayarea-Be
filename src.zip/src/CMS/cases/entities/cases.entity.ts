import { CaseAssign } from "src/CMS/case-assign/entities/case-assign.entity";
import { Client } from "src/CMS/client/entities/client.entity";
import { CaseFile } from "src/CMS/case-file/entities/case-file.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { CasesStatus } from "./status.enum";
import { CaseDeliveryDoc } from "src/CMS/case-delivery-docs/entities/case-delivery-doc.entity";
import { Order } from "src/CMS/order/entities/order.entity";
import { OrderDetail } from "src/CMS/order-detail/entities/order-detail.entity";

@Entity({ name: 'cases' })
export class Cases {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    clientId: number;

    @ManyToOne(() => Client, (client: Client) => client.case, {
        eager: false,
        onDelete: 'CASCADE'
    })
     client: Client[];
     
    @Column("varchar")
    caseNumber: string;

    @Column()
    otherDataValue: string;

    @Column({ default: CasesStatus.ACTIVE })
    status: CasesStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column()
    originType: string;

    @OneToMany(() => CaseAssign, (caseAssign: CaseAssign) => caseAssign.case)
    caseAssign: CaseAssign;

    @OneToMany(() => CaseFile, (caseFile: CaseFile) => caseFile.case)
    caseFile: CaseFile;

    @OneToMany(() => CaseDeliveryDoc, (caseDeliveryDoc: CaseDeliveryDoc) => caseDeliveryDoc.case)
    caseDeliveryDoc: CaseDeliveryDoc;

    @OneToMany(() => Order, (order: Order) => order.case)
    order: Order;

    @Column({type:"varchar"})
    baseCaseNumber?: string;

    @OneToMany(() => OrderDetail, (orderDetail: OrderDetail) => orderDetail.case)
    orderDetail: OrderDetail;

    @Column({ nullable: true })
    caseAssociationId: number
}
