import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CasesResponse } from './cases-response';

export class CasesWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CasesResponse | CasesResponse[];

  constructor(message: string, data: CasesResponse | CasesResponse[]) {
    this.data = data;
    this.message = message;
  }
}
