import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { CasesStatus } from '../../entities/status.enum';

export class CasesResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  clientId: number;

  @ApiProperty()
  @Expose()
  caseNumber: string;

  @ApiProperty()
  @Expose()
  otherDataValue: string;

  @ApiProperty({ example: CasesStatus })
  @Expose()
  status: CasesStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

  @ApiProperty()
  @Expose()
  originType: string;

  
  @ApiProperty()
  @Expose()
  baseCaseNumber?: string;


  @ApiProperty()
  @Expose()
  caseAssociationId?:number


}
