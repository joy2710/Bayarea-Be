import { CreateCasesDto } from './create-cases.dto';

export class UpdateCasesDto extends CreateCasesDto{}
