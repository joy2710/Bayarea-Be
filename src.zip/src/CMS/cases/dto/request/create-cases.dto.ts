import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator"
import { CasesStatus } from "../../entities/status.enum";

export class CreateCasesDto {

    @ApiProperty()
    @IsNotEmpty()
    clientId: number;

    @ApiProperty()
    @IsNotEmpty()
    caseNumber: string;

    @ApiProperty()
    @IsOptional()
    otherDataValue?: string;

    @ApiProperty({ default: CasesStatus.ACTIVE })
    @IsNotEmpty()
    @IsEnum(CasesStatus)
    status: CasesStatus;

    @ApiProperty()
    @IsOptional()
    originType: string;

    @ApiProperty()
    @IsOptional()
    baseCaseNumber?: string;

    @ApiProperty()
    @IsOptional()
    caseAssociationId?:number

}
