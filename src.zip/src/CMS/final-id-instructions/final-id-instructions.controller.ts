import { Controller, Get, Post, Body, Param, Delete, UseGuards } from '@nestjs/common';
import { FinalIdInstructionsService } from './final-id-instructions.service';

import { UpdateFinalIdInstructionDto } from './dto/request/update-final-id-instruction.dto';
import { CreateFinalIdInstructionDto } from './dto/request/create-final-id-instruction.dto';
import { FinalIdInstructionRoute, FinalIdInstructionRoutes } from './final.id.instructions.http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';



@ApiTags('final-id-instructions')
@Controller({ path:FinalIdInstructionRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

@Controller('final-id-instructions')
export class FinalIdInstructionsController {
  constructor(private readonly finalIdInstructionsService: FinalIdInstructionsService) {}

  @Post(FinalIdInstructionRoutes.create)
  create(@Body() createFinalIdInstructionDto: CreateFinalIdInstructionDto) {
    return this.finalIdInstructionsService.create(createFinalIdInstructionDto);
  }

  @Get(FinalIdInstructionRoutes.view_all)
  findAll() {
    return this.finalIdInstructionsService.findAll();
  }

  @Get(FinalIdInstructionRoutes.view_one)
  findOne(@Param('finalIdInstructionId') id: string) {
    return this.finalIdInstructionsService.findOne(+id);
  }

  @Post(FinalIdInstructionRoutes.update)
  update(@Param('finalIdInstructionId') id: string, @Body() updateFinalIdInstructionDto: UpdateFinalIdInstructionDto) {
    return this.finalIdInstructionsService.update(+id, updateFinalIdInstructionDto);
  }

  @Delete(FinalIdInstructionRoutes.delete)
  remove(@Param('finalIdInstructionId') id: string) {
    return this.finalIdInstructionsService.remove(+id);
  }
}
