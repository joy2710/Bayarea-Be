import { Column,Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity ({name: 'final-id-instructions'})

export class FinalIdInstruction {

    @PrimaryGeneratedColumn()
    id:number;

    @Column({type: 'longtext'})
    description:string;
    
}
