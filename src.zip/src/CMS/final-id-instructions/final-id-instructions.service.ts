import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { UpdateFinalIdInstructionDto } from './dto/request/update-final-id-instruction.dto';
import { FinalIdInstruction } from './entities/final-id-instruction.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm/repository/Repository';
import { FinalIdInstructionWithMessageResponse } from './dto/response/finalidinstructionWithResponse';
import { Messages } from 'src/common/constants/messages';
import { CreateFinalIdInstructionDto } from './dto/request/create-final-id-instruction.dto';

@Injectable()
export class FinalIdInstructionsService {
  constructor(
    @InjectRepository(FinalIdInstruction) private finalIdInstructionRepository: Repository<FinalIdInstruction>,

  ) { }

  async create(createFinalIdInstructionDto: CreateFinalIdInstructionDto): Promise<FinalIdInstructionWithMessageResponse> {
     const finalIdInstruction = await this.finalIdInstructionRepository.create(createFinalIdInstructionDto);
    const result = await this.finalIdInstructionRepository.save(finalIdInstruction)
      return {
        message: `${Messages.Resource.Created} : Final Id Instruction`,
        data: result
    }

  }

  

 async findAll(): Promise<FinalIdInstructionWithMessageResponse> {
  const result = await this.finalIdInstructionRepository.find()
  if (result) {
    return {
      message: `${Messages.Resource.Found}: Final Id Instruction`,
      data: result
    }
  }
  }

 async findOne(finalIdInstructionId: number) : Promise<FinalIdInstructionWithMessageResponse> {
    try {
      const result = await this.finalIdInstructionRepository.findOne(
        {
          where:
            { id: finalIdInstructionId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}:Final Id Instruction`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Final Id Instruction`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

async  update(finalIdInstructionId: number, updateFinalIdDto: UpdateFinalIdInstructionDto) : Promise<FinalIdInstructionWithMessageResponse> {
    const data = await this.finalIdInstructionRepository.findOne(finalIdInstructionId);

    if (!data) {
      throw new HttpException(`Final Id Instruction not exist`, HttpStatus.NOT_FOUND);
    }
    await this.finalIdInstructionRepository.update(finalIdInstructionId, updateFinalIdDto)
    return {
      message: `${Messages.Resource.Updated} : Final Id Instruction`,
    }
  }

 async remove(finalIdInstructionId: number): Promise<FinalIdInstructionWithMessageResponse> {
    try {
      const deleteEventLog = await this.finalIdInstructionRepository.delete(finalIdInstructionId);
      if (deleteEventLog.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted}: Final Id Instruction  `
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
