import { Test, TestingModule } from '@nestjs/testing';
import { FinalIdInstructionsController } from './final-id-instructions.controller';
import { FinalIdInstructionsService } from './final-id-instructions.service';

describe('FinalIdInstructionsController', () => {
  let controller: FinalIdInstructionsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FinalIdInstructionsController],
      providers: [FinalIdInstructionsService],
    }).compile();

    controller = module.get<FinalIdInstructionsController>(FinalIdInstructionsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
