export const FinalIdInstructionRoute = 'finalid-instruction';

export const FinalIdInstructionRoutes = {
  create: '',
  update: 'update/:finalIdInstructionId',
  delete: ':finalIdInstructionId',
  view_one: ':finalIdInstructionId',
  view_all: '',
};