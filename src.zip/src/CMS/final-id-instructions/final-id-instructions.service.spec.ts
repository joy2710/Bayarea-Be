import { Test, TestingModule } from '@nestjs/testing';
import { FinalIdInstructionsService } from './final-id-instructions.service';

describe('FinalIdInstructionsService', () => {
  let service: FinalIdInstructionsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FinalIdInstructionsService],
    }).compile();

    service = module.get<FinalIdInstructionsService>(FinalIdInstructionsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
