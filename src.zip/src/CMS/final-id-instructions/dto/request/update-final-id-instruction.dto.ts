import { PartialType } from '@nestjs/mapped-types';
import { CreateFinalIdInstructionDto } from './create-final-id-instruction.dto';

export class UpdateFinalIdInstructionDto extends PartialType(CreateFinalIdInstructionDto) {}
