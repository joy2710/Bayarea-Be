import { ApiProperty } from "@nestjs/swagger";

export class CreateFinalIdInstructionDto {

    @ApiProperty()
    description:string;
    
}
