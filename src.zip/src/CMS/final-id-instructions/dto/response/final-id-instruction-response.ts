import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
export class FinalIdInstructionResponse {

  @ApiProperty()
  @Expose()
  id:number;

  @ApiProperty()
  @Expose()
  description?:string;

  
}
