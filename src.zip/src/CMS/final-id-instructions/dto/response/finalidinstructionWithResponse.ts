import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { FinalIdInstructionResponse } from './final-id-instruction-response';



export class FinalIdInstructionWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: FinalIdInstructionResponse | FinalIdInstructionResponse[];

  constructor(message: string, data: FinalIdInstructionResponse | FinalIdInstructionResponse[]) {
    this.data = data;
    this.message = message;
  }
}
