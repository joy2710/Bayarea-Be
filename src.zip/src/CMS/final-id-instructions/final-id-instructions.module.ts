import { Module } from '@nestjs/common';
import { FinalIdInstructionsService } from './final-id-instructions.service';
import { FinalIdInstructionsController } from './final-id-instructions.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinalIdInstruction } from './entities/final-id-instruction.entity';

@Module({
  imports: [TypeOrmModule.forFeature([FinalIdInstruction])],
  controllers: [FinalIdInstructionsController],
  providers: [FinalIdInstructionsService]
})
export class FinalIdInstructionsModule {}
