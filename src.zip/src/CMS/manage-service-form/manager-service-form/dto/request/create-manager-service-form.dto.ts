import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { ManageServiceStatuStatus } from "../../entities/status.enum";

export class CreateManagerServiceFormDto {


    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;

    @ApiProperty({ default: ManageServiceStatuStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(ManageServiceStatuStatus)
    status: ManageServiceStatuStatus;   

    // @ApiProperty()
    // @IsNotEmpty()
    // serialNo: number
}
