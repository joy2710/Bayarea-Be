
import { CreateManagerServiceFormDto } from './create-manager-service-form.dto';

export class UpdateManagerServiceFormDto extends(CreateManagerServiceFormDto) {}
