import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { ManageServiceStatuStatus } from "../../entities/status.enum";
import { TransformDateToEpoch } from "src/common/helpers/decorators/transformDateToEpoch";

export class ManageSeriveFormResponse {
    @ApiProperty()
    @Expose()
    id: number;
  
    @ApiProperty()
    @Expose()
    name: string;
  
    @ApiProperty()
    @Expose()
    description: string;
  
  
    @ApiProperty({ example: ManageServiceStatuStatus })
    @Expose()
    status: ManageServiceStatuStatus;
  
    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    createdDate?: Date;
  
    @ApiProperty()
    @Expose()
    createdBy?: number;
  
    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    updatedDate?: Date;
  
    @ApiProperty()
    @Expose()
    updatedBy?: string;

    // @ApiProperty()
    // @Expose()
    // serialNo: number
  } 
  