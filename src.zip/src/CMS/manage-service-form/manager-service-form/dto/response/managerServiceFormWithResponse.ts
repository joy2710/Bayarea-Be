import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { ManageSeriveFormResponse } from "./manager-service-from-response";


export class ManageServiceFormWithMessageResponse {
    @ApiProperty({
      name: 'Message',
      description: 'Specifies a response message',
      example: 'Process Successful',
    })
  
    @Expose()
    message: string;
  
    @ApiProperty({
      name: 'Data',
      description: 'Specifies response data',
    })
  
    @Expose()
    data?: ManageSeriveFormResponse | ManageSeriveFormResponse[];
  
    constructor(message: string, data: ManageSeriveFormResponse | ManageSeriveFormResponse[]) {
      this.data = data;
      this.message = message;
    }
  }