export enum ManageServiceStatuStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}