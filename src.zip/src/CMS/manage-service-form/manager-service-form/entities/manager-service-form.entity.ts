import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { ManageServiceStatuStatus } from "./status.enum";
import { ManageServiceFormDetail } from "../../manage-service-form-detail/entities/manage-service-form-detail.entity";
import { ProductServiceForm } from "src/CMS/product-service-form/entities/product-service-form.entity";
import { ProductOrderDetailForm } from "src/CMS/product-order-detail-form/entities/product-order-detail-form.entity";
import { ManageServiceFormGroupName } from "../../manage-service-form-group-name/entities/manage-service-form-group-name.entity";

@Entity({ name: 'manage-service-form' }) 
export class ManagerServiceForm {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column({type: 'longtext'})
    description: string;


    @Column({ default: ManageServiceStatuStatus.INACTIVE })
    status: ManageServiceStatuStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @OneToMany(() => ManageServiceFormDetail, (manageServiceFormDetail: ManageServiceFormDetail) => manageServiceFormDetail.serviceForm)
    manageServiceFormDetail: ManageServiceFormDetail;


    @OneToMany(() => ProductServiceForm, (productServiceForm: ProductServiceForm) => productServiceForm.serviceForm)
    productServiceForm: ProductServiceForm;

    @OneToMany(() => ProductOrderDetailForm, (productOrderDetailForm: ProductOrderDetailForm) => productOrderDetailForm.manageServiceForm)
    productOrderDetailForm: ProductOrderDetailForm;

    @OneToMany(() => ManageServiceFormGroupName, (manageServiceFormGroupName: ManageServiceFormGroupName) => manageServiceFormGroupName.serviceForm)
    manageServiceFormGroupName: ManageServiceFormGroupName;

    // @Column()
    // serialNo: number

}
