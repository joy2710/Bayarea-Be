import { Module } from '@nestjs/common';
import { ManagerServiceFormService } from './manager-service-form.service';
import { ManagerServiceFormController } from './manager-service-form.controller';
import { ManagerServiceForm } from './entities/manager-service-form.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports:[TypeOrmModule.forFeature([ManagerServiceForm])],
  controllers: [ManagerServiceFormController],
  providers: [ManagerServiceFormService]
})
export class ManagerServiceFormModule {}
