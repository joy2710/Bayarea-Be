export const ManageServiceFormParentRoute = 'manage-service-form';

export const ManageServiceFormRoutes = {
  create: '',
  update: 'update/:manageServiceFormId',
  delete: ':manageServiceFormId',
  view_one: ':manageServiceFormId',
  view_all: '',
  get_service_form_detail_by_service_form_id: 'getServiceDetailFormByServiceId/:manageServiceFormId',
 
};