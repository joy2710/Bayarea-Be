import { Test, TestingModule } from '@nestjs/testing';
import { ManagerServiceFormService } from './manager-service-form.service';

describe('ManagerServiceFormService', () => {
  let service: ManagerServiceFormService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ManagerServiceFormService],
    }).compile();

    service = module.get<ManagerServiceFormService>(ManagerServiceFormService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
