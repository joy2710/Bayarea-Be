import { Test, TestingModule } from '@nestjs/testing';
import { ManagerServiceFormController } from './manager-service-form.controller';
import { ManagerServiceFormService } from './manager-service-form.service';


describe('ManagerServiceFormController', () => {
  let controller: ManagerServiceFormController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ManagerServiceFormController],
      providers: [ManagerServiceFormService],
    }).compile();

    controller = module.get<ManagerServiceFormController>(ManagerServiceFormController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
