import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ManagerServiceFormService } from './manager-service-form.service';
import { UpdateManagerServiceFormDto } from './dto/request/update-manager-service-form.dto';
import { CreateManagerServiceFormDto } from './dto/request/create-manager-service-form.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ManageServiceFormParentRoute, ManageServiceFormRoutes } from './manage-service-form-http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';



/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Manage-Service-Form')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */



@Controller({ path:ManageServiceFormParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class ManagerServiceFormController {
  constructor(private readonly managerServiceFormService: ManagerServiceFormService) {}

  @Post(ManageServiceFormRoutes.create)
  create(@Body() createManagerServiceFormDto: CreateManagerServiceFormDto) {
    return this.managerServiceFormService.create(createManagerServiceFormDto);
  }

  @Get(ManageServiceFormRoutes.view_all)
  findAll() {
    return this.managerServiceFormService.findAll();
  }

  @Get(ManageServiceFormRoutes.view_one)
  findOne(@Param('manageServiceFormId') id: string) {
    return this.managerServiceFormService.findOne(+id);
  }

  @Post(ManageServiceFormRoutes.update)
  update(@Param('manageServiceFormId') id: string, @Body() updateManagerServiceFormDto: UpdateManagerServiceFormDto) {
    return this.managerServiceFormService.update(+id, updateManagerServiceFormDto);
  }

  @Delete(ManageServiceFormRoutes.delete)
  remove(@Param('manageServiceFormId') id: string) {
    return this.managerServiceFormService.remove(+id);
  }

  @Get(ManageServiceFormRoutes.get_service_form_detail_by_service_form_id)
  getServiceFormDetailByServiceFormId(@Param('manageServiceFormId') id: string) {
    return this.managerServiceFormService.getServiceFormDetailByServiceFormId(+id);
  }
}
