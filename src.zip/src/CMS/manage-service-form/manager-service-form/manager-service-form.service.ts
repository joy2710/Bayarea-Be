import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';

import { UpdateManagerServiceFormDto } from './dto/request/update-manager-service-form.dto';
import { CreateManagerServiceFormDto } from './dto/request/create-manager-service-form.dto';
import { ManagerServiceForm } from './entities/manager-service-form.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, Repository } from 'typeorm';
import { ManageServiceFormWithMessageResponse } from './dto/response/managerServiceFormWithResponse';
import { Messages } from 'src/common/constants/messages';
// import { ManageServiceFormDetail } from '../manage-service-form-detail/entities/manage-service-form-detail.entity';

@Injectable()
export class ManagerServiceFormService {

  constructor(
    @InjectRepository(ManagerServiceForm) private manageServiceFormRepository: Repository<ManagerServiceForm>,
    // @InjectRepository(ManageServiceFormDetail) private manageServiceFromDetailRepository: Repository<ManageServiceFormDetail>
  ) {}
  async create(createManagerServiceFormDto: CreateManagerServiceFormDto):Promise<ManageServiceFormWithMessageResponse>  {
   const  managerServiceForm = await this.manageServiceFormRepository.create(createManagerServiceFormDto);
   const result = await this.manageServiceFormRepository.save(managerServiceForm);
   if(result){
    return {
      message: `${Messages.Resource.Created} : Manage-service-form`,
      data: result
    }
   }
    
  }

 async findAll():Promise<ManageServiceFormWithMessageResponse> {
  const  result = await this.manageServiceFormRepository.find()
   if(result){
    return {
      message: `${Messages.Resource.Found} : Manage-service-form`,
      data: result
    }
   }
  }

  async findOne(manageServiceFormId: number):Promise<ManageServiceFormWithMessageResponse> {
    try {
      const result = await this.manageServiceFormRepository.findOne(
        {
          where:
            { id: manageServiceFormId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Manage-service-form`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Manage-service-form`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(manageServiceFormId: number, updateManagerServiceFormDto: UpdateManagerServiceFormDto):Promise<ManageServiceFormWithMessageResponse> {
    // const startData = await this.manageServiceFormRepository.findOne(    {
    //   where:
    //     { serialNo: updateManagerServiceFormDto.serialNo }
    // });
    const data = await this.manageServiceFormRepository.findOne(manageServiceFormId);
    // Clean Code
    // if(startData){
    //   if (startData.serialNo < data.serialNo){
    //     const itemsToUpdate = await this.manageServiceFormRepository.find({
    //       where: {
    //           serialNo: Between(startData.serialNo, data.serialNo)
    //       }
    //   });
    //   for (const item of itemsToUpdate) {
    //       item.serialNo += 1;
    //       await this.manageServiceFormRepository.save(item);
    //     }
    //   } else if (startData.serialNo > data.serialNo){
    //     const itemsToUpdate = await this.manageServiceFormRepository.find({
    //       where: {
    //         serialNo: Between(data.serialNo, startData.serialNo)
    //       }
    //   });
    //   for (const item of itemsToUpdate) {
    //       item.serialNo -= 1;
    //       await this.manageServiceFormRepository.save(item);
    //     }
    //   }
    // }

    if(!data){
      throw new HttpException(`${Messages.Resource.NotFound} : Manage-service-form`, HttpStatus.NOT_FOUND);
    }
    await this.manageServiceFormRepository.update(manageServiceFormId, updateManagerServiceFormDto)
    return {
      message: `${Messages.Resource.Updated} : Manage-service-form`,
    }
  }

 async remove(manageServiceFormId: number):Promise<ManageServiceFormWithMessageResponse> {
  try {
    const deletemanageServiceForm = await this.manageServiceFormRepository.delete(manageServiceFormId);
    if (deletemanageServiceForm.affected > 0) {
      return {
        message: `${Messages.Resource.Deleted} : Manage-service-form`
      }
    }
  } catch (error) {
    throw new InternalServerErrorException(error.message);
  }
  }

  async getServiceFormDetailByServiceFormId(manageServiceFormId: number): Promise<any> {
    return await this.manageServiceFormRepository.createQueryBuilder('serviceForm')
    .leftJoinAndSelect('serviceForm.manageServiceFormDetail', 'manageServiceFormDetail')
    .where('serviceForm.id=:id', {id: manageServiceFormId})
    .orderBy('manageServiceFormDetail.sequenceNumber', 'ASC')
    .getMany();
  }
}
