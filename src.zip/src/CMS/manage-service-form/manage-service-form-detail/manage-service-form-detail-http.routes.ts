export const ManageServiceFormDetailParentRoute = 'manage-service-form-detail';

export const ManageServiceFormDetailRoutes = {
  create: '',
  update: 'update/:manageServiceFormDetailId',
  delete: ':manageServiceFormDetailId',
  view_one: ':manageServiceFormDetailId',
  view_all: '',
  updateDragAndDrop: 'dragandDrop',
  copy_by_service_form_id: 'copyByServiceId/:manageServiceFormId',
};