import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Query } from '@nestjs/common';
import { ManageServiceFormDetailService } from './manage-service-form-detail.service';
import { CreateManageServiceFormDetailDto } from './dto/request/create-manage-service-form-detail.dto';
import { UpdateManageServiceFormDetailDto } from './dto/request/update-manage-service-form-detail.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ManageServiceFormDetailParentRoute, ManageServiceFormDetailRoutes } from './manage-service-form-detail-http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Manage-Service-Form-Detail')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:ManageServiceFormDetailParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class ManageServiceFormDetailController {
  constructor(private readonly managerServiceFormDetailService: ManageServiceFormDetailService) {}

  @Post(ManageServiceFormDetailRoutes.create)
  create(@Body() createManagerServiceFormDetailDto: CreateManageServiceFormDetailDto) {
    return this.managerServiceFormDetailService.create(createManagerServiceFormDetailDto);
  }

  @Get(ManageServiceFormDetailRoutes.view_all)
  findAll() {
    return this.managerServiceFormDetailService.findAll();
  }

  @Get(ManageServiceFormDetailRoutes.view_one)
  findOne(@Param('manageServiceFormDetailId') id: string) {
    return this.managerServiceFormDetailService.findOne(+id);
  }

  @Post(ManageServiceFormDetailRoutes.update)
  update(@Param('manageServiceFormDetailId') id: string, @Body() updateManageServiceFormDetailDto: UpdateManageServiceFormDetailDto) {
    return this.managerServiceFormDetailService.update(+id, updateManageServiceFormDetailDto);
  }

  @Delete(ManageServiceFormDetailRoutes.delete)
  remove(@Param('manageServiceFormDetailId') id: string) {
    return this.managerServiceFormDetailService.remove(+id);
  }


  @Post(ManageServiceFormDetailRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.managerServiceFormDetailService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }

  @Post(ManageServiceFormDetailRoutes.copy_by_service_form_id)
  copyByServiceFormId(@Param('manageServiceFormId') manageServiceFormId: string) {
    return this.managerServiceFormDetailService.copyByServiceFormId(+manageServiceFormId);
  }
}
