import { Test, TestingModule } from '@nestjs/testing';
import { ManageServiceFormDetailController } from './manage-service-form-detail.controller';
import { ManageServiceFormDetailService } from './manage-service-form-detail.service';

describe('ManageServiceFormDetailController', () => {
  let controller: ManageServiceFormDetailController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ManageServiceFormDetailController],
      providers: [ManageServiceFormDetailService],
    }).compile();

    controller = module.get<ManageServiceFormDetailController>(ManageServiceFormDetailController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
