import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateManageServiceFormDetailDto } from './dto/request/create-manage-service-form-detail.dto';
import { UpdateManageServiceFormDetailDto } from './dto/request/update-manage-service-form-detail.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ManageServiceFormDetail } from './entities/manage-service-form-detail.entity';
import { Between, getConnection,MoreThan,Repository } from 'typeorm';
import { ManageServiceFormDetailWithMessageResponse } from './dto/response/managerServiceFormDetailWithResponse';
import { Messages } from 'src/common/constants/messages';
import { ManagerServiceForm } from '../manager-service-form/entities/manager-service-form.entity';
import { ManageServiceFormGroupName } from '../manage-service-form-group-name/entities/manage-service-form-group-name.entity';
const lodash = require('lodash');

@Injectable()
export class ManageServiceFormDetailService {
 

  constructor(
    @InjectRepository(ManageServiceFormDetail) private manageServiceFormDetailRepository: Repository<ManageServiceFormDetail>,
    @InjectRepository(ManagerServiceForm) private manageServiceFormRepository: Repository<ManagerServiceForm>,
    @InjectRepository(ManageServiceFormGroupName) private manageServiceFormGroupNameRepository: Repository<ManageServiceFormGroupName>
  ) { }

  async create(createManageServiceFormDetailDto: CreateManageServiceFormDetailDto): Promise<ManageServiceFormDetailWithMessageResponse> {
    const managerServiceForm = await this.manageServiceFormDetailRepository.create(createManageServiceFormDetailDto);
    const result = await this.manageServiceFormDetailRepository.save(managerServiceForm);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Manage-service-form-detail`,
        data: result
      }
    }
  }

  // async findAll(): Promise<ManageServiceFormDetailWithMessageResponse> {
  //   const result = await this.manageServiceFormDetailRepository.find({relations: ['serviceForm']})
  //   if (result) {
  //     return {
  //       message: `${Messages.Resource.Found} : Manage-service-form-detail`,
  //       data: result
  //     }
  //   }
  // }

  async findAll(): Promise<ManageServiceFormDetailWithMessageResponse> {
    const result = await this.manageServiceFormDetailRepository
    .createQueryBuilder('manageServiceFormDetail')
    .leftJoinAndSelect('manageServiceFormDetail.serviceForm', 'serviceForm')
    .orderBy('manageServiceFormDetail.sequenceNumber', 'ASC')
    .getMany();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Manage-service-form-detail`,
        data: result
      }
    }
  }

  async findOne(manageServiceFormDetailId: number): Promise<ManageServiceFormDetailWithMessageResponse> {
    try {
      const result = await this.manageServiceFormDetailRepository.findOne(
        {
          relations: ['serviceForm'],
          where: { id: manageServiceFormDetailId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Manage-service-form-detail`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Manage-service-form-detail`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(manageServiceFormDetailId: number, updateManageServiceFormDetailDto: UpdateManageServiceFormDetailDto): Promise<ManageServiceFormDetailWithMessageResponse> {
        const startData = await this.manageServiceFormDetailRepository.findOne(    {
      where:
        { serialNo: updateManageServiceFormDetailDto.serialNo }
    });
    const data = await this.manageServiceFormDetailRepository.findOne(manageServiceFormDetailId);
        if(startData){
      if (startData.serialNo < data.serialNo){
        const itemsToUpdate = await this.manageServiceFormDetailRepository.find({
          where: {
              serialNo: Between(startData.serialNo, data.serialNo),
              serviceFormId: updateManageServiceFormDetailDto.serviceFormId
          }
      });
      for (const item of itemsToUpdate) {
          item.serialNo += 1;
          await this.manageServiceFormDetailRepository.save(item);
        }
      } else if (startData.serialNo > data.serialNo){
        const itemsToUpdate = await this.manageServiceFormDetailRepository.find({
          where: {
            serialNo: Between(data.serialNo, startData.serialNo),
            serviceFormId: updateManageServiceFormDetailDto.serviceFormId
          }
      });
      for (const item of itemsToUpdate) {
          item.serialNo -= 1;
          await this.manageServiceFormDetailRepository.save(item);
        }
      }
    }
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Manage-service-form-detail`, HttpStatus.NOT_FOUND);
    }
    await this.manageServiceFormDetailRepository.update(manageServiceFormDetailId, updateManageServiceFormDetailDto)
    return {
      message: `${Messages.Resource.Updated} : Manage-service-form-detail`,
    }
  }

  async remove(manageServiceFormDetailId: number): Promise<ManageServiceFormDetailWithMessageResponse> {
    try {
      const data = await this.manageServiceFormDetailRepository.findOne(manageServiceFormDetailId);      
      const serialNo = data.serialNo;
      const serviceFormId = data.serviceFormId;
      const nextRecords = await this.manageServiceFormDetailRepository.find({
        where: {
          serviceFormId: serviceFormId,
          serialNo: MoreThan(serialNo), 
        },
        order: {
          serialNo: 'ASC', 
        }
      });      
      const deletemanageServiceForm = await this.manageServiceFormDetailRepository.delete(manageServiceFormDetailId);
       if (nextRecords){
      for (const item of nextRecords) {
          item.serialNo -= 1;
          await this.manageServiceFormDetailRepository.save(item);
        }
      }
      if (deletemanageServiceForm.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Manage-service-form-detail`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }


  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(ManageServiceFormDetail)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(ManageServiceFormDetail)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(ManageServiceFormDetail)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(ManageServiceFormDetail)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(ManageServiceFormDetail)
      .set({ sequenceNumber: () => "sequenceNumber - 1" })
      .where('sequenceNumber > :currSequenceNumber AND sequenceNumber <= :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(ManageServiceFormDetail)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }

  async copyByServiceFormId(manageServiceFormId: number) {
    let serviceForm = [];
    let manageServiceForm;
    let service = [];
    let serviceGroupList = [];
    const serviceFormDetail = await this.manageServiceFormDetailRepository.createQueryBuilder('manageServiceFormDetail')
    .leftJoinAndSelect('manageServiceFormDetail.serviceForm', 'serviceForm')
    .where('serviceForm.id=:id', {id: manageServiceFormId})
    .getMany();
    for(let x of serviceFormDetail) {
      for(let y of [x.serviceForm]) {
        serviceForm.push(y)
        let form = serviceForm.filter((form) => { return form.id === manageServiceFormId})
        service = lodash.uniq(serviceForm)
        // delete form[0].id
      }
    }
    delete service[0].id

    manageServiceForm = await this.manageServiceFormRepository.save({
      name:service[0].name+' copy',
      description:service[0].description,
      status:service[0].status
    });
    serviceGroupList = await this.manageServiceFormGroupNameRepository.find({where: {serviceFormId: manageServiceFormId}});
     for(let x of serviceGroupList) {              
        delete x.id;
      const result =  await this.manageServiceFormGroupNameRepository.save({
          serviceFormId: manageServiceForm.id,
          name: x.name,
          status: x.status,
        })
      }
    for(let x of serviceFormDetail) {                 
        delete x.id;
        await this.manageServiceFormDetailRepository.save({
          serviceFormId: manageServiceForm.id,
          title: x.title,
          question: x.question,
          answer: x.answer,
          insertNote: x.insertNote,
          answerType: x.answerType,
          value: x.value,
          groupName: x.groupName,
          required: x.required,
          sequenceNumber: x.sequenceNumber
        })
      // }
    }
    const result = await this.manageServiceFormDetailRepository.createQueryBuilder('manageServiceFormDetail')
    .leftJoinAndSelect('manageServiceFormDetail.serviceForm', 'serviceForm')
    .where('serviceForm.id=:id', {id: manageServiceFormId})
    .getMany();
    return  result ;
  }
}


