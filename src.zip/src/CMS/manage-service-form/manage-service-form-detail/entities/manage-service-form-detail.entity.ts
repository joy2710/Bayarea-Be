import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { ManagerServiceForm } from "../../manager-service-form/entities/manager-service-form.entity";
import { AnswerType } from "./answer-type.enum";
import { ProductOrderDetailForm } from "src/CMS/product-order-detail-form/entities/product-order-detail-form.entity";

@Entity({ name: 'manage-service-form-detail' }) 
export class ManageServiceFormDetail {
    @PrimaryGeneratedColumn()
    id: number;

    @ManyToOne(() => ManagerServiceForm, (serviceForm: ManagerServiceForm) => serviceForm.manageServiceFormDetail, {
        eager: false,
        onDelete: 'CASCADE'
    })
    serviceForm: ManagerServiceForm[];

    @Column({nullable: true})
    serviceFormId: number;

    @Column({nullable: true})
    title: string;

    @Column({nullable: true, type: 'longtext'})
    question: string;

    @Column({nullable: true, type: 'longtext'})
    answer: string;

    @Column({nullable: true, type: 'text' })
    insertNote: string;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column({ default: AnswerType.TEXT })
    answerType: AnswerType;

    @Column({ type: 'simple-array', nullable: true, default: null })
    value: string[];

    @Column({ nullable: true })
    groupName: string;

    @Column({ default: false, type: Boolean })
    required: true;

    @Column()
    sequenceNumber: number;

    @OneToMany(() => ProductOrderDetailForm, (productOrderDetailForm: ProductOrderDetailForm) => productOrderDetailForm.manageServiceFormDetail)
    productOrderDetailForm: ProductOrderDetailForm;

   
    @Column()
    serialNo: number

}
