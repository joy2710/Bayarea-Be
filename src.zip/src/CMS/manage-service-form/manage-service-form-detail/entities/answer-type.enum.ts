export enum AnswerType {
    TEXT = 'text',
    DROPDOWN = 'dropdown',
    NUMBER='number',
    CALENDAR= 'calendar',
}