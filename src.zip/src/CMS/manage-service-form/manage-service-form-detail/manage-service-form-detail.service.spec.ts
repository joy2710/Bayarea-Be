import { Test, TestingModule } from '@nestjs/testing';
import { ManageServiceFormDetailService } from './manage-service-form-detail.service';

describe('ManageServiceFormDetailService', () => {
  let service: ManageServiceFormDetailService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ManageServiceFormDetailService],
    }).compile();

    service = module.get<ManageServiceFormDetailService>(ManageServiceFormDetailService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
