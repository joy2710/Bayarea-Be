import { CreateManageServiceFormDetailDto } from './create-manage-service-form-detail.dto';

export class UpdateManageServiceFormDetailDto extends CreateManageServiceFormDetailDto {}
