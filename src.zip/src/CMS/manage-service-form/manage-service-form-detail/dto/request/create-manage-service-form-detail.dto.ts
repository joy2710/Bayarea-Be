import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsEnum, IsNotEmpty, IsOptional, IsString } from "class-validator";
import { AnswerType } from "../../entities/answer-type.enum";

export class CreateManageServiceFormDetailDto {
 

    @ApiProperty()
    @IsOptional()
    serviceFormId: number;

    @ApiProperty()
    @IsOptional()
    title: string;

    @ApiProperty()
    @IsOptional()
    question: string;

    @ApiProperty()
    @IsOptional()
    answer: string;

    @ApiProperty()
    @IsOptional()
    insertNote: string;

    @ApiProperty({default: AnswerType.TEXT})
    @IsNotEmpty()
    @IsEnum(AnswerType)
    answerType: AnswerType;

    @ApiProperty({example: ["string"], isArray: true})
    @IsString({ each: true })
    @IsOptional()
    value: string[];

    @ApiProperty()
    @IsOptional()
    groupName: string;

    @ApiProperty()
    @IsBoolean()
    required: true;

    @ApiProperty()
    @IsOptional()
    sequenceNumber: number;

    @ApiProperty()
    @IsOptional()
    serialNo: number
}
