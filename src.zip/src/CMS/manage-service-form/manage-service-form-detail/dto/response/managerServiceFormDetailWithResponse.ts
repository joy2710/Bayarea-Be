import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { ManageServiceFormDetailResponse } from "./manager-service-from-detail-response";


export class ManageServiceFormDetailWithMessageResponse {
    @ApiProperty({
      name: 'Message',
      description: 'Specifies a response message',
      example: 'Process Successful',
    })
  
    @Expose()
    message: string;
  
    @ApiProperty({
      name: 'Data',
      description: 'Specifies response data',
    })
  
    @Expose()
    data?: ManageServiceFormDetailResponse | ManageServiceFormDetailResponse[];
  
    constructor(message: string, data: ManageServiceFormDetailResponse | ManageServiceFormDetailResponse[]) {
      this.data = data;
      this.message = message;
    }
  }