import { Module } from '@nestjs/common';
import { ManageServiceFormDetailService } from './manage-service-form-detail.service';
import { ManageServiceFormDetailController } from './manage-service-form-detail.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManageServiceFormDetail } from './entities/manage-service-form-detail.entity';
import { ManagerServiceForm } from '../manager-service-form/entities/manager-service-form.entity';
import { ManageServiceFormGroupName } from '../manage-service-form-group-name/entities/manage-service-form-group-name.entity';
import { ManageServiceFormGroupNameService } from '../manage-service-form-group-name/manage-service-form-group-name.service';

@Module({
  imports: [TypeOrmModule.forFeature([ManageServiceFormDetail, ManagerServiceForm,ManageServiceFormGroupName])],
  controllers: [ManageServiceFormDetailController],
  providers: [ManageServiceFormDetailService,ManageServiceFormGroupNameService]
})
export class ManageServiceFormDetailModule {}
