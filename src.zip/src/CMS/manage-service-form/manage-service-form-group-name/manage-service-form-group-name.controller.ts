import { Controller, Get, Post, Body, Param, Delete, UseGuards } from '@nestjs/common';
import { ManageServiceFormGroupNameService } from './manage-service-form-group-name.service';
import { UpdateManageServiceFormGroupNameDto } from './dto/request/update-manage-service-form-group-name.dto';
import { CreateManageServiceFormGroupNameDto } from './dto/request/create-manage-service-form-group-name.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ManageServiceFormGroupNameParentRoute, ManageServiceFormGroupNameRoutes } from './manage-service-form-group-name-http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Manage-Service-Form-Group-Name')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:ManageServiceFormGroupNameParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)


export class ManageServiceFormGroupNameController {
  constructor(private readonly manageServiceFormGroupNameService: ManageServiceFormGroupNameService) {}

  @Post()
  create(@Body() createManageServiceFormGroupNameDto: CreateManageServiceFormGroupNameDto) {
    return this.manageServiceFormGroupNameService.create(createManageServiceFormGroupNameDto);
  }

  @Get(ManageServiceFormGroupNameRoutes.view_all)
  findAll() {
    return this.manageServiceFormGroupNameService.findAll();
  }

  @Get(ManageServiceFormGroupNameRoutes.view_one)
  findOne(@Param('manageServiceFormGroupNameId') id: string) {
    return this.manageServiceFormGroupNameService.findOne(+id);
  }

  @Post(ManageServiceFormGroupNameRoutes.update)
  update(@Param('manageServiceFormGroupNameId') id: string, @Body() updateManageServiceFormGroupNameDto: UpdateManageServiceFormGroupNameDto) {
    return this.manageServiceFormGroupNameService.update(+id, updateManageServiceFormGroupNameDto);
  }

  @Delete(ManageServiceFormGroupNameRoutes.delete)
  remove(@Param('manageServiceFormGroupNameId') id: string) {
    return this.manageServiceFormGroupNameService.remove(+id);
  }


  @Get(ManageServiceFormGroupNameRoutes.get_Group_List_By_ServiceFormId)
  async getGroupListByServiceFormId(@Param('serviceFormId') serviceFormId: Number) {
    return this.manageServiceFormGroupNameService.getGroupListByServiceFormId(+serviceFormId);
  }
}
