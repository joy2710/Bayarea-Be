import { Test, TestingModule } from '@nestjs/testing';
import { ManageServiceFormGroupNameController } from './manage-service-form-group-name.controller';
import { ManageServiceFormGroupNameService } from './manage-service-form-group-name.service';

describe('ManageServiceFormGroupNameController', () => {
  let controller: ManageServiceFormGroupNameController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ManageServiceFormGroupNameController],
      providers: [ManageServiceFormGroupNameService],
    }).compile();

    controller = module.get<ManageServiceFormGroupNameController>(ManageServiceFormGroupNameController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
