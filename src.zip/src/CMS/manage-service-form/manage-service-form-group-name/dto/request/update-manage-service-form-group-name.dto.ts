import { CreateManageServiceFormGroupNameDto } from './create-manage-service-form-group-name.dto';

export class UpdateManageServiceFormGroupNameDto extends CreateManageServiceFormGroupNameDto {}
