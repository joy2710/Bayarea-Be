import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { ManageServiceStatuStatus } from "src/CMS/manage-service-form/manager-service-form/entities/status.enum";

export class CreateManageServiceFormGroupNameDto {

    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty()
    @IsNotEmpty()
    serviceFormId: Number;

    @ApiProperty({ default: ManageServiceStatuStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(ManageServiceStatuStatus)
    status: ManageServiceStatuStatus;  
}
