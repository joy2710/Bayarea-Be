import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { ManageSeriveFormGroupNameResponse } from "./manager-service-from-group-name-response";



export class ManageServiceFormGroupNameWithMessageResponse {
    @ApiProperty({
      name: 'Message',
      example: 'Process Successful',
    })
  
    @Expose()
    message: string;
  
    @ApiProperty({
      name: 'Data',
    })
  
    @Expose()
    data?: ManageSeriveFormGroupNameResponse | ManageSeriveFormGroupNameResponse[];
  
    constructor(message: string, data: ManageSeriveFormGroupNameResponse | ManageSeriveFormGroupNameResponse[]) {
      this.data = data;
      this.message = message;
    }
  }