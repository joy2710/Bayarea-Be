import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { TransformDateToEpoch } from "src/common/helpers/decorators/transformDateToEpoch";

export class ManageSeriveFormGroupNameResponse {
    @ApiProperty()
    @Expose()
    id: number;
  
    @ApiProperty()
    @Expose()
    name: string;

    @ApiProperty()
    @Expose()
    serviceFormId: Number;
  
    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    createdDate?: Date;
  
    @ApiProperty()
    @Expose()
    createdBy?: number;
  
    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    updatedDate?: Date;
  
    @ApiProperty()
    @Expose()
    updatedBy?: string;
  } 
  