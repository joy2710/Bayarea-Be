export const ManageServiceFormGroupNameParentRoute = 'manage-service-form-group-name';

export const ManageServiceFormGroupNameRoutes = {
  create: '',
  update: 'update/:manageServiceFormGroupNameId',
  delete: ':manageServiceFormGroupNameId',
  view_one: ':manageServiceFormGroupNameId',
  view_all: '',
  get_Group_List_By_ServiceFormId:'getGroupListByServiceFormID/:serviceFormId'
  
 
};