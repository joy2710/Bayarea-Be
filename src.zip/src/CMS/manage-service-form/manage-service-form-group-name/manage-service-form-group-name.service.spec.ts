import { Test, TestingModule } from '@nestjs/testing';
import { ManageServiceFormGroupNameService } from './manage-service-form-group-name.service';

describe('ManageServiceFormGroupNameService', () => {
  let service: ManageServiceFormGroupNameService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ManageServiceFormGroupNameService],
    }).compile();

    service = module.get<ManageServiceFormGroupNameService>(ManageServiceFormGroupNameService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
