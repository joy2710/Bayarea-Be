import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';

import { UpdateManageServiceFormGroupNameDto } from './dto/request/update-manage-service-form-group-name.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ManageServiceFormGroupName } from './entities/manage-service-form-group-name.entity';
import { Repository } from 'typeorm';
import { ManageServiceFormGroupNameWithMessageResponse } from './dto/response/managerServiceFormGroupNameWithResponse';
import { Messages } from 'src/common/constants/messages';

@Injectable()
export class ManageServiceFormGroupNameService {

  constructor(
    @InjectRepository(ManageServiceFormGroupName) private manageServiceFormGroupNameRepository: Repository<ManageServiceFormGroupName>,
  ) {}

  async create(createManageServiceFormGroupNameDto: UpdateManageServiceFormGroupNameDto):Promise<ManageServiceFormGroupNameWithMessageResponse>   {
    const  managerServiceFormGroupName = await this.manageServiceFormGroupNameRepository.create(createManageServiceFormGroupNameDto);
    const result = await this.manageServiceFormGroupNameRepository.save(managerServiceFormGroupName);
    if(result){
     return {
       message: `${Messages.Resource.Created} : Manage-service-form-group-name`,
       data: result
     }
    }
  }

  async findAll():Promise<ManageServiceFormGroupNameWithMessageResponse> {
    const  result = await this.manageServiceFormGroupNameRepository.find()
   if(result){
    return {
      message: `${Messages.Resource.Found} : Manage-service-form-group-name`,
      data: result
    }
   }
  }

 async findOne(manageServiceFormGroupNameId: number):Promise<ManageServiceFormGroupNameWithMessageResponse> {
  try {
    const result = await this.manageServiceFormGroupNameRepository.findOne(
      {
        where:
          { id: manageServiceFormGroupNameId }
      }
    );
    if (!result)
      throw new HttpException(`${Messages.Resource.NotFound}: Manage-service-form-group-name`, HttpStatus.NOT_FOUND);
    return {
      message: `${Messages.Resource.Found} : Manage-service-form-group-name`,
      data: result
    }
  } catch (error) {
    throw error;
  }
  }

  async update(manageServiceFormGroupNameId: number, updateManageServiceFormGroupNameDto: UpdateManageServiceFormGroupNameDto) {
    const data = await this.manageServiceFormGroupNameRepository.findOne(manageServiceFormGroupNameId);
    if(!data){
      throw new HttpException(`${Messages.Resource.NotFound} : Manage-service-form-group-name`, HttpStatus.NOT_FOUND);
    }
    await this.manageServiceFormGroupNameRepository.update(manageServiceFormGroupNameId, updateManageServiceFormGroupNameDto)
    return {
      message: `${Messages.Resource.Updated} : Manage-service-form-group-name`,
    }
  }

 async remove(manageServiceFormGroupNameId: number):Promise<ManageServiceFormGroupNameWithMessageResponse> {
    try {
      const deletemanageServiceForm = await this.manageServiceFormGroupNameRepository.delete(manageServiceFormGroupNameId);
      if (deletemanageServiceForm.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Manage-service-form-group-name`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async getGroupListByServiceFormId(serviceFormId: number) {
    const result = await this.manageServiceFormGroupNameRepository.find({where: {serviceFormId: serviceFormId}});
    if(result){
      return {
        message: `${Messages.Resource.Created} : Manage-service-form-group-name`,
        data: result
      }
     }

  }


}
