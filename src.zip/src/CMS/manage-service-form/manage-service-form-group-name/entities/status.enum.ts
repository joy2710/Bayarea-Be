export enum ManageServiceFormStatusStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}