import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { ManageServiceStatuStatus } from "../../manager-service-form/entities/status.enum";
import { ManagerServiceForm } from "../../manager-service-form/entities/manager-service-form.entity";


@Entity({ name: 'manage-service-form-group-name' }) 
export class ManageServiceFormGroupName {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    serviceFormId: Number;

    @Column({ default: ManageServiceStatuStatus.INACTIVE })
    status: ManageServiceStatuStatus;
    
    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @ManyToOne(() => ManagerServiceForm, (managerServiceForm: ManagerServiceForm) => managerServiceForm.manageServiceFormGroupName,
    {
        eager: false,
        onDelete: 'CASCADE'
    })
    serviceForm: ManagerServiceForm[];
    
}

