import { Module } from '@nestjs/common';
import { ManageServiceFormGroupNameService } from './manage-service-form-group-name.service';
import { ManageServiceFormGroupNameController } from './manage-service-form-group-name.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManageServiceFormGroupName } from './entities/manage-service-form-group-name.entity';

@Module({
  imports:[TypeOrmModule.forFeature([ManageServiceFormGroupName])],
  controllers: [ManageServiceFormGroupNameController],
  providers: [ManageServiceFormGroupNameService]
})
export class ManageServiceFormGroupNameModule {}
