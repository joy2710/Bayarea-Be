import { Module } from '@nestjs/common';
import { ClientBillingContactService } from './client-billing-contact.service';
import { ClientBillingContactController } from './client-billing-contact.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ClientBillingContact } from './entities/client-billing-contact.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ClientBillingContact])],
  controllers: [ClientBillingContactController],
  providers: [ClientBillingContactService]
})
export class ClientBillingContactModule {}
