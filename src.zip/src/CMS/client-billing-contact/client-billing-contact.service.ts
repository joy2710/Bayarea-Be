import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateClientBillingContactDto } from './dto/request/create-client-billing-contact.dto';
import { UpdateClientBillingContactDto } from './dto/request/update-client-billing-contact.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ClientBillingContact } from './entities/client-billing-contact.entity';
import { Repository } from 'typeorm';
import { ClientBillingContactWithMessageResponse } from './dto/response/clientBillingContactWithResponce';
import { Messages } from 'src/common/constants/messages';


@Injectable()
export class ClientBillingContactService {
  constructor(
    @InjectRepository(ClientBillingContact) private clientBillingContactRepository: Repository<ClientBillingContact>,

  ) { }

  async create(createClientBillingContactDto: CreateClientBillingContactDto):Promise<ClientBillingContactWithMessageResponse> {
    const clientBillingContact = await this.clientBillingContactRepository.create(createClientBillingContactDto);
    const result = await this.clientBillingContactRepository.save(clientBillingContact)
      return {
        message: `${Messages.Resource.Created} : Client Billing Contact`,
        data: result
    }
  }


async findAll():Promise<ClientBillingContactWithMessageResponse> {
    const result = await this.clientBillingContactRepository.find()
    if (result) {
      return {
        message: `${Messages.Resource.Found}: Client Billing Contact`,
        data: result
      }
    }
  }
  
  async findOne(id: number):Promise<ClientBillingContactWithMessageResponse> {
    try {
      const result = await this.clientBillingContactRepository.findOne(
        {
          where:
            { id: id }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}:Client Billing Contact`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Client Billing Contact`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }
  

  async update(id: number, updateClientBillingContactnDto: UpdateClientBillingContactDto):Promise<ClientBillingContactWithMessageResponse> {
    const data = await this.clientBillingContactRepository.findOne(id);

    if (!data) {
      throw new HttpException(`Client Billing Contact not exist`, HttpStatus.NOT_FOUND);
    }
    await this.clientBillingContactRepository.update(id, updateClientBillingContactnDto)
    return {
      message: `${Messages.Resource.Updated} : Client Billing Contact`,
    }
  }



 async remove(id: number):Promise<ClientBillingContactWithMessageResponse> {
    try {
      const deleteClientBillingContact = await this.clientBillingContactRepository.delete(id);
      if (deleteClientBillingContact.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted}: Client Billing Contact`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async getClientBillingContactByClientId(clientId: number){
    try {
      const result = await this.clientBillingContactRepository.find({
        where: { clientId:  clientId}
      });

      if (result && result.length >= 0) {
        return {
          message: `${Messages.Resource.Found} : Client Billing Contact`,
          data: result
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async getClientBillingContactByOrderId(orderId: number){
    try {
      const result = await this.clientBillingContactRepository.find({
        where: { orderId:  orderId}
      });

      if (result && result.length >= 0) {
        return {
          message: `${Messages.Resource.Found} : Client Billing Contact`,
          data: result
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
