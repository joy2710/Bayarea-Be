import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ClientBillingContactService } from './client-billing-contact.service';
import { CreateClientBillingContactDto } from './dto/request/create-client-billing-contact.dto';
import { UpdateClientBillingContactDto } from './dto/request/update-client-billing-contact.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ClientBillingContactRoute, ClientBillingContactRoutes } from './client-billing-contact.http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('client-billing-contact')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Public()
@Controller({ path:ClientBillingContactRoute})
export class ClientBillingContactController {
  constructor(private readonly clientBillingContactService: ClientBillingContactService) {}

  @Post(ClientBillingContactRoutes.create)
  create(@Body() createClientBillingContactDto: CreateClientBillingContactDto) {
    return this.clientBillingContactService.create(createClientBillingContactDto);
  }

  @Get(ClientBillingContactRoutes.view_all)
  findAll() {
    return this.clientBillingContactService.findAll();
  }

  @Get(ClientBillingContactRoutes.view_one)
  findOne(@Param('id') id: string) {
    return this.clientBillingContactService.findOne(+id);
  }

  @Post(ClientBillingContactRoutes.update)
  update(@Param('id') id: string, @Body() updateClientBillingContactDto: UpdateClientBillingContactDto) {
    return this.clientBillingContactService.update(+id, updateClientBillingContactDto);
  }

  @Delete(ClientBillingContactRoutes.delete)
  remove(@Param('id') id: string) {
    return this.clientBillingContactService.remove(+id);
  }

  @Get(ClientBillingContactRoutes.getByClientId)
  getClientBillingContactByClientId(@Param('clientId') clientId:number) {
    return this.clientBillingContactService.getClientBillingContactByClientId(+clientId)
  }

  @Get(ClientBillingContactRoutes.getByOrderId)
  getClientBillingContactByOrderId(@Param('orderId') orderId:number) {
    return this.clientBillingContactService.getClientBillingContactByOrderId(+orderId)
  }

}
