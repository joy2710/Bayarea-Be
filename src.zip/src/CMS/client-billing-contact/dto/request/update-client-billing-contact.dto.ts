import { PartialType } from '@nestjs/mapped-types';
import { CreateClientBillingContactDto } from './create-client-billing-contact.dto';

export class UpdateClientBillingContactDto extends PartialType(CreateClientBillingContactDto) {}
