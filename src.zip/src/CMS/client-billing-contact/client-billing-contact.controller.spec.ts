import { Test, TestingModule } from '@nestjs/testing';
import { ClientBillingContactController } from './client-billing-contact.controller';
import { ClientBillingContactService } from './client-billing-contact.service';

describe('ClientBillingContactController', () => {
  let controller: ClientBillingContactController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ClientBillingContactController],
      providers: [ClientBillingContactService],
    }).compile();

    controller = module.get<ClientBillingContactController>(ClientBillingContactController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
