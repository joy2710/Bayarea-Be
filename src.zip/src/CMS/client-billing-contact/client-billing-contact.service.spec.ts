import { Test, TestingModule } from '@nestjs/testing';
import { ClientBillingContactService } from './client-billing-contact.service';

describe('ClientBillingContactService', () => {
  let service: ClientBillingContactService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ClientBillingContactService],
    }).compile();

    service = module.get<ClientBillingContactService>(ClientBillingContactService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
