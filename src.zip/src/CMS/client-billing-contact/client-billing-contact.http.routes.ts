export const ClientBillingContactRoute = 'client-billing-contact';

export const ClientBillingContactRoutes = {
  create: '',
  update: 'update/:id',
  delete: ':id',
  view_one: ':id',
  view_all: '',
  getByClientId : 'getByClientId/:clientId',
  getByOrderId : 'getByOrderId/:orderId'
};