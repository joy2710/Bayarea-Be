import { Order } from "src/CMS/order/entities/order.entity";
import { Column, CreateDateColumn, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity({ name: 'client-billing-contact' })
export class ClientBillingContact {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName?: string;
  
    @Column()
    lastName?: string;
  
    @Column()
    middleName?: string;
  
    @Column()
    email?: string;
  
    @Column()
    clientId?: number;
  
    @Column()
    phone?: number;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column()
    orderId?: number;

    @OneToOne(() => Order, (order) => order.clientBillingContact)
    @JoinColumn()
    order: Order;
}
