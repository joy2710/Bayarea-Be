import { Module } from '@nestjs/common';
import { GlobalInstructionService } from './global-instruction.service';
import { GlobalInstructionController } from './global-instruction.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GlobalInstruction } from './entities/global-instruction.entity';

@Module({
  imports: [TypeOrmModule.forFeature([GlobalInstruction])],
  controllers: [GlobalInstructionController],
  providers: [GlobalInstructionService]
})
export class GlobalInstructionModule {}
