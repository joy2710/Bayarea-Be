import { Test, TestingModule } from '@nestjs/testing';
import { GlobalInstructionController } from './global-instruction.controller';
import { GlobalInstructionService } from './global-instruction.service';

describe('GlobalInstructionController', () => {
  let controller: GlobalInstructionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GlobalInstructionController],
      providers: [GlobalInstructionService],
    }).compile();

    controller = module.get<GlobalInstructionController>(GlobalInstructionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
