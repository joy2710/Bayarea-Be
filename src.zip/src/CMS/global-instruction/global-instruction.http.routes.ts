export const GlobalInstructionRoute = 'globalInstruction';

export const GlobalInstructionRoutes = {
  create: '',
  update: 'update/:globalInstructionId',
  delete: ':globalInstructionId',
  view_one: ':globalInstructionId',
  view_all: '',
  get_instruction_by_keys: 'instruction/byKeys',
};
