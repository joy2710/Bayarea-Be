import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { GlobalInstructionWithMessageResponse } from './dto/response/globalInstructionWithResponse';
import { Messages } from 'src/common/constants/messages';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { GlobalInstruction } from './entities/global-instruction.entity';
import { CreateGlobalInstructionDto } from './dto/request/create-global-instruction.dto';
import { In } from 'typeorm';

@Injectable()
export class GlobalInstructionService {
  constructor(
    @InjectRepository(GlobalInstruction) private globalInstructionRepository: Repository<GlobalInstruction>
  ) { }

  async create(request: CreateGlobalInstructionDto): Promise<GlobalInstructionWithMessageResponse> {
    const globalInstruction = await this.globalInstructionRepository.create(request);
    const result = await this.globalInstructionRepository.save(globalInstruction);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Global-Instruction`,
        data: result
      }
    }
  }
  async findAll(): Promise<GlobalInstructionWithMessageResponse> {
    const result = await this.globalInstructionRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Global-Instruction`,
        data: result
      }
    }
  }
 
  async findOne(globalInstructionId: number): Promise<GlobalInstructionWithMessageResponse> {
    try {
      const result = await this.globalInstructionRepository.findOne(
        {
          where:
            { id: globalInstructionId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Global-Instruction`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Global-Instruction`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

 
  async update(globalInstructionId: number, request: CreateGlobalInstructionDto): Promise<GlobalInstructionWithMessageResponse> {
    const data = await this.globalInstructionRepository.findOne(globalInstructionId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Global-Instruction`, HttpStatus.NOT_FOUND);
    }
    await this.globalInstructionRepository.update(globalInstructionId, request)
    return {
      message: `${Messages.Resource.Updated} : Global-Instruction`,
    }

  }

  async remove(globalInstructionId: number): Promise<GlobalInstructionWithMessageResponse> {
    try {
      const deleteGlobalInstruction = await this.globalInstructionRepository.delete(globalInstructionId)
      if (deleteGlobalInstruction.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Global-Instruction`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async getInstructionsByKeys(keys:any): Promise<GlobalInstructionWithMessageResponse> {
    const result = await this.globalInstructionRepository.find({ where: { instructionLabelKey: In(keys) } });
  
    if (result.length > 0) {
      return {
        message: `${Messages.Resource.Found} : Global-Instruction`,
        data: result
      };
    } else {
      return {
        message: `${Messages.Resource.NotFound} : Global-Instruction`,
        data: []
      };
    }
  }
}
