import { Test, TestingModule } from '@nestjs/testing';
import { GlobalInstructionService } from './global-instruction.service';

describe('GlobalInstructionService', () => {
  let service: GlobalInstructionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [GlobalInstructionService],
    }).compile();

    service = module.get<GlobalInstructionService>(GlobalInstructionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
