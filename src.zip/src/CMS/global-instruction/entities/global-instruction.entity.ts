import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity({name: 'global-instruction'})
export class GlobalInstruction {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    instructionLabelKey: string;

    @Column()
    description: string

    @Column({type: 'longtext'})
    content: string;

    @Column({ default:true })
    status: boolean;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;
}
