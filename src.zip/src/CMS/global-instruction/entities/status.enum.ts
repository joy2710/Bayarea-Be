export enum GlobalInstructionStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}