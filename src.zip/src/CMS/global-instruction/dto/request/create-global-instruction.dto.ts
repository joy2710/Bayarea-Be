import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsOptional } from "class-validator";

export class InstructionKeysDto {
    @ApiProperty()
    keys: string;
}

export class CreateGlobalInstructionDto {
    @ApiProperty()
    @IsOptional()
    instructionLabelKey: string;

    @ApiProperty()
    @IsOptional()
    description: string

    @ApiProperty()
    @IsOptional()
    content: string;

    @ApiProperty({ default: true})
    @IsOptional()
    status: boolean;;
 
}
