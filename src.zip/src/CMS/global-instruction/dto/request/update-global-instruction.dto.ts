import { PartialType } from '@nestjs/mapped-types';
import { CreateGlobalInstructionDto } from './create-global-instruction.dto';

export class UpdateGlobalInstructionDto extends CreateGlobalInstructionDto {}
