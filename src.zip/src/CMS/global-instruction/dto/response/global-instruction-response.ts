import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
export class GlobalInstructionResponse {

  @ApiProperty()
  @Expose()
  id:number;

  
  @ApiProperty()
  @Expose()
  description: string

  @ApiProperty()
  @Expose()
  instructionLabelKey?:string;

  @ApiProperty()
  @Expose()
  content?:string;
 
  @ApiProperty()
  @Expose()
  status?:boolean
  
}
