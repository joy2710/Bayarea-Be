import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { GlobalInstructionResponse } from './global-instruction-response';



export class GlobalInstructionWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: GlobalInstructionResponse | GlobalInstructionResponse[];

  constructor(message: string, data: GlobalInstructionResponse | GlobalInstructionResponse[]) {
    this.data = data;
    this.message = message;
  }
}
