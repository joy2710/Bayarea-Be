import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Query } from '@nestjs/common';
import { GlobalInstructionService } from './global-instruction.service';
import { CreateGlobalInstructionDto, InstructionKeysDto } from './dto/request/create-global-instruction.dto';
import { GlobalInstructionRoute, GlobalInstructionRoutes } from './global-instruction.http.routes';
import { Public } from 'src/auth/constants';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Global-Instruction')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:GlobalInstructionRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
export class GlobalInstructionController {
  constructor(private readonly globalInstructionService: GlobalInstructionService) {}

  @Post(GlobalInstructionRoutes.create)
  create(@Body() createFooterDto: CreateGlobalInstructionDto) {
    return this.globalInstructionService.create(createFooterDto);
  }

  @Public()
  @Get(GlobalInstructionRoutes.view_all)
  findAll() {
    return this.globalInstructionService.findAll();
  }

  @Public()
  @Get(GlobalInstructionRoutes.view_one)
  findOne(@Param('globalInstructionId') id: string) {
    return this.globalInstructionService.findOne(+id);
  }

  @Post(GlobalInstructionRoutes.update)
  update(@Param('globalInstructionId') id: number, @Body() updateGlobalInstructionDto: CreateGlobalInstructionDto) {
    return this.globalInstructionService.update(+id, updateGlobalInstructionDto);
  }

  @Delete(GlobalInstructionRoutes.delete)
  remove(@Param('globalInstructionId') id: number) {
    return this.globalInstructionService.remove(+id);
  }

  @Public()
  @Post(GlobalInstructionRoutes.get_instruction_by_keys)
  async getInstructionsByKeys(@Body() instructionKeysDto: InstructionKeysDto): Promise<{ message: string; data: any }> {
    const keysArray = instructionKeysDto.keys.split(',');
    const response = await this.globalInstructionService.getInstructionsByKeys(keysArray);
    return {
      message: response.message,
      data: response.data,
    };
  }
}
