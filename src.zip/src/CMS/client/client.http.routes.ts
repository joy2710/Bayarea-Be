export const ClientParentRoute = 'client';

export const ClientRoutes = {
  create: '',
  update: 'update/:clientId',
  delete: ':clientId',
  view_one: ':clientId',
  view_all: '',
  change_password: 'changePassword',
  find_client_details: 'findClientDetails/detail',
  find_client_order_details_by_case: 'findClientOrderDetailsByCase/case',
  find_client_dashboard_details_by_client_id: 'findClientDashboardDetailsByCLientId/:clientId',
  update_all_clients:'updateClient',
  get_baseCase_List_By_ClientId:'getBaseCaseListByClientId/:clientId',
  get_service_agreement_By_clientId:'getServiceAgreementByClientId/:clientId',
  get_assignee_agreement_By_clientId:'getAssigneeAgreementByClientId/:clientId'
};
