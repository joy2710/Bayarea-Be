import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ClientResponse } from './client-response';

export class ClientWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: ClientResponse | ClientResponse[];

  constructor(message: string, data: ClientResponse | ClientResponse[]) {
    this.data = data;
    this.message = message;
  }
}
