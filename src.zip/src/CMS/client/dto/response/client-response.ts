import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ClientStatus } from 'src/CMS/client/entities/status.enum';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';

export class ClientResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  firstName: string;

  @ApiProperty()
  @Expose()
  lastName: string;

  @ApiProperty()
  @Expose()
  middleName: string;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  clientType?: string[];

  @ApiProperty()
  @Expose()
  phone: string;

  @ApiProperty()
  @Expose()
  landLinePhone: number;

  @ApiProperty()
  @Expose()
  workPhone: number;

  @ApiProperty()
  @Expose()
  password: string;

  @ApiProperty()
  @Expose()
  notes: string;

  @ApiProperty()
  @Expose()
  street: string;

  @ApiProperty()
  @Expose()
  apartment: string;

  @ApiProperty()
  @Expose()
  city: string;

  @ApiProperty()
  @Expose()
  state: string;

  @ApiProperty()
  @Expose()
  state1: string;

  @ApiProperty()
  @Expose()
  country: string;

  @ApiProperty()
  @Expose()
  zipcode: string;

  @ApiProperty()
  @Expose()
  otherDataValue: string;

  @ApiProperty({ example: ClientStatus })
  @Expose()
  status: ClientStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdBy?: number;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedBy?: string;

  @ApiProperty()
  @Expose()
  isExisting: boolean;

  @ApiProperty()
  @Expose()
  secondaryEmail: string;

  @ApiProperty()
  @Expose()
  isApprove: boolean;

  @ApiProperty()
  @Expose()
  isdisableClient: boolean;

  @ApiProperty()
  @Expose()
  alternateEmail: string;

  @ApiProperty()
  @Expose()
  clientRootPath: string;

  @ApiProperty()
  @Expose()
  parentClientId: number;

  @ApiProperty()
  @Expose()
  isArchiveClient: boolean;

  @ApiProperty()
  @Expose()
  isDeleteClient: boolean;

  @ApiProperty()
  @Expose()
  pocSecondaryEmail: string;

  @ApiProperty()
  @Expose()
  isPermitInvoicing: boolean

  @ApiProperty()
  @Expose()
  invoicingDueDate: number

  @ApiProperty()
  @Expose()
  company?: string;

  @ApiProperty()
  @Expose()
  isPaymentReminder: boolean;

  @ApiProperty()
  @Expose()
  isAdminIntakeReminder: boolean;

  @ApiProperty()
  @Expose()
  isAgreementReminder: boolean;

  @ApiProperty()
  @Expose()
  isServiceFormReminder: boolean;

  @ApiProperty()
  @Expose()
  isUploadDocReminder: boolean;

  @ApiProperty()
  @Expose()
  isValidateDocReminder: boolean;
}
