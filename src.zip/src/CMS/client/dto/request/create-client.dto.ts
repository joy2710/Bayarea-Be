import { ApiProperty } from "@nestjs/swagger"
import { IsBoolean, IsEmail, IsEnum, IsNotEmpty, IsOptional, IsString } from "class-validator"
import { ClientStatus } from "../../entities/status.enum";

export class CreateClientDto {
    @ApiProperty()
    @IsOptional()
    firstName?: string;

    @ApiProperty()
    @IsOptional()
    lastName?: string;

    @ApiProperty()
    @IsOptional()
    middleName?: string;

    @ApiProperty()
    @IsOptional()
    email?: string;

    @ApiProperty({example: ["string"], isArray: true})
    @IsString({ each: true })
    @IsOptional()
    clientType?: string[];

    @ApiProperty()
    @IsOptional()
    phone?: string;

    @ApiProperty({ default:null })
    @IsOptional()
    landLinePhone?: number;

    @ApiProperty({ default:null })
    @IsOptional()
    workPhone?: number;

    @ApiProperty()
    @IsOptional()
    password?: string;

    @ApiProperty({ default:null })
    @IsOptional()
    notes?: string;

    @ApiProperty()
    @IsOptional()
    street?: string;

    @ApiProperty()
    @IsOptional()
    apartment?: string;

    @ApiProperty()
    @IsOptional()
    city?: string;

    @ApiProperty()
    state?: string;

    @ApiProperty()
    state1?: string;

    @ApiProperty()
    @IsOptional()
    country?: string;

    @ApiProperty()
    @IsOptional()
    zipcode?: string;

    @ApiProperty()
    @IsOptional()
    otherDataValue?: string;
    
    @ApiProperty({ default: ClientStatus.ACTIVE })
    @IsNotEmpty()
    @IsEnum(ClientStatus)
    status?: ClientStatus;
    
    @ApiProperty()
    @IsOptional()
    isExisting?: boolean;

    @ApiProperty()
    @IsOptional()
    secondaryEmail?: string;

    @ApiProperty({ default:false})
    @IsOptional()
    isApprove?: boolean;
    
    @ApiProperty()
    @IsOptional()
    isdisableClient?: boolean;

    @ApiProperty()
    @IsOptional()
    alternateEmail?:string;

    @ApiProperty()
    @IsOptional()
    clientRootPath:string;

    @ApiProperty()
    @IsOptional()
    parentClientId:number;

    @ApiProperty({ default:false})
    @IsOptional()
    isArchiveClient?: boolean;

    @ApiProperty({ default:false})
    @IsOptional()
    isDeleteClient?: boolean;

    @ApiProperty()
    @IsOptional()
    pocSecondaryEmail?: string;

    @ApiProperty({ default:false})
    @IsOptional()
    isPermitInvoicing?: boolean;
    
    @ApiProperty()
    @IsOptional()
    invoicingDueDate?: number

    @ApiProperty()
    @IsOptional()
    company?: string;

    @ApiProperty({ default:true})
    @IsOptional()
    isPaymentReminder?: boolean;

    @ApiProperty({ default:true})
    @IsOptional()
    isAdminIntakeReminder?: boolean;

    @ApiProperty({ default:true})
    @IsOptional()
    isAgreementReminder?: boolean;

    @ApiProperty({ default:true})
    @IsOptional()
    isServiceFormReminder?: boolean;

    @ApiProperty({ default:true})
    @IsOptional()
    isUploadDocReminder?: boolean;

    @ApiProperty({ default:true})
    @IsOptional()
    isValidateDocReminder ?: boolean;
}
