import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional } from "class-validator";

export class ChangePasswordDto {
    @ApiProperty()
    @IsNotEmpty()
    id?: number;
  
    @ApiProperty()
    @IsOptional()
    oldPassword?: string;
  
    @ApiProperty()
    @IsNotEmpty()
    newPassword?: string;
}