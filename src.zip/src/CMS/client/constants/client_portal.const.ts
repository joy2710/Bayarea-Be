export const ClientDashboard = [
    {
        'id': 1,
        'task_name': 'Honored Payment',
        'action': 'Click here to complete task',
        'instruction': 'Instruction',
        'status': 'Pending Client',
        'status_date': '2023-01-01',
        'url': '/client/orderPayment'
    },
    {
        'id': 2,
        'task_name': 'Admin Intake Forms',
        'action': 'Click here to complete task',
        'instruction': 'Instruction',
        'status': 'Pending Client',
        'status_date': '2023-01-01',
        'url': '/client/order'
    },
    {
        'id': 3,
        'task_name': 'Service Agreement',
        'action': 'Click here to complete task',
        'instruction': 'Instruction',
        'status': 'Pending Client',
        'status_date': '2023-01-01',
        'url': '/client/service-agreement'
    },
    {
        'id': 4,
        'task_name': 'Service Intake Forms',
        'action': 'Click here for order list',
        'instruction': 'Instruction',
        'status': 'Pending Client',
        'status_date': '2023-01-01',
        'url':'/client/case-list/'
    }
    ,
    {
        'id': 5,
        'task_name': 'Upload Disclosure Documents',
        'action': 'Click here to Upload Disclosure Documents',
        'instruction': 'Instruction',
        'status': 'Pending Client',
        'status_date': '2023-01-01',
        'url':'/client/document/'
    },
    {
        'id': 6,
        'task_name': 'Validate Disclosure Documents',
        'action': 'Click here to Validate Disclosure Documents',
        'instruction': 'Instruction',
        'status': 'Pending Client',
        'status_date': '2023-01-01',
        'url':'/client/document-validation/'
    }
]