import { Module, forwardRef } from '@nestjs/common';
import { ClientService } from './client.service';
import { ClientController } from './client.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Client } from './entities/client.entity';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { EventLogService } from '../event-log/event-log.service';
import { EventLog } from '../event-log/entities/event-log.entity';
import { Order } from '../order/entities/order.entity';
import { OrderModule } from '../order/order.module';
import { Cases } from '../cases/entities/cases.entity';
import { TaskInstruction } from '../task-instruction/entities/task-instruction.entity';
import { Setting } from '../setting/entities/setting.entity';
import { OrderPayment } from '../order-payment/entities/order-payment.entity';
import { OrderInventorsService } from '../order-inventors/order-inventors.service';
import { OrderInventor } from '../order-inventors/entities/order-inventor.entity';
import { OrderAssigneeDocumentService } from '../order-assignee-document/order-assignee-document.service';
import { OrderAssigneeDocument } from '../order-assignee-document/entities/order-assignee-document.entity';
import { CaseFile } from '../case-file/entities/case-file.entity';
import { CaseFileService } from '../case-file/case-file.service';
import { Folder } from '../folder/entities/folder.entity';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { CaseFileModule } from '../case-file/case-file.module';
import { ConfigService } from '@nestjs/config';


@Module({
  imports:[TypeOrmModule.forFeature([Client,OrderPayment,ProductOrderDetailForm, EventLog,OrderInventor,OrderAssigneeDocument,Folder, Order, Cases, TaskInstruction,Setting]),forwardRef(() => CaseFileModule)],
  controllers: [ClientController],
  providers: [ClientService,MailService, EventLogService,OrderInventorsService,OrderAssigneeDocumentService,ConfigService],
  exports: [ClientService, MailService, EventLogService,OrderInventorsService,OrderAssigneeDocumentService]
})
export class ClientModule {}
