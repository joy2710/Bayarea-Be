import { Controller, Get, Post, Body, Param, Delete, UseGuards, Req, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { ClientParentRoute, ClientRoutes } from './client.http.routes';
import { ClientService } from './client.service';
import { CreateClientDto } from './dto/request/create-client.dto';
import { UpdateClientDto } from './dto/request/update-client.dto';
import { ChangePasswordDto } from './dto/request/change-password-dto';
import { Public } from 'src/auth/constants';


/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Client')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: ClientParentRoute })
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class ClientController {
  constructor(private readonly clientService: ClientService) { }

  @Post(ClientRoutes.create)
  async createClient(@Body() body: CreateClientDto, @Req() req: any) {
    let userDetail = req.headers['userdetail'];
    let userdetailid = req.headers['userdetailid'];
    return this.clientService.create(body, userDetail, userdetailid);
  }

  @Get(ClientRoutes.view_all)
  findAllClient(@Query('search') search: string) {
    return this.clientService.findAll(search);
  }

  @Get(ClientRoutes.view_one)
  findClientById(@Param('clientId') id: string) {
    return this.clientService.findOne(+id);
  }

  @Post(ClientRoutes.update)
  updateClientById(@Param('clientId') id: string, @Body() body: UpdateClientDto, @Req() req: any) {
    let userDetail = req.headers['userdetail'];
    let userdetailid = req.headers['userdetailid'];
    return this.clientService.update(+id, body, userDetail, userdetailid);
  }

  @Delete(ClientRoutes.delete)
  removeClientById(@Param('clientId') id: string, @Req() req: any) {
    let userDetail = req.headers['userdetail'];
    let userdetailid = req.headers['userdetailid'];
    return this.clientService.remove(+id, userDetail, userdetailid);
  }

  @Post(ClientRoutes.change_password)
  async changePassword(@Body() request: ChangePasswordDto,@Req() req: any) {
    let userDetail = req.headers['userdetail'];
    let userdetailid = req.headers['userdetailid'];
    return await this.clientService.changePassword(
      request,userDetail, userdetailid
    );
  }

  @Get(ClientRoutes.find_client_details)
  async findClientByEmailAndName(@Query('text') text: string) {
    return await this.clientService.findClientByEmailAndName(text);
  }

  @Get(ClientRoutes.find_client_order_details_by_case)
  async findClientOrderDeatilsByCase(@Query('text') text: string) {
    const newText = decodeURIComponent(text)
    return await this.clientService.findClientOrderDeatilsByCase(newText);
  }

  @Get(ClientRoutes.find_client_dashboard_details_by_client_id)
  async findClientDashboardDetailsByCLientId(@Param('clientId') id: string) {
    return await this.clientService.findClientDashboardDetailsByCLientId(+id);
  }


  @Post(ClientRoutes.update_all_clients)
  updateAll(@Req() req) {
    return this.clientService.updateAll(req);
  }
  @Public()
  @Get(ClientRoutes.get_baseCase_List_By_ClientId)
  getBaseCaseListByClientId(@Param('clientId') clientId: string) {
    return this.clientService.getBaseCaseListByClientId(+clientId);
  }

  @Get(ClientRoutes.get_service_agreement_By_clientId)
  async getInventorDocuments(@Param('clientId') clientId: number) {
    return this.clientService.getInventorDocumentsByClientId(clientId);
  }

  @Get(ClientRoutes.get_assignee_agreement_By_clientId)
  async getAssigneeDocumentsByClientId(@Param('clientId') clientId: number) {
    return this.clientService.getAssigneeAgreementByClientId(clientId);
  }
}
