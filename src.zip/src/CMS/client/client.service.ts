import {
  HttpException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import {  Repository, getConnection } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateClientDto } from './dto/request/create-client.dto';
import { UpdateClientDto } from './dto/request/update-client.dto';
import { Client } from './entities/client.entity';
import { ClientWithMessageResponse } from './dto/response/clientWithResponce';
import { ClientStatus, PaymentStatus } from './entities/status.enum';
import { ChangePasswordDto } from './dto/request/change-password-dto';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { EventLogService } from '../event-log/event-log.service';
import { ModuleName } from '../event-log/entities/module-name.enum';
import { ClientAction } from '../event-log/entities/event-name.enum';
import { ClientDashboard } from './constants/client_portal.const';
import { Order } from '../order/entities/order.entity';
import { TaskInstruction } from '../task-instruction/entities/task-instruction.entity';
import { Cases } from '../cases/entities/cases.entity';
import { OrderPayment } from '../order-payment/entities/order-payment.entity';
import { OrderInventorsService } from '../order-inventors/order-inventors.service';
import { OrderAssigneeDocumentService } from '../order-assignee-document/order-assignee-document.service';
import { CaseFileService } from '../case-file/case-file.service';
import { ProductOrderDetailFormStatus } from '../product-order-detail-form/entities/approve-type.enum';
import { DocumentUploadStatus } from '../case-file/entities/status.enum';
import { ConfigService } from '@nestjs/config';
const fs = require('fs');
const moment = require('moment');

const saltOrRounds = 10;

@Injectable()
export class ClientService {
  constructor(
    @InjectRepository(Client) private clientRepository: Repository<Client>,
    @InjectRepository(Order) private orderRepository: Repository<Order>,
    @InjectRepository(Cases) private caseRepository: Repository<Cases>,
    @InjectRepository(TaskInstruction)
    private taskInstructionRepository: Repository<TaskInstruction>,
    @InjectRepository(OrderPayment)
    private orderPaymentRepository: Repository<OrderPayment>,
    private readonly mailsService: MailService,
    private eventLogService: EventLogService,
    private orderInventor: OrderInventorsService,
    private orderAssigneeService: OrderAssigneeDocumentService,
    private caseFileService: CaseFileService,
    private configService: ConfigService
  ) { }

  async create(
    request: CreateClientDto,
    userDetail,
    userdetailid,
  ): Promise<ClientWithMessageResponse> {
    try {
      let existingClientEmail = await this.clientRepository.findOne({
        where: { email: request.email },
      });
      if (existingClientEmail) {
        return {
          message: `Client already exist`,
        };
      }

      const result = await this.clientRepository.save(request);
      await this.eventLogService.create({
        moduleName: ModuleName.CLIENT,
        eventName: ClientAction.ADD_CLIENT,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue: '',
        newValue: JSON.stringify(result),
        eventPrimeryKey: result.id,
      });
      if (userDetail != '') {
        const mailNewData = {
          'First name': result.firstName,
          'Middle name': result.middleName,
          'Last name': result.lastName,
          'Email .': result.email,
          'Email Alternate1': result.alternateEmail,
          'Client type': result.clientType,
          'Phone No.': result.phone,
          'Land Line  Phone': result.landLinePhone,
          'Notes': result.landLinePhone,
          'Work phone': result.workPhone,
          'Password': result.password,
          'Street': result.street,
          'Apartment': result.apartment,
          'City': result.city,
          'State': result.state,
          'state1':result.state1,
          'Country': result.country,
          'Zip code': result.zipcode,
          'Status':result.status,
          'Client  Root Path':result.clientRootPath,
          'other Data Value:':result.otherDataValue,
          'Client block': result.isdisableClient,
          'Client archived': result.isArchiveClient,
          'Client deleted': result.isDeleteClient,
          'Alternate email':result.alternateEmail,
          'clientRootPath':result.clientRootPath,
        };
   
        let frontUrl = this.configService.get<string>('FRONT_URL');
        var mail: IMail = {
          to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
          subject: `CIS Update:A new client created # ${result.firstName + ' ' + result.lastName}}`,
          url: userDetail + ' ' + 'has created a new client',
          data: mailNewData,
          requestdata: userdetailid,
          fronturl: frontUrl,
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.cis_new_client);
      }else{
        const newClient = {
          'First name': result.firstName,
          'Middle name': result.middleName,
          'Last name': result.lastName,
          'Email .': result.email,
          'Phone no.': result.phone,
          'Notes': result.notes,
          'Work phone':result.workPhone,
          'Password': result.password,
          'Street': result.street,
          'Apartment': result.apartment,
          'City': result.city,
          'State': result.state,
          'Country': result.country,
          'Zip code': result.zipcode,
          'Other data value':result.otherDataValue,
          'Status': result.status,
          'Client type': result.clientType,
          'Client approve': result.isApprove,
          'Phone': result.phone,
          'Client block': result.isdisableClient,
          'Client archived': result.isArchiveClient,
          'Client deleted': result.isDeleteClient,
          'Alternate email':result.alternateEmail,
          'clientRootPath':result.clientRootPath,
      };
      let frontUrl = this.configService.get<string>('FRONT_URL');
      var mail: IMail = {
        to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
        subject: `CIS Update:A New Client Created ${result.firstName} ${result.lastName}`,
        url: 'New Client Created',
        data: newClient,
        requestdata: userdetailid,
        fronturl: frontUrl,
      };
      await this.mailsService.sendingMail(mail, TemplateTypes.cis_new_client);
      }
      if (result) {
        return {
          message: `${Messages.Resource.Created} : Client`,
          data: result,
        };
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async findAll(search: string): Promise<ClientWithMessageResponse> {
    let query = `SELECT *, (SELECT COUNT(id) AS ordercount FROM \`order\` WHERE clientId = client.id) AS ordercount FROM \`client\``;

    if (search) {
      const conditions = [
        `firstName LIKE '%${search}%'`,
        `lastName LIKE '%${search}%'`,
        `middleName LIKE '%${search}%'`,
        `email LIKE '%${search}%'`,
        `phone LIKE '%${search}%'`,
        `landLinePhone LIKE '%${search}%'`,
        `workPhone LIKE '%${search}%'`
      ];
      const whereClause = conditions.join(' OR ');
      query += ` WHERE ${whereClause}`;
    }

    const result = await getConnection().query(query);

    if (result && result.length > 0) {
      return {
        message: `${Messages.Resource.Found} : Client`,
        data: result,
      };
    } else {
      return {
        message: `${Messages.Resource.NotFound} : Client`,
        data: [],
      };
    }
  }

  async findOne(clientId: number): Promise<ClientWithMessageResponse> {
    try {
      const result = await this.clientRepository.findOne({
        where: { id: clientId },
      });

      if (!result)
        throw new HttpException(`Client-id not exist`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Client`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }

  async findOneByCLientId(clientId: number) {
    try {
      const result = await this.clientRepository.findOne({
        where: { id: clientId },
      });
      if (result && result != undefined) {
        return result;
      } else {
        return [];
      }
    } catch (error) {
      throw error;
    }
  }

  async update(
    clientId: number,
    request: UpdateClientDto,
    userDetail, 
    userdetailid,
  ): Promise<ClientWithMessageResponse> {
    try {
      const data = await this.clientRepository
        .createQueryBuilder('client')
        .leftJoinAndSelect('client.case', 'case')
        .where({ id: clientId })
        .orderBy('case.id', 'DESC')
        .getRawMany();
      if (!data) {
        throw new HttpException(`Client-id not exist`, HttpStatus.NOT_FOUND);
      }
      if (request.password === '' || request.password === null) {
        const generatePassword = (length) => {
          const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
          let password = '';
          for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
          }
          return password;
        };
      
        request.password = generatePassword(18);
      }
      const result1 = await this.clientRepository.findOne(clientId);
      await this.clientRepository.update(clientId, request);
      const result = await this.clientRepository.findOne(clientId);
      const clientAllOrder = await this.findClientByEmailAndName(result.email)
      const latestOrder = clientAllOrder[0]?.order[clientAllOrder[0]?.order?.length - 1];
      if(latestOrder){
        await this.orderRepository.update(latestOrder?.id,{
          firstName: request.firstName ? request.firstName : latestOrder.firstName ,
          middleName: request.middleName ? request.middleName : latestOrder.middleName,
          lastName: request.lastName ? request.lastName : latestOrder.lastName,
          email: request.email? request.email : latestOrder.email,
          phone: request.phone ? request.phone : latestOrder.phone,
          city: request.city ? request.city : latestOrder.city,
          state: request.state ? request.state : latestOrder.state,
          country: request.country ? request.country : latestOrder.country,
          zipcode: request.zipcode ? request.zipcode : latestOrder.zipcode,
        },)
      }
      await this.eventLogService.create({
        moduleName: ModuleName.CLIENT,
        eventName: ClientAction.UPDATE_CLIENT,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue:JSON.stringify(result1),
        newValue: JSON.stringify(result),
        eventPrimeryKey: result.id,
      });
        const oldData = JSON.stringify(result1);
        const newData = JSON.stringify(result);
        const oldClient1 = JSON.parse(oldData);
        const newClient1 = JSON.parse(newData);
        const parseOtherDataValueOld = (client) => JSON.stringify(JSON.parse(client.otherDataValue));
        const parseOtherDataValueNew = (client) => JSON.stringify(JSON.parse(client.otherDataValue));
        const newClient = {
          'First name': newClient1.firstName,
          'Middle name': newClient1.middleName,
          'Last name': newClient1.lastName,
          'Email .': newClient1.email,
          'Phone no.': newClient1.phone,
          'Landline no.': newClient1.landLinePhone,
          'Notes': newClient1.notes,
          'Work phone': newClient1.workPhone,
          'Password': newClient1.password,
          'Street': newClient1.street,
          'Apartment': newClient1.apartment,
          'City': newClient1.city,
          'State': newClient1.state,
          'Company': newClient1.company,
          'Country': newClient1.country,
          'Zip code': newClient1.zipcode,
          'Other data value': parseOtherDataValueNew(newClient1),
          'Status': newClient1.status,
          'Client type': newClient1.clientType,
          'Client approve': newClient1.isApprove,
          'Client block': newClient1.isdisableClient,
          'Client archived': newClient1.isArchiveClient,
          'Client deleted': newClient1.isDeleteClient,
          'Alternate email':newClient1.alternateEmail,
          'clientRootPath':newClient1.clientRootPath,
      };
      
      const oldClient = {
          'First name': oldClient1.firstName,
          'Middle name': oldClient1.middleName,
          'Last name': oldClient1.lastName,
          'Email .': oldClient1.email,
          'Phone no.': oldClient1.phone,
          'Landline no.': oldClient1.landLinePhone,
          'Notes': oldClient1.notes,
          'Work phone': oldClient1.workPhone,
          'Password': oldClient1.password,
          'Street': oldClient1.street,
          'Apartment': oldClient1.apartment,
          'City': oldClient1.city,
          'State': oldClient1.state,
          'Company': oldClient1.company,
          'Country': oldClient1.country,
          'Zip code': oldClient1.zipcode,
          'Other data value': parseOtherDataValueOld(oldClient1),
          'Status': oldClient1.status,
          'Client type': oldClient1.clientType,
          'Client approve': oldClient1.isApprove,
          'Client block': oldClient1.isdisableClient,
          'Client archived': oldClient1.isArchiveClient,
          'Client deleted': oldClient1.isDeleteClient,
          'Alternate email':oldClient1.alternateEmail,
          'clientRootPath':oldClient1.clientRootPath,
      };
      let changes: { key: string; oldValue: any; newValue: any }[] = [];
      let notChanges: { key: string; oldValue: any; newValue: any }[] = [];
      let finalChanges = {};
      
      const deepEqual = (a, b) => {
        if (Array.isArray(a) && Array.isArray(b)) {
          return JSON.stringify(a) === JSON.stringify(b);
        }
        return a === b;
      };  
      if (newData !== oldData) {
        Object.keys(newClient).forEach(key => {
          if (!deepEqual(oldClient[key], newClient[key])) {
            changes.push({
              key: key,
              oldValue: oldClient[key],
              newValue: key === 'clientRootPath' ? '' : newClient[key]
            });
          } else {
            notChanges.push({
              key: key,
              oldValue: oldClient[key],
              newValue: ''
            });
          }
        });
        finalChanges = [...changes, ...notChanges];

      }
      let frontUrl = this.configService.get<string>('FRONT_URL');
      if (userDetail != '') {
           if (data[0].case_caseNumber != null) {
              var mail: IMail = {
                to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
                subject: `CIS Update: Client updated, case # ${data[0].case_caseNumber?? ''} ${data[0].client_firstName + ' '+ data[0].client_lastName}`,
                url: userDetail + ' ' + 'has updated a client',
                data: finalChanges,
                fronturl: frontUrl,
                requestdata: userdetailid,
                orderdata: clientId
              };
            } 
          else {
              var mail: IMail = {
                to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
                subject: `CIS Update: Client updated ${data[0].case_caseNumber?? ''} ${data[0].client_firstName + ' '+ data[0].client_lastName}`,
                url: userDetail + ' ' + 'has updated a client',
                data: finalChanges,
                requestdata: userdetailid,
                fronturl: frontUrl,
                orderdata: clientId
              };
            }
           await this.mailsService.sendingMail(mail, TemplateTypes.cis_client_changes);
          }     
          return {
            message: `${Messages.Resource.Updated} : Client`,
          };
        } catch (error) {
          throw new InternalServerErrorException(error.message);
        }
    }

  async remove(
    clientId: number,
    userDetail,
    userdetailid,
  ): Promise<ClientWithMessageResponse> {
    try {
      const result = await this.clientRepository.findOne({
        where: { id: clientId },
      });
      await this.eventLogService.create({
        moduleName: ModuleName.CLIENT,
        eventName: ClientAction.DELETE_CLIENT,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue: '',
        newValue: JSON.stringify(result),
        eventPrimeryKey: result.id,
      });
      const resultClient = await this.clientRepository.findOne(clientId);
      const deleteClient = await this.clientRepository.delete(clientId);
      const newClient = {
        'First name': resultClient.firstName,
        'Last name': resultClient.lastName,
        'Email .': resultClient.email,
        'Phone no.': resultClient.phone,
        'Password': resultClient.password,
        };
        let frontUrl = this.configService.get<string>('FRONT_URL');
      var mail: IMail = {
        to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
        subject: `CIS Update: client deleted ${resultClient.firstName} ${resultClient.lastName}`,
        data: newClient,
        cc: '',
        requestdata: userdetailid,
        fronturl: frontUrl,
      };
      await this.mailsService.sendingMail(mail, TemplateTypes.cis_change);
      if (deleteClient.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Client`,
        };
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  // get clients detail by emailid
  async getLeadOrClientDetailByEmailid(emailid: string) {
    try {
      const result = await this.clientRepository.findOne({
        where: { email: emailid },
        relations: ['order'],
      });
      return result;
    } catch (error) {
      throw error;
    }
  }

  // get clients detail by Clientid
  async getLeadOrClientDetailByClientid(clientid: Number) {
    try {
      const result = await this.clientRepository.findOne({
        where: { id: clientid },
      });
      return result;
    } catch (error) {
      throw error;
    }
  }

  async findByEmail(email: string) {
    const client = await this.clientRepository.findOne({
      where: { email: email },
    });
    if (client && client.status != ClientStatus.ACTIVE) {
      throw new HttpException(
        {
          status: HttpStatus.UNAUTHORIZED,
          error: Messages.Login.Unauthorised,
        },
        HttpStatus.UNAUTHORIZED,
      );
    }

    return client;
  }

  async getPermissionbyRole(clientId: string) {
    const res = await this.clientRepository
      .createQueryBuilder('client')
      .select('client.username', 'client.password')
      .where('id =:clientId', { clientId: clientId })
      .getMany();
    return res;
  }

  async changePassword(changePassword: ChangePasswordDto,userDetail,
    userdetailid,) {
    const client = await this.clientRepository.findOne({
      where: { id: changePassword.id, status: ClientStatus.ACTIVE },
    });
    try {
      if (client.password == changePassword.oldPassword) {
        await this.clientRepository.update(changePassword.id, {
          password: changePassword.newPassword,
        });
        const clientupdated = await this.clientRepository.findOne({
          where: { id: changePassword.id, status: ClientStatus.ACTIVE },
        });
        await this.eventLogService.create({
          moduleName: ModuleName.CLIENT,
          eventName: ClientAction.CHANGE_PASSWORD,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
          oldValue:  JSON.stringify(client),
          newValue: JSON.stringify(clientupdated),
          eventPrimeryKey: clientupdated.id,
        });
        const newClient = {
          'First name': clientupdated.firstName,
          'Last name': clientupdated.lastName,
          'Email .': clientupdated.email,
          'Phone no.': clientupdated.phone,
          'Password':client.password,
          'Updated Password': clientupdated.password,
          };
          let frontUrl = this.configService.get<string>('FRONT_URL');
        var mail: IMail = {
          to: clientupdated.email,
          subject: `CIS Update:Password Updated By Client ${clientupdated.firstName} ${clientupdated.lastName}`,
          data: newClient,
          cc: '',
          requestdata: userdetailid,
          fronturl: frontUrl,
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.cis_change);
        return {
          status: 200,
          message: 'Your password changed successfully',
        };
      }
      return new HttpException(
        'Incorrect old password',
        HttpStatus.BAD_REQUEST,
      );
    } catch (err) {
      throw err;
    }
  }

  async findClientByEmailAndName(text: string) {
    const result = await this.clientRepository
      .createQueryBuilder('client')
      .leftJoinAndSelect('client.order', 'order')
      .leftJoinAndSelect('order.orderDetail', 'orderDetail')
      .leftJoinAndSelect('orderDetail.case', 'case')
      .where(`client.firstName = '${text}'`)
      .orWhere(`client.email = '${text}'`)
      .orWhere(`client.phone = '${text}'`)
      .orWhere(`client.id = '${text}'`)
      .getMany();
    return result;
  }

  async findClientOrderDeatilsByCase(text: string) {
    const result = await this.clientRepository
      .createQueryBuilder('client')
      .leftJoinAndSelect('client.order', 'order')
      .leftJoinAndSelect('order.orderDetail', 'orderDetail')
      .leftJoinAndSelect('order.orderInventor', 'orderInventor')
      .leftJoinAndSelect('order.orderPayment', 'orderPayment')
      .leftJoinAndSelect('orderDetail.case', 'case')
      .leftJoinAndSelect('case.caseFile', 'caseFile')
      .leftJoinAndSelect(
        'orderDetail.productOrderDetailForm',
        'productOrderDetailForm',
      )
      .where(`case.caseNumber ='${text}'`)
      .getMany();
    return result;
  }

  async findClientDashboardDetailsByCLientId(clientId: number) {
    try {
      let clientDashboard = ClientDashboard;
      let latestOrderPaymentUpadatedDate: any = String;
      let latestOrderUpadatedDate: any = String;
      let latestServiceAgreementUpadatedDate: any = String;
      let latestServiceIntakeFormUpdatedDate: any = String;
      let latestUploadedDocumentUpdatedDate: any = String;
      let inProgressHonoredDataArr: any = [];
      let notStartedHonoredDataArr: any = [];
      let pendingHonoredDataArr: any = [];
      let inProgressIntakeDataArr: any = [];
      let pendingIntakeDataArr: any = [];
      let receivedIntakeDataArr: any = [];
      let archivedIntakeDataArr: any = [];
      let approvedServiceAgreement: any = [];
      let submitForApproveServiceAgreement: any = [];
      let allInventor: any = [];
      let clientIntakeServiceForm: any = [];
      let notStartedServiceIntakeForm: any = [];
      let underReviewServiceIntakeForm: any = [];
      let inProgressServiceIntakeForm: any = [];
      let doneServiceIntakeForm: any = [];
      let result3: any;
      let orderPaymentData: any = [];
      // let caseFileSubmitted: any = [];
      let nonValidateDocs:any=[];
      let validatedDocs:any =[];
      let caseFileApproved: any = [];
      let allCaseFile: any = [];
      let allOrderAssignee: any = [];
      let allServiceAgreement: any = [];
      let orderInventor: any;
      let submittedForValidate: any=[];
      let allNullInventorDoc: any= [];
      let allAssigneeNullDoc: any=[]
      const order: any = await this.orderRepository
        .createQueryBuilder('order')
        .where('order.clientId =:clientId', { clientId: clientId })
        .andWhere('order.isDeleted=:isDeleted', {isDeleted: false})
        .andWhere('order.isTemporaryCart=:isTemporaryCart', {isTemporaryCart: false})
        .getMany();

      let orderDates = [];
      if (clientId != null) {
        for (let x of order) {
          orderDates.push(x.updatedDate);
        }
        var max_date = orderDates.sort(function (d1: any, d2: any) {
          return d2 - d1;
        })[0];
        if (max_date != null) {
          latestOrderUpadatedDate = moment(new Date(max_date)).format(
            'YYYY-MM-DD',
          );
        } else {
          latestOrderUpadatedDate = moment(new Date()).format('YYYY-MM-DD');
        }
      }

      const instruction = await this.taskInstructionRepository
        .createQueryBuilder('task-instruction')
        .getMany();
      await Promise.all(
        order.map(async (res) => {
          //  for Honored payment
          const result: any = await this.orderPaymentRepository
            .createQueryBuilder('orderPayment')
            .select(
              'orderPayment.orderId as orderId, SUM(orderPayment.totalPrice) AS totalAmount',
            )
            .where({ orderId: res.id })
            .andWhere(`orderPayment.paymentStatus != :approvedStatus`, {
              approvedStatus: PaymentStatus.REJECTED,
            })
            .groupBy('orderPayment.orderId')
            .getRawMany();
          const result2: any = await this.orderPaymentRepository
            .createQueryBuilder('orderPayment')
            .select(
              'orderPayment.orderId as orderId, orderPayment.paymentStatus as paymentStatus',
            )
            .where({ orderId: res.id })
            .andWhere({ paymentStatus: PaymentStatus.PENDING_APPROVAL })
            .groupBy('orderPayment.orderId')
            .getRawMany();
          result3 = await this.orderPaymentRepository.find({
            where: { orderId: res.id },
          });
          orderPaymentData.push(result3);

          if (result.length == 0) {
            notStartedHonoredDataArr.push(res);
          }
          // if (
          //   result[0]?.totalAmount > 0 &&
          //   Number(result[0]?.totalAmount) < Number(res.orderPrice)
          // ) {
          //   inProgressHonoredDataArr.push(res);
          // }
          if (
            result2.length > 0 
          ) {
            pendingHonoredDataArr.push(res);
          }

          // For Admin Intake Forms
          if (
            res.status == 'Admin Intake Pending' ||
            res.status == 'Application Pending'
          ) {
            inProgressIntakeDataArr.push(res);
          }
          if (res.status == 'Payment Pending') {
            pendingIntakeDataArr.push(res);
          }
          if (res.status == 'Admin Intake Received') {
            receivedIntakeDataArr.push(res);
          }
          if (res.status == 'Archived') {
            archivedIntakeDataArr.push(res);
          }
          // for Service Agreement
          const orderAssignee =
            await this.orderAssigneeService.getDocumentByOrderId(res.id);
          if (orderAssignee != undefined) {
            allOrderAssignee.push(orderAssignee?.data);
          } else if(res.genAssigneeFullLegalname) {
            allAssigneeNullDoc.push(res)
          }
        }),
      );
      const completelyFlattenedArray = orderPaymentData.flat(Infinity);
      if (clientId != null) {
        let dates = [];
        for (let x of completelyFlattenedArray) {
          dates.push(x.updatedDate ? x.updatedDate : x.createdDate);
      }
        var max_date = dates.sort(function (d1: any, d2: any) {
          return d2 - d1;
        })[0];
        if (max_date != null) {
          latestOrderPaymentUpadatedDate = moment(new Date(max_date)).format(
            'YYYY-MM-DD',
          );
        } else {
          latestOrderPaymentUpadatedDate = moment(new Date()).format(
            'YYYY-MM-DD',
          );
        }
      }

      // for Service Agreement
      orderInventor = await this.orderInventor.getInventorByClientId(clientId);
      allInventor = orderInventor.data.map((x) => {
        return x.orderInventorDocument;
      });
       allNullInventorDoc = orderInventor.data.filter((q) => 
        q.orderInventorDocument.length === 0
    );
      var combinedArray = [].concat(allInventor, allOrderAssignee);
      allServiceAgreement = combinedArray.flat(Infinity);
      let serviceAgreementDates = [];
      for (let x of allServiceAgreement) {
          serviceAgreementDates.push(x.updatedDate ? x.updatedDate : x.createdDate);
      }
      var max_date = serviceAgreementDates.sort(function (d1: any, d2: any) {
        return d2 - d1;
      })[0];
      if (max_date != null) {
        latestServiceAgreementUpadatedDate = moment(new Date(max_date)).format(
          'YYYY-MM-DD',
        );
      } else {
        latestServiceAgreementUpadatedDate = moment(new Date()).format(
          'YYYY-MM-DD',
        );
      }     
      approvedServiceAgreement = allServiceAgreement.filter(
        (obj) => obj.status == 30,
      );
      submitForApproveServiceAgreement = allServiceAgreement.filter(
        (obj) => obj.status == 29,
      );
   

      //for intake service form
      clientIntakeServiceForm = await this.orderRepository
        .createQueryBuilder('order')
        .select('order.id', 'orderId')
        .leftJoin('order.orderDetail', 'orderDetail')
        .leftJoin('orderDetail.case', 'case')
        .leftJoin(
          'orderDetail.productOrderDetailForm',
          'productOrderDetailForm',
        )
        .addSelect(
          'productOrderDetailForm.isApprove as isApprove,productOrderDetailForm.id as id, productOrderDetailForm.updatedDate as updatedDate',
        )
        .where('order.clientId = :clientId', { clientId: clientId })
        .andWhere('order.isDeleted=:isDeleted', {isDeleted: false})
        .andWhere('order.isTemporaryCart=:isTemporaryCart', {isTemporaryCart: false})
        .andWhere('case.caseNumber IS NOT NULL')
        .groupBy('case.caseNumber')
        .addGroupBy('productOrderDetailForm.manageServiceFormName')
        .getRawMany();
        const filteredOrderServiceIntakeForm = Array.from(
          clientIntakeServiceForm.reduce((acc, item) => {
            if (!acc.has(item.orderId)) {
              acc.set(item.orderId, true); // Assume true for all initially
            }
            if (item.isApprove !== '13') {
              acc.set(item.orderId, false); // Mark false if any item is not '13'
            }
            return acc;
          }, new Map())
        ).filter(([orderId, allApprove13]) => allApprove13) // Keep only orderIds where allApprove13 is true
          .map(([orderId]) => orderId); // Extract the orderId
        
        clientIntakeServiceForm = clientIntakeServiceForm.filter(item => item.id !== null);
      if (clientId != null) {
        let serviceIntakeFormDates = [];
        for (let x of clientIntakeServiceForm) {
          if (x.updatedDate != null) {
            serviceIntakeFormDates.push(x.updatedDate);
          }
        }
        var max_date = serviceIntakeFormDates.sort(function (d1: any, d2: any) {
          return d2 - d1;
        })[0];
        if (max_date != null) {
          latestServiceIntakeFormUpdatedDate = moment(
            new Date(max_date),
          ).format('YYYY-MM-DD');
        } else {
          latestServiceIntakeFormUpdatedDate = moment(new Date()).format(
            'YYYY-MM-DD',
          );
        }
      }
      notStartedServiceIntakeForm = clientIntakeServiceForm.filter(
        (item) =>
          item.isApprove === ProductOrderDetailFormStatus.NOTSTARTED ||
          item.isApprove === null,
      );
      underReviewServiceIntakeForm = clientIntakeServiceForm.filter(
        (item) => item.isApprove === ProductOrderDetailFormStatus.UNDER_REVIEW,
      );
      inProgressServiceIntakeForm = clientIntakeServiceForm.filter(
        (item) => item.isApprove === ProductOrderDetailFormStatus.InProgress,
      );
      doneServiceIntakeForm = clientIntakeServiceForm.filter(
        (item) => item.isApprove === ProductOrderDetailFormStatus.DONE,
      );

      // For Upload Document
      allCaseFile = await this.caseFileService.getCaseFileByClientId(clientId);
      if (clientId != null) {
        let uploadDocumentDates = [];
        for (let x of allCaseFile) {
          if (x.updatedDate != null) {
            uploadDocumentDates.push(x.updatedDate);
          }
        }
        var max_date = uploadDocumentDates.sort(function (d1: any, d2: any) {
          return d2 - d1;
        })[0];
        if (max_date != null) {
          latestUploadedDocumentUpdatedDate = moment(new Date(max_date)).format(
            'YYYY-MM-DD',
          );
        } else {
          latestUploadedDocumentUpdatedDate = moment(new Date()).format(
            'YYYY-MM-DD',
          );
        }
      }
      // caseFileSubmitted = allCaseFile.filter(
      //   (K) =>
      //     K.status === DocumentUploadStatus.Submitted_For_Approval
      //    || K.status === 
      //     DocumentUploadStatus.Archived,
      // );
      nonValidateDocs= allCaseFile.filter((b)=> b.status === DocumentUploadStatus.Submitted_For_Approval)
      validatedDocs= allCaseFile.filter((q)=> q.status === DocumentUploadStatus.Client_Validated_Docs || q.status === DocumentUploadStatus.Client_Approved_For_Work )
      
      caseFileApproved = allCaseFile.filter(
        (p) =>
          p.status === DocumentUploadStatus.Client_Approved_For_Work ||
          p.status === DocumentUploadStatus.Client_Validated_Docs,
      );
      const honoredPaymentInstruction = instruction.filter((a:any)=> a.typeofcontent == 'Honored Payment')
      const adminIntakeInstruction = instruction.filter((a:any)=> a.typeofcontent == 'Admin Intake Forms')
      const serviceAgreementInstruction = instruction.filter((a:any)=> a.typeofcontent == 'Service Agreement')
      const serviceIntakeInstruction = instruction.filter((a:any)=> a.typeofcontent == 'Service Intake Forms')
      const uploadDocumentInstruction = instruction.filter((a:any)=> a.typeofcontent == 'Upload Documents')
      const validateDocumentInstruction = instruction.filter((a:any)=> a.typeofcontent == 'Validate Documents')
      // For Honored
      if (notStartedHonoredDataArr.length > 0) {
        clientDashboard[0].status = 'Pending Client';
        clientDashboard[0].action = 'Click here to complete task';
        clientDashboard[0].instruction = honoredPaymentInstruction[0].content;
        clientDashboard[0].status_date = latestOrderPaymentUpadatedDate;
      }
      // if (inProgressHonoredDataArr.length > 0) {
      //   clientDashboard[0].status = 'In Progress';
      //   clientDashboard[0].action = 'Click here to complete task';
      //   clientDashboard[0].instruction = instruction[0].content;
      //   clientDashboard[0].status_date = latestOrderPaymentUpadatedDate;
      // }
      if (pendingHonoredDataArr.length > 0 && notStartedHonoredDataArr.length == 0) {
        clientDashboard[0].status = 'Pending Approval';
        clientDashboard[0].action = 'Click here to Make additional Payments';
        clientDashboard[0].instruction = honoredPaymentInstruction[0]?.content;
        clientDashboard[0].status_date = latestOrderPaymentUpadatedDate;
      }
      if (
        notStartedHonoredDataArr.length == 0 &&
        pendingHonoredDataArr.length == 0
      ) {
        clientDashboard[0].status = 'Done';
        clientDashboard[0].action =
          'Click here to revise/update your prior submission';
        clientDashboard[0].instruction = honoredPaymentInstruction[0]?.content;
        clientDashboard[0].status_date = latestOrderPaymentUpadatedDate;
      }
      // For Admin Intake Forms
      // if (inProgressIntakeDataArr.length > 0) {
      //   clientDashboard[1].status = 'In Progress';
      //   clientDashboard[1].action = 'Click here to complete task';
      //   clientDashboard[1].instruction = instruction[1]?.content;
      //   clientDashboard[1].status_date = latestOrderUpadatedDate;
      // }
      if (
        pendingIntakeDataArr.length > 0  || inProgressIntakeDataArr.length > 0
      ) {

        clientDashboard[1].status = 'Pending Client';
        clientDashboard[1].action = 'Click here to complete task';
        clientDashboard[1].instruction = adminIntakeInstruction[0]?.content;
        clientDashboard[1].status_date = latestOrderUpadatedDate;
      }
      if (receivedIntakeDataArr.length == order.length &&  pendingIntakeDataArr.length == 0 ) {
        clientDashboard[1].status = 'Done';
        clientDashboard[1].action =
          'Click here to revise/update your prior submission';
        clientDashboard[1].instruction = adminIntakeInstruction[0]?.content;
        clientDashboard[1].status_date = latestOrderUpadatedDate;
      }
      // Service Agreement
      if (
        (allAssigneeNullDoc.length > 0  ||
          allNullInventorDoc.length > 0 ) 
      ) {
        clientDashboard[2].status = 'Pending Client';
        clientDashboard[2].action = 'Click here to complete task';
        clientDashboard[2].instruction = serviceAgreementInstruction[0]?.content;
        clientDashboard[2].status_date = latestServiceAgreementUpadatedDate;
      } 
      //  if (
      //   submitForApproveServiceAgreement.length > 0 &&
      //   submitForApproveServiceAgreement.length != allServiceAgreement.length
      // ) {
      //   clientDashboard[2].status = 'In Progress';
      //   clientDashboard[2].action = 'Click here to complete task';
      //   clientDashboard[2].instruction = instruction[2]?.content;
      //   clientDashboard[2].status_date = latestServiceAgreementUpadatedDate;
      // }
       else if (
        (allServiceAgreement.length =
          approvedServiceAgreement.length +
          submitForApproveServiceAgreement.length &&
          allServiceAgreement.length != approvedServiceAgreement.length && allAssigneeNullDoc.length == 0  &&
            allNullInventorDoc.length == 0 )
      ) {
        clientDashboard[2].status = 'Pending Approval';
        clientDashboard[2].action = 'Click here to complete task';
        clientDashboard[2].instruction = serviceAgreementInstruction[0]?.content;
        clientDashboard[2].status_date = latestServiceAgreementUpadatedDate;
      } else if (
        (allServiceAgreement.length =
          approvedServiceAgreement.length &&
          submitForApproveServiceAgreement.length == 0)
      ) {
        clientDashboard[2].status = 'Done';
        clientDashboard[2].action =
          'Click here to revise/update your prior submission';
        clientDashboard[2].instruction = serviceAgreementInstruction[0]?.content;
        clientDashboard[2].status_date = latestServiceAgreementUpadatedDate;
      }
      // Service Intake Forms
      if (
        clientIntakeServiceForm.length == 0
      ) {
        clientDashboard[3].status = 'Not Applicable';
        clientDashboard[3].action = 'No service forms currently required';
        clientDashboard[3].instruction = serviceIntakeInstruction[0]?.content;
        clientDashboard[3].status_date = latestServiceIntakeFormUpdatedDate;
      }
     else if (
      filteredOrderServiceIntakeForm.length > 0
      ) {
        clientDashboard[3].status = 'Pending Client';
        clientDashboard[3].action = 'Click here to complete task';
        clientDashboard[3].instruction = serviceIntakeInstruction[0]?.content;
        clientDashboard[3].status_date = latestServiceIntakeFormUpdatedDate;
      }
     else if (
        notStartedServiceIntakeForm.length > 0 &&
        clientIntakeServiceForm.length > notStartedServiceIntakeForm.length && filteredOrderServiceIntakeForm.length == 0
      ) {
        clientDashboard[3].status = 'In Progress';
        clientDashboard[3].action = 'Click here to complete task';
        clientDashboard[3].instruction = serviceIntakeInstruction[0]?.content;
        clientDashboard[3].status_date = latestServiceIntakeFormUpdatedDate;
      }
      else if (
        underReviewServiceIntakeForm.length + doneServiceIntakeForm.length == clientIntakeServiceForm.length
      ) {
        clientDashboard[3].status = 'Pending Approval';
        clientDashboard[3].action =
          'Click here to revise/update your prior submission';
        clientDashboard[3].instruction = serviceIntakeInstruction[0]?.content;
        clientDashboard[3].status_date = latestServiceIntakeFormUpdatedDate;
      }
      else if (doneServiceIntakeForm.length == clientIntakeServiceForm.length) {
        clientDashboard[3].status = 'Done';
        clientDashboard[3].action =
          'Click here to revise/update your prior submission';
        clientDashboard[3].instruction = serviceIntakeInstruction[0]?.content;
        clientDashboard[3].status_date = latestServiceIntakeFormUpdatedDate;
      }
      // Upload Documents
      if (clientIntakeServiceForm.length == 0 && allCaseFile.length == 0) {
        clientDashboard[4].status = 'Optional';
        clientDashboard[4].action = 'Click here to submit any documents for our review/work';
        clientDashboard[4].instruction = uploadDocumentInstruction[0]?.content;
        clientDashboard[4].status_date = latestUploadedDocumentUpdatedDate;
      }
     else if (filteredOrderServiceIntakeForm.length > 0  ) {
        clientDashboard[4].status = 'Pending Client';
        clientDashboard[4].action = 'Click here to complete task';
        clientDashboard[4].instruction = uploadDocumentInstruction[0]?.content;
        clientDashboard[4].status_date = latestUploadedDocumentUpdatedDate;
      }
     else if(nonValidateDocs.length > 0 && filteredOrderServiceIntakeForm.length ==0  ||  notStartedServiceIntakeForm.length > 0 &&
      clientIntakeServiceForm.length > notStartedServiceIntakeForm.length && filteredOrderServiceIntakeForm.length == 0) {
        clientDashboard[4].status = 'In Progress'
        clientDashboard[4].action = 'Click here to complete task';
        clientDashboard[4].instruction= uploadDocumentInstruction[0]?.content;
        clientDashboard[4].status_date= latestUploadedDocumentUpdatedDate;
      }
     else if (
        nonValidateDocs.length == 0 && allCaseFile.length > 0 && underReviewServiceIntakeForm.length + doneServiceIntakeForm.length == clientIntakeServiceForm.length
      ) {
        clientDashboard[4].status = 'Done';
        clientDashboard[4].action =
          'Click here to revise/update your prior submission';
        clientDashboard[4].instruction = uploadDocumentInstruction[0]?.content;
        clientDashboard[4].status_date = latestUploadedDocumentUpdatedDate;
      }
      // Validate Documents
      if ( filteredOrderServiceIntakeForm.length > 0 || validatedDocs.length == 0 && nonValidateDocs.length > 0) {
        clientDashboard[5].status = 'Pending Client';
        clientDashboard[5].action = 'Click here to complete task';
        clientDashboard[5].instruction = validateDocumentInstruction[0]?.content;
        clientDashboard[5].status_date = latestUploadedDocumentUpdatedDate;
      }
      if (
        allCaseFile.length == 0
      ) {
        clientDashboard[5].status = 'Not Applicable';
        clientDashboard[5].action =
          'Click to upload documents for validation';
        clientDashboard[5].instruction = validateDocumentInstruction[0]?.content;
        clientDashboard[5].status_date = latestUploadedDocumentUpdatedDate;
      }
      if (nonValidateDocs.length > 0 &&  validatedDocs.length > 0 && filteredOrderServiceIntakeForm.length ==0 || notStartedServiceIntakeForm.length > 0 &&
        clientIntakeServiceForm.length > notStartedServiceIntakeForm.length && filteredOrderServiceIntakeForm.length == 0 && validatedDocs.length > 0
      ) {
        clientDashboard[5].status = 'In Progress';
        clientDashboard[5].action =
          'Click to upload documents for validation';
        clientDashboard[5].instruction = validateDocumentInstruction[0]?.content;
        clientDashboard[5].status_date = latestUploadedDocumentUpdatedDate;
      }
      if (
        ( allCaseFile.length > 0 &&  nonValidateDocs == 0 && underReviewServiceIntakeForm.length + doneServiceIntakeForm.length == clientIntakeServiceForm.length )
      ) {
        clientDashboard[5].status = 'Done';
        clientDashboard[5].action =
          'Click here to revise/update your prior submission';
        clientDashboard[5].instruction = validateDocumentInstruction[0]?.content;
        clientDashboard[5].status_date = latestUploadedDocumentUpdatedDate;
      }
      const result = clientDashboard;
      if (result && result != undefined) {
        return result;
      } else {
        return [];
      }
    } catch (error) {
      throw error;
    }
  }

  updatedData: any;
  async updateAll(req: any): Promise<any> {
    const ids = req.body.id;
    const action = req.body.action;
    if (action == 'archive' || action == 'delete' || action == 'merge') {
      if (action === 'archive') {
        this.updatedData = {
          isArchiveClient: true,
        };
      } else if (action === 'delete') {
        this.updatedData = {
          isDeleteClient: true,
        };
      } else if (action === 'merge') {
        this.updatedData = {
          status: req.body.status,
          isdisableClient: req.body.isdisableClient,
          parentClientId: req.body.parentClientId,
        };
      }
    }
    const orders = await this.orderRepository.find();
    const cases = await this.caseRepository.find();
    const parentClient = await this.clientRepository.findOne({
      where: { id: req.body.parentClientId },
    });
    for (let id of ids) {
      await this.clientRepository.update(id, this.updatedData);
      if (action === 'merge') {
        for (let order of orders) {
          if (order.clientId == id) {
            await this.orderRepository.update(order.id, {
              clientId: req.body.parentClientId,
              firstName: parentClient.firstName,
              middleName: parentClient.middleName,
              lastName: parentClient.lastName,
              email: parentClient.email,
              phone: parentClient.phone,
              street: parentClient.street,
              apartment: parentClient.apartment,
              city: parentClient.city,
              state: parentClient.state,
              state1: parentClient.state1,
              country: parentClient.country,
              zipcode: parentClient.zipcode,
              isExisting: parentClient.isExisting,
            });
          }
        }
        for (let cas of cases) {
          if (cas.clientId == id) {
            await this.caseRepository.update(cas.id, {
              clientId: req.body.parentClientId,
            });
          }
        }
      }
    }
    return {
      message: `${Messages.Resource.Updated} : Client`,
    };
  }

  async getClientIdByParentId(parentClientId: number) {
    const result = await this.clientRepository.findOne({
      where: { parentClientId: parentClientId },
    });
    return result;
  }

  async getByParentId(id: number) {
    const result = await this.clientRepository.findOne({
      where: { id: id },
    });
    return result;
  }

  async getBaseCaseListByClientId(clientId: number){
    const result  = await this.clientRepository.findOne({
      where: {id: clientId},
      relations: ['caselegacy','case']
    })
    return result
  }

  async findAllClient(): Promise<ClientWithMessageResponse> {
    const result = await this.clientRepository.find()
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Client`,
        data: result
      }
    }
  }

  async getInventorDocumentsByClientId(clientId: number): Promise<ClientWithMessageResponse[]> {
    const result = await this.clientRepository
      .createQueryBuilder('client')
      .leftJoin('client.order', 'order')
      .select('order.administrativeCaseNumber', 'administrativeCaseNumber')
      .leftJoin('order.orderInventor', 'orderInventor')
      .leftJoin('orderInventor.orderInventorDocument', 'orderInventorDocument')
      .addSelect('orderInventorDocument.id', 'id')
      .addSelect('orderInventorDocument.fileActualName', 'fileActualName')
      .addSelect('orderInventorDocument.filePath', 'filePath')
      .addSelect('orderInventorDocument.clientNote', 'clientNote')
      .addSelect('orderInventorDocument.internalNote', 'internalNote')
      .addSelect('orderInventorDocument.status', 'status')
      .addSelect('orderInventorDocument.serviceAgreementDate', 'serviceAgreementDate')
      .where('client.id = :clientId', { clientId: clientId })
      .andWhere('orderInventorDocument.fileActualName IS NOT NULL')
      .getRawMany();
    return result
  }

  async getAssigneeAgreementByClientId(clientId: number): Promise<ClientWithMessageResponse[]> {
    const result = await this.clientRepository
      .createQueryBuilder('client')
      .leftJoin('client.order', 'order')
      .select('order.administrativeCaseNumber', 'administrativeCaseNumber')
      .leftJoin('order.orderAssigneeDocument', 'orderAssigneeDocument')
      .addSelect('orderAssigneeDocument.id', 'id')
      .addSelect('orderAssigneeDocument.fileActualName', 'fileActualName')
      .addSelect('orderAssigneeDocument.clientNote', 'clientNote')
      .addSelect('orderAssigneeDocument.internalNote', 'internalNote')
      .addSelect('orderAssigneeDocument.status', 'status')
      .addSelect('orderAssigneeDocument.serviceAgreementDate', 'serviceAgreementDate')
      .where('client.id = :clientId', { clientId: clientId })
      .andWhere('orderAssigneeDocument.fileActualName IS NOT NULL')
      .getRawMany();
    return result
  }
}
