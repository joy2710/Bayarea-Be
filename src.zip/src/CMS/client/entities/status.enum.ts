export enum ClientStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}

export enum PaymentStatus {
    PENDING_APPROVAL = 11,
    APPROVED = 12,
    REJECTED = 17,
    UNDER_REVIEW=18,
    HAS_ISSUES= 19
  }