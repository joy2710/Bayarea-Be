import { Cases } from "src/CMS/cases/entities/cases.entity";
import { Order } from "src/CMS/order/entities/order.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { ClientStatus } from "./status.enum";
import { CaseLegacy } from "src/CMS/case-legacy/entities/case-legacy.entity";

@Entity()
export class Client {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column({nullable: true})
    middleName: string;

    @Column({unique: true})
    email: string;

    @Column({ type: 'simple-array', nullable: true, default: null })
    clientType?: string[];

    @Column({ nullable: true,  })
    phone: string;

    @Column({ default:null })
    landLinePhone: number;

    @Column({ default:null })
    workPhone: number;

    @Column({ default:null })
    password: string;

    @Column({ default:null })
    notes: string;

    @Column({ default:null })
    street: string;

    @Column({ default:null })
    apartment: string;

    @Column({ default:null })
    city: string;

    @Column({ default:null })
    state: string;

    @Column({ default:null })
    state1: string;

    @Column({ default:null })
    country: string;

    @Column({ default:null })
    zipcode: string;
    
    @Column({ default:null })
    otherDataValue: string;
    
    @Column({ default: ClientStatus.ACTIVE })
    status: ClientStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @OneToMany(() => Order, (order: Order) => order.client)
    order: Order[];

    @OneToMany(() => Cases, (cases: Cases) => cases.client)
    case: Cases;

    @Column()
    isExisting: boolean;

    @Column()
    secondaryEmail: string;

    @Column({ default:false })
    isApprove: boolean;

    @Column({ default:false })
    isdisableClient: boolean;

    @Column({default: null})
    alternateEmail: string;
    
    @Column({default: null})
    clientRootPath:string;

    @Column({default: null})
    parentClientId:number;

    @Column({default: false})
    isArchiveClient:boolean;

    @Column({default: false})
    isDeleteClient:boolean;

    @OneToMany(() => CaseLegacy, (caselegacy: CaseLegacy) => caselegacy.client)
    caselegacy: CaseLegacy;

    @Column({default: null})
    pocSecondaryEmail: string;

    @Column({default: false})
    isPermitInvoicing: boolean;

    @Column()
    invoicingDueDate: number

    @Column()
    company?: string;

    @Column()
    isPaymentReminder: boolean;

    @Column()
    isAdminIntakeReminder: boolean;

    @Column()
    isAgreementReminder: boolean;

    @Column()
    isServiceFormReminder: boolean;

    @Column()
    isUploadDocReminder: boolean;

    @Column()
    isValidateDocReminder: boolean;
}