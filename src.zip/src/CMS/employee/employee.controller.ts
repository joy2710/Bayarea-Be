import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { ChangePasswordDto } from './dto/request/change-password.dto';
import { CreateEmployeeDto } from './dto/request/create-employee.dto';
import { UpdateEmployeeDto } from './dto/request/update-employee.dto';
import { EmployeeParentRoute, EmployeeRoutes } from './employee.http.routes';
import { EmployeeService } from './employee.service';


/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Employee')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:EmployeeParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class EmployeeController {
  constructor(private readonly employeeService: EmployeeService) {}

  @Post(EmployeeRoutes.create)
  create(@Body() createEmployeeDto: CreateEmployeeDto, @Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.employeeService.create(createEmployeeDto, userDetail,userdetailid);
  }

  @Get(EmployeeRoutes.view_all)
  findAll() {
    return this.employeeService.findAll();
  }

  @Get(EmployeeRoutes.view_one)
  findOne(@Param('employeeId') id: string) {
    return this.employeeService.findOne(+id);
  }

  @Post(EmployeeRoutes.update)
  update(@Param('employeeId') id: string, @Body() updateEmployeeDto: UpdateEmployeeDto,@Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.employeeService.update(+id, updateEmployeeDto, userDetail, userdetailid);
  }

  @Delete(EmployeeRoutes.delete)
  remove(@Param('employeeId') id: string, @Req()req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.employeeService.remove(+id,userDetail, userdetailid);
  }
  @Post(EmployeeRoutes.change_password)
  async changePassword(@Body() request: ChangePasswordDto) {
    return await this.employeeService.changePassword(
        request
      );
  }
}
