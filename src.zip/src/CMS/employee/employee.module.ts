import { Module } from '@nestjs/common';
import { EmployeeService } from './employee.service';
import { EmployeeController } from './employee.controller';
import { Employee } from './entities/employee.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { EventLogService } from '../event-log/event-log.service';
import { EventLog } from '../event-log/entities/event-log.entity';
import { SettingService } from '../setting/setting.service';
import { Setting } from '../setting/entities/setting.entity';
import { ConfigService } from '@nestjs/config';

@Module({
  imports: [TypeOrmModule.forFeature([Employee, EventLog,Setting])],
  controllers: [EmployeeController],
  providers: [EmployeeService, MailService,EventLogService,SettingService,ConfigService],
  exports: [EmployeeService, MailService, EventLogService,SettingService]
})
export class EmployeeModule {}
