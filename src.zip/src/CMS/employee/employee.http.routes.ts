export const EmployeeParentRoute = 'employee';

export const EmployeeRoutes = {
  create: '',
  update: 'update/:employeeId',
  delete: ':employeeId',
  view_one: ':employeeId',
  view_all: '',
  change_password: 'changePassword',
};