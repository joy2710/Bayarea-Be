
import { CaseAssign } from "src/CMS/case-assign/entities/case-assign.entity";
import { Role } from "src/CMS/role/entities/role.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { EmployeeStatus } from "./status.enum";

@Entity({ name: 'employee' })
export class Employee {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column()
    email: string;

    @Column()
    password: string;

    @Column()
    emailAlternate1: string;

    @Column()
    emailAlternate2: string;

    @Column({default:null})
    phoneNo: number;

    @Column()
    roleId: number;

    @Column({ default: EmployeeStatus.INACTIVE })
    status: EmployeeStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string; 

    @ManyToOne(() => Role, (role: Role) => role.employee,
    {
        eager: false,
        onDelete: 'CASCADE'
    })
    role: Role[];

    @OneToMany(() => CaseAssign, (caseAssign: CaseAssign) => caseAssign.employee)
    caseAssign: CaseAssign;
}
