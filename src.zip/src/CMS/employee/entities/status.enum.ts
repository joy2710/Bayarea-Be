export enum EmployeeStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}