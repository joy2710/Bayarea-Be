import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { getManager, getRepository, Repository } from 'typeorm';
import { CreateEmployeeDto } from './dto/request/create-employee.dto';
import { UpdateEmployeeDto } from './dto/request/update-employee.dto';
import { EmployeeWithMessageResponse } from './dto/response/employeeWithResponce';
import { Employee } from './entities/employee.entity';
import { EmployeeStatus } from './entities/status.enum';
import * as bcrypt from 'bcrypt';
import { ChangePasswordDto } from './dto/request/change-password.dto';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { ModuleName } from '../event-log/entities/module-name.enum';
import { EmployeeAction, FolderAction } from '../event-log/entities/event-name.enum';
import { EventLogService } from '../event-log/event-log.service';
const moment = require('moment');

const saltOrRounds = 10;

@Injectable()
export class EmployeeService {
  constructor(
    @InjectRepository(Employee) private employeeRepository: Repository<Employee>,
    private eventLogService: EventLogService

  ) { }
  async create(createEmployeeDto: CreateEmployeeDto, userDetail,userdetailid): Promise<EmployeeWithMessageResponse> {
    const employee = await this.employeeRepository.create(createEmployeeDto);
    const result = await this.employeeRepository.save(employee);
    await this.eventLogService.create({
      moduleName: ModuleName.EMPLOYEE,
      eventName: EmployeeAction.ADD_EMPLOYEE,
      baseCaseNumber:'',
      eventUserId: userdetailid,
      eventUserName: userDetail,
      eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
      oldValue: '',
      newValue:JSON.stringify(result),
      eventPrimeryKey:result.id,

    });
      return {
        message: `${Messages.Resource.Created} : Employee`,
        data: result
      }
  }

  async findAll(): Promise<EmployeeWithMessageResponse> {
    const result = await this.employeeRepository.find({relations: ['role']})
    if (result) {
      return {
        message: `${Messages.Resource.Found}: Employee`,
        data: result
      }
    }

  }

  async findOne(employeeId: number): Promise<EmployeeWithMessageResponse> {
    try {
      const result = await this.employeeRepository.findOne(
        {
          where:
            { id: employeeId }
        }
      );
      if (!result)
        throw new HttpException(`Employee-id not exist`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Employee`,
        data: result
      }
    } catch (error) {
      throw error;
    }

  }

  async update(employeeId: number, updateEmployeeDto: UpdateEmployeeDto, userDetail,userdetailid): Promise<EmployeeWithMessageResponse> {
    const data = await this.employeeRepository.findOne(employeeId);
    if (!data) {
      throw new HttpException(`Employee-id not exist`, HttpStatus.NOT_FOUND);
    }
   await this.employeeRepository.update(employeeId, updateEmployeeDto)
   const updatedData=await this.employeeRepository.findOne(employeeId)
    await this.eventLogService.create({
    moduleName: ModuleName.EMPLOYEE,
    eventName: EmployeeAction.UPDATE_EMPLOYEE,
    baseCaseNumber:'',
    eventUserId: userdetailid,
    eventUserName: userDetail,
    eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
    oldValue: JSON.stringify(data),
    newValue:JSON.stringify(updatedData),
    eventPrimeryKey:updatedData.id,


  });
    return {
      message: `${Messages.Resource.Updated} : Employee`,
    }
  }

  async remove(employeeId: number, userDetail,userdetailid): Promise<EmployeeWithMessageResponse> {

    try {
      const deletedData=await this.employeeRepository.findOne(employeeId)
      const deleteEmployee = await this.employeeRepository.delete(employeeId);
      const updatedData=await this.employeeRepository.findOne(employeeId)
      await this.eventLogService.create({
      moduleName: ModuleName.EMPLOYEE,
      eventName: EmployeeAction.DELETE_EMPLOYEE,
      baseCaseNumber:'',
      eventUserId: userdetailid,
      eventUserName: userDetail,
      eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
      oldValue: JSON.stringify(deletedData),
      newValue:'',
      eventPrimeryKey:deletedData.id,
  
    });
      if (deleteEmployee.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted}: Employee`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }

  }

  async findByEmail(email: string){
    const employee = await this.employeeRepository.findOne(
      {
        relations: ['role'],
        where:
          { email: email },
      }
    );
    if (employee && employee.status != EmployeeStatus.ACTIVE) {
      throw new HttpException({
        status: HttpStatus.UNAUTHORIZED,
        error: Messages.Login.Unauthorised,
      }, HttpStatus.UNAUTHORIZED);
    }

    return employee;

  }
  async getPermissionbyRole(employeeId: string) {
    const columnPermission = await getManager().query('SELECT  A.email,A.roleId as employeeRole,B.columnId,C.name as columnName,B.roleId as columnRole ,B.isNoaccess,B.isRead,B.isReadWrite FROM `employee` A '
      + 'right outer join `column-permission` B on A.roleId=B.roleId '
      + 'left outer join `column-detail`  C on C.id=B.columnId WHERE A.id=' + `${employeeId}`);

    const folderPermission = await getManager().query('SELECT  A.email,A.roleId as employeeRole,C.name as folderName,B.roleId as folderRole ,B.isAccess FROM `employee` A '
      + 'right outer join `folder-permission` B on A.roleId=B.roleId '
      + 'left outer join `folder`  C on C.id=B.folderId WHERE A.id=' + `${employeeId}`);

    const menuPermission = await getManager().query('SELECT  A.email,A.roleId as employeeRole,B.roleId as menuRole ,B.menuName,B.isAccess FROM `employee` A '
      + 'right outer join `menu-permission` B on A.roleId=B.roleId WHERE A.id=' + `${employeeId}`);

    return { columnPermission, folderPermission, menuPermission };

  }

  async changePassword(changePassword: ChangePasswordDto) {
    const employee = await this.employeeRepository.findOne({
      where:
        { id: changePassword.id, status: EmployeeStatus.ACTIVE }
    });
    try {
      if (employee) {
        const isMatch = await bcrypt.compare(changePassword.oldPassword, employee.password);
        if (isMatch) {
          await this.employeeRepository.update(changePassword.id, {
            password: await bcrypt.hash(changePassword.newPassword, saltOrRounds),
          })
          return {
            status: 200,
            message: 'Your password changed successfully'
          }
        }
        return new HttpException('Incorrect old password', HttpStatus.BAD_REQUEST);
      }
    }
    catch (err) {
      throw (err)
    }
  }
}
