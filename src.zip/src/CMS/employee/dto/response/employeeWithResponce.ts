import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { EmployeeResponse } from './employee-response';



export class EmployeeWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: EmployeeResponse | EmployeeResponse[];

  constructor(message: string, data: EmployeeResponse | EmployeeResponse[]) {
    this.data = data;
    this.message = message;
  }
}
