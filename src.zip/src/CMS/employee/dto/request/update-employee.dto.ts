
import { CreateEmployeeDto } from './create-employee.dto';

export class UpdateEmployeeDto extends (CreateEmployeeDto) {}
