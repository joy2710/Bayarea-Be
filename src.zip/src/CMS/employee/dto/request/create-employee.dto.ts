import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { EmployeeStatus } from "../../entities/status.enum";

export class CreateEmployeeDto {

    @ApiProperty()
    @IsNotEmpty()
    firstName: string;

    @ApiProperty()
    @IsNotEmpty()
    lastName: string;

    @ApiProperty()
    @IsNotEmpty()
    email: string;

    @ApiProperty()
    @IsNotEmpty()
    password: string;
    
    @ApiProperty()
    @IsNotEmpty()
    emailAlternate1: string;

    @ApiProperty()
    @IsNotEmpty()
    emailAlternate2: string;

    @ApiProperty()
    @IsOptional()
    phoneNo: number;

    @ApiProperty()
    @IsNotEmpty()
    roleId: number;

    @ApiProperty({ default: EmployeeStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(EmployeeStatus)
    status: EmployeeStatus;  
}
