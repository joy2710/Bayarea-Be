export const FooterRoute = 'footer';

export const FooterContentRoutes = {
  create: '',
  update: 'update/:footerId',
  delete: ':footerId',
  view_one: ':footerId',
  view_all: '',
  home_footer:'home-footer'
};
