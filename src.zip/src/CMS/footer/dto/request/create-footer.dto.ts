import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { FooterStatus } from "../../entities/status.enum";


export class CreateFooterDto {
    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;

    @ApiProperty({ default: false })
    @IsOptional()
    isHomeFooter: boolean;

    @ApiProperty({ default: FooterStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(FooterStatus)
    status: FooterStatus;

  
}
