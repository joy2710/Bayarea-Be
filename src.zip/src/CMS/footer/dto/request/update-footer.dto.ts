import { CreateFooterDto } from "./create-footer.dto";
export class UpdateCaseStudyDto extends CreateFooterDto {}
