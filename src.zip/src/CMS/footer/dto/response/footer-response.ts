import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { FooterStatus } from '../../entities/status.enum';


export class FooterResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  isHomeFooter: boolean;

  @ApiProperty({ example: FooterStatus })
  @Expose()
  status: FooterStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdBy?: number;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

}
