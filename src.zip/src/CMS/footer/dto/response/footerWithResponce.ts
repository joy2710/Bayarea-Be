import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { FooterResponse } from './footer-response';



export class FooterWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: FooterResponse | FooterResponse[];

  constructor(message: string, data: FooterResponse | FooterResponse[]) {
    this.data = data;
    this.message = message;
  }
}
