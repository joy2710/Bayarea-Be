import { Controller, Get, Post, Body, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CreateFooterDto } from './dto/request/create-footer.dto';
import { FooterContentRoutes, FooterRoute } from './footer.http.routes';
import { FooterService } from './footer.service';


/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Footer')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path: FooterRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class FooterController {
  constructor(private readonly footerService: FooterService) {}

  @Post(FooterContentRoutes.create)
  create(@Body() createFooterDto: CreateFooterDto) {
    return this.footerService.create(createFooterDto);
  }

  @Public()
  @Get(FooterContentRoutes.view_all)
  findAll() {
    return this.footerService.findAll();
  }
  // HOME-FOOTER
  @Public()
  @Get(FooterContentRoutes.home_footer)
  getHomeFooter() {
    return this.footerService.homeFooter();
  }
  @Public()
  @Get(FooterContentRoutes.view_one)
  findOne(@Param('footerId') id: string) {
    return this.footerService.findOne(+id);
  }

  @Post(FooterContentRoutes.update)
  update(@Param('footerId') id: string, @Body() updateFooterDto: CreateFooterDto) {
    return this.footerService.update(+id, updateFooterDto);
  }

  @Delete(FooterContentRoutes.delete)
  remove(@Param('footerId') id: string) {
    return this.footerService.remove(+id);
  }
}
