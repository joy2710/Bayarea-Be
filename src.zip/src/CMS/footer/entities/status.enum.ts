export enum FooterStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}
