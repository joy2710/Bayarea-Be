
import { Page } from "src/CMS/page/entities/page.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { FooterStatus } from "./status.enum";
@Entity({ name: 'footer' })
export class Footer {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column({type: 'longtext'})
    description: string;

    @Column({ default: false })
    isHomeFooter: boolean;

    @Column({ default:FooterStatus.INACTIVE })
    status: FooterStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @OneToMany(() => Page, (page: Page) => page.footer)
    page: Page;
}

