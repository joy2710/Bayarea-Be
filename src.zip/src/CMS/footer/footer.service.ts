import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CreateFooterDto } from './dto/request/create-footer.dto';
import { FooterWithMessageResponse } from './dto/response/footerWithResponce';
import { Footer } from './entities/footer.entity';
import { FooterStatus } from './entities/status.enum';



@Injectable()
export class FooterService {

  constructor(
    @InjectRepository(Footer) private footerRepository: Repository<Footer>
  ) { }


  async create(request: CreateFooterDto): Promise<FooterWithMessageResponse> {
    const Footer = await this.footerRepository.create(request);
    const result = await this.footerRepository.save(Footer);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Footer`,
        data: result
      }
    }
  }
  async findAll(): Promise<FooterWithMessageResponse> {
    const result = await this.footerRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Footer`,
        data: result
      }
    }
  }
 
  async findOne(footerId: number): Promise<FooterWithMessageResponse> {
    try {
      const result = await this.footerRepository.findOne(
        {
          where:
            { id: footerId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Footer`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Footer`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

 
  async update(footerId: number, request: CreateFooterDto): Promise<FooterWithMessageResponse> {
    const data = await this.footerRepository.findOne(footerId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Footer`, HttpStatus.NOT_FOUND);
    }
    await this.footerRepository.update(footerId, request)
    return {
      message: `${Messages.Resource.Updated} : Footer`,
    }

  }

  async remove(footerId: number): Promise<FooterWithMessageResponse> {
    try {
      const deleteCaseStudy = await this.footerRepository.delete(footerId)
      if (deleteCaseStudy.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Footer`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
  // GET-HOME-FOOTER
  async homeFooter(): Promise<FooterWithMessageResponse> {
    const result = await this.footerRepository.find({
      where: {
        isHomeFooter: true || 1,
        status: FooterStatus.ACTIVE
      }
    });
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Footer`,
        data: result
      }
    }
  }
}
