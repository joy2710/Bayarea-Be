import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, getRepository,Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateMenuDto } from './dto/request/create-menu.dto';
import { UpdateMenuDto } from './dto/request/update-menu.dto';
import { Menu } from './entities/menu.entity';
import { MenuWithMessageResponse } from './dto/response/menuWithResponce';
import { Page } from '../page/entities/page.entity';

@Injectable()
export class MenuService {
  constructor(
    @InjectRepository(Menu) private menusRepository: Repository<Menu>,
    @InjectRepository(Page) private pageRepository: Repository<Page>
  ) { }

  async create(request: CreateMenuDto): Promise<MenuWithMessageResponse> {
    try {
      if (request.parentid != null) {
        const parentId = await this.menusRepository.findOne(request.parentid);

        if (!parentId) {
          return {
            message: `${Messages.Resource.NotFound} : Parent-id`,
            data: []
          }
        }
      }
      if (request.pageId != null) {
        const pageId = await this.pageRepository.findOne(request.pageId);
        if (!pageId) {
          return {
            message: `${Messages.Resource.NotFound} : Page-id`,
            data: []
          }
        }
      }
      var menu = await this.menusRepository.create(request);
      request.pageNameUrl = request.name.replace(/[^a-zA-Z0-9]/g, "_")
      var result = await this.menusRepository.save(menu);
      if (result) {
        return {
          message: `${Messages.Resource.Created} : Menu`,
          data: result
        }
      }
    } catch (error) {
      if (error.code == 'ER_DUP_ENTRY') {
        throw new HttpException(
          error.message,
          HttpStatus.BAD_REQUEST,
        );
      }
    }
  }

  async findAll(): Promise<MenuWithMessageResponse> {
    const result = await getRepository(Menu)
      .createQueryBuilder('menu')
      .leftJoinAndSelect('menu.parent', 'parent')
      .leftJoinAndSelect('menu.page', 'page')
      .leftJoinAndSelect('page.pageContent', 'pageContent')
      .orderBy('menu.sequenceNumber', "ASC")
      .getMany();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Menu`,
        data: result
      }
    }
  }

  async findOne(menuId: number): Promise<MenuWithMessageResponse> {
    try {
      const result = await getRepository(Menu)
      .createQueryBuilder('menu')
      .where("menu.id = :id", { id: menuId })
      .leftJoinAndSelect('menu.page', 'page')
      .leftJoinAndSelect('page.pageContent', 'pageContent')
      .getOne();
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Menu`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Menu`,
        data: result
      }

    } catch (error) {
      throw error;
    }
  }

  async update(menuId: number, request: UpdateMenuDto): Promise<MenuWithMessageResponse> {
    const data = await this.menusRepository.findOne(menuId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Menu`, HttpStatus.NOT_FOUND);
    }
    request.pageNameUrl = request.name.replace(/[^a-zA-Z0-9]/g, "_")
    await this.menusRepository.update(menuId, request)
    return {
      message: `${Messages.Resource.Updated} : Menu`,
    }

  }

  async remove(menuId: number): Promise<MenuWithMessageResponse>  {
    try {
      const deleteMenu = await this.menusRepository.delete(menuId);
      if (deleteMenu.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Menu`
        }
      }
    } catch (error) {
      return new InternalServerErrorException(error.message);
    }
  }
  async customQuery() {
    return this.menusRepository.createQueryBuilder("menu").select("name").orderBy("name");
  }

  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(Menu)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Menu)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Menu)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(Menu)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Menu)
      .set({ sequenceNumber: () => "sequenceNumber - 1" })
      .where('sequenceNumber > :currSequenceNumber AND sequenceNumber <= :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(Menu)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }

  async getMenuByPageId(pageId: number) {
    return await this.menusRepository
    .createQueryBuilder('menu')
    .leftJoinAndSelect('menu.parent', 'parent')
    .leftJoinAndSelect('parent.parent', 'parentMenu')
    .where({pageId: pageId})
    .getOne();
  }
}
