export enum MenuType {
    TOP = 'top',
    SIDE = 'side',
}