export enum MenuStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}
