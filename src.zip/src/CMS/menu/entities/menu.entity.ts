import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { MenuType } from "./menu-type.enum";
import { MenuStatus } from "./status.enum";
import { Page } from "src/CMS/page/entities/page.entity";

@Entity()
export class Menu {
 
    @PrimaryGeneratedColumn()
    id:number;

    @Column({unique: true})
    name:string;

    @Column()
    navigationurl:string;

    @Column({ default: null })
    parentid:number;

    @Column({default:MenuType.TOP})
    type:MenuType;

    @Column({default:MenuStatus.INACTIVE})
    status:MenuStatus;

    @CreateDateColumn({name:'createdDate'})
    createdDate: Date;

    @Column()
    createdBy:number;

    @UpdateDateColumn({name:'updatedDate',nullable:true,default:()=>'null'})
    updatedDate:Date;

    @Column({ nullable:true })
    updatedBy: string;

    @Column({ default: null })
    pageId: number;

    @ManyToOne(() => Page, (page: Page) => page.menu , {
        eager: false,
        onDelete: 'CASCADE'
    })
     page:Page[];

    @Column()
    sequenceNumber: number;
    
    @ManyToOne((type) => Menu, (menu: Menu) => menu.id)
    @JoinColumn({ name: 'parentid'})
    parent: Menu;

    @Column()
    pageNameUrl:string;

}
