import { Controller, Get, Post, Body, Param, Delete,UseGuards, Query } from '@nestjs/common';
import { ApiTags,ApiBearerAuth } from '@nestjs/swagger';
import { MenuService } from './menu.service';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CreateMenuDto } from './dto/request/create-menu.dto';
import { UpdateMenuDto } from './dto/request/update-menu.dto';
import { MenusParentRoute, MenusRoutes } from './menus.http.routes';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Menus')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:MenusParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class MenuController {
  constructor(private readonly menuService: MenuService) {}

  @Post(MenusRoutes.create)
  createMenu(@Body() body: CreateMenuDto) {
    return this.menuService.create(body);
  }

  @Public()
  @Get(MenusRoutes.view_all)
  findAllMenus() {
    return this.menuService.findAll();
  }

  @Public()
  @Get(MenusRoutes.view_one)
  findMenuById(@Param('menuId') id: string) {
    return this.menuService.findOne(+id);
  }

  @Post(MenusRoutes.update)
  updateMenuById(@Param('menuId') id: string, @Body() body: UpdateMenuDto) {
    return this.menuService.update(+id, body);
  }

  @Delete(MenusRoutes.delete)
  removeMenuById(@Param('menuId') id: string) {
    return this.menuService.remove(+id);
  }

  @Public()
  @Post(MenusRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.menuService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }
}
