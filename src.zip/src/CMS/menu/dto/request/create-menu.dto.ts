import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { MenuType } from "../../entities/menu-type.enum";
import { MenuStatus } from "../../entities/status.enum";

export class CreateMenuDto {
    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty()
    @IsNotEmpty()
    navigationurl: string;

    @ApiProperty({ default: null })
    parentid: number;

    @ApiProperty({ default: null })
    pageId: number;

    @ApiProperty({ default: MenuType.TOP })
    @IsNotEmpty()
    @IsEnum(MenuType)
    type: MenuType;

    @ApiProperty({ default: MenuStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(MenuStatus)
    status: MenuStatus;

    @ApiProperty()
    @IsOptional()
    sequenceNumber?: number;

    @ApiProperty()
    @IsOptional()
    pageNameUrl:string;

}