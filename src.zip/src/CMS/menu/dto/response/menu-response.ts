import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { MenuType } from '../../entities/menu-type.enum';
import { MenuStatus } from '../../entities/status.enum';

export class MenuResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  navigationurl: string;

  @ApiProperty()
  @Expose()
  pageId: number;

  @ApiProperty()
  @Expose()
  parentid: number;

  @ApiProperty({ default: MenuType.TOP })
  @Expose()
  type: MenuType;

  @ApiProperty({ example: MenuStatus })
  @Expose()
  status: MenuStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

  @ApiProperty()
  @Expose()
  sequenceNumber: number;

  @ApiProperty()
  @Expose()
  pageNameUrl:string;
}
