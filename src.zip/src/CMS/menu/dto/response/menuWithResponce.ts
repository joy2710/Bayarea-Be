import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { MenuResponse } from './menu-response';

export class MenuWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: MenuResponse | MenuResponse[];

  constructor(message: string, data: MenuResponse | MenuResponse[]) {
    this.data = data;
    this.message = message;
  }
}
