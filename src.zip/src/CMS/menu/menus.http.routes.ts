export const MenusParentRoute = 'menus';

export const MenusRoutes = {
  create: '',
  update: 'update/:menuId',
  delete: ':menuId',
  view_one: ':menuId',
  view_all: '',
  updateDragAndDrop: 'dragandDrop'
};
