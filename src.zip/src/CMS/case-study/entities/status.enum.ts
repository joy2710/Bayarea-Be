export enum CaseStudyStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}
