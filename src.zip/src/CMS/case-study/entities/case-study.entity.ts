import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { CaseStudyStatus } from "./status.enum";

@Entity({ name: 'case-study' })
export class CaseStudy {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    imageurl: string;

    @Column()
    title: string;

    @Column({ default: CaseStudyStatus.INACTIVE })
    status: CaseStudyStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column()
    sequenceNumber: number;
}
