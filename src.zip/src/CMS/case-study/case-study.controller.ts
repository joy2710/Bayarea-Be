import { Controller, Get, Post, Body, Param, Delete,UploadedFile,UseInterceptors,UseGuards, Query } from '@nestjs/common';
import { ApiTags,ApiBearerAuth,ApiBody,ApiConsumes } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { Observable, of } from 'rxjs';

import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CaseStudyParentRoute, CaseStudyRoutes } from './case-study.http.routes';
import { CaseStudyService } from './case-study.service';
import { CreateCaseStudyDto } from './dto/request/create-case-study.dto';
import { UpdateCaseStudyDto } from './dto/request/update-case-study.dto';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Case-study')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CaseStudyParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class CaseStudyController {
  constructor(private readonly caseStudyService: CaseStudyService) {}

  @Post(CaseStudyRoutes.create)
  createCaseStudy(@Body() body: CreateCaseStudyDto) {
    return this.caseStudyService.create(body);
  }

  @Public()
  @Get(CaseStudyRoutes.view_all)
  findAllCaseStudy() {
    return this.caseStudyService.findAll();
  }

  @Public()
  @Get(CaseStudyRoutes.view_one)
  findCaseStudyById(@Param('caseStudyId') id: string) {
    return this.caseStudyService.findOne(+id);
  }

  @Post(CaseStudyRoutes.update)
  updateCaseStudyById(@Param('caseStudyId') id: string, @Body() body: UpdateCaseStudyDto) {
    return this.caseStudyService.update(+id, body);
  }

  @Delete(CaseStudyRoutes.delete)
  removeCaseStudyById(@Param('caseStudyId') id: string) {
    return this.caseStudyService.remove(+id);
  }

  @Post(CaseStudyRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {

    return of({ imagePath: `${file.destination}/${file.filename}` })
  }

  @Public()
  @Post(CaseStudyRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.caseStudyService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }
  
}
