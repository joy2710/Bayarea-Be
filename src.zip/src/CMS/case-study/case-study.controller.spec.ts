import { Test, TestingModule } from '@nestjs/testing';
import { CaseStudyController } from './case-study.controller';
import { CaseStudyService } from './case-study.service';

describe('CaseStudyController', () => {
  let controller: CaseStudyController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CaseStudyController],
      providers: [CaseStudyService],
    }).compile();

    controller = module.get<CaseStudyController>(CaseStudyController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
