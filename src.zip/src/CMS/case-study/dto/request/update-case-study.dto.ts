import { CreateCaseStudyDto } from './create-case-study.dto';

export class UpdateCaseStudyDto extends CreateCaseStudyDto {}
