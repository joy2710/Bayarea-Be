import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { CaseStudyStatus } from "../../entities/status.enum";

export class CreateCaseStudyDto {

    @ApiProperty()
    @IsNotEmpty()
    imageurl: string;

    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty({ default: CaseStudyStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(CaseStudyStatus)
    status: CaseStudyStatus;

    @ApiProperty()
    @IsOptional()
    sequenceNumber?: number;

}
