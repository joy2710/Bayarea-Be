import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CaseStudyResponse } from './case-study-response';

export class CaseStudyWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CaseStudyResponse | CaseStudyResponse[];

  constructor(message: string, data: CaseStudyResponse | CaseStudyResponse[]) {
    this.data = data;
    this.message = message;
  }
}
