export const CaseStudyParentRoute = 'case-study';

export const CaseStudyRoutes = {
  create: '',
  update: 'update/:caseStudyId',
  delete: ':caseStudyId',
  view_one: ':caseStudyId',
  view_all: '',
  upload_image: 'image-upload',
  updateDragAndDrop: 'dragandDrop'
};
