import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateCaseStudyDto } from './dto/request/create-case-study.dto';
import { UpdateCaseStudyDto } from './dto/request/update-case-study.dto';
import { CaseStudyWithMessageResponse } from './dto/response/caseStudyWithResponce';
import { CaseStudy } from './entities/case-study.entity';

@Injectable()
export class CaseStudyService {
  constructor(
    @InjectRepository(CaseStudy) private caseStudyRepository: Repository<CaseStudy>
  ) { }

  async create(request: CreateCaseStudyDto): Promise<CaseStudyWithMessageResponse> {
    const caseStudy = await this.caseStudyRepository.create(request);
    const result = await this.caseStudyRepository.save(caseStudy);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Case-study`,
        data: result
      }
    }
  }

  async findAll(): Promise<CaseStudyWithMessageResponse> {
    const result = await this.caseStudyRepository
    .createQueryBuilder()
    .orderBy('sequenceNumber', "ASC")
    .getMany();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Case-study`,
        data: result
      }
    }
  }

  async findOne(caseStudyId: number): Promise<CaseStudyWithMessageResponse> {
    try {
      const result = await this.caseStudyRepository.findOne(
        {
          where:
            { id: caseStudyId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Case-study`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Case-study`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(caseStudyId: number, request: UpdateCaseStudyDto): Promise<CaseStudyWithMessageResponse> {
    const data = await this.caseStudyRepository.findOne(caseStudyId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Case-study`, HttpStatus.NOT_FOUND);
    }
    await this.caseStudyRepository.update(caseStudyId, request)
    return {
      message: `${Messages.Resource.Updated} : Case-study`,
    }

  }

  async remove(caseStudyId: number): Promise<CaseStudyWithMessageResponse> {
    try {
      const deleteCaseStudy = await this.caseStudyRepository.delete(caseStudyId)
      if (deleteCaseStudy.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Case-study`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(CaseStudy)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(CaseStudy)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(CaseStudy)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(CaseStudy)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(CaseStudy)
      .set({ sequenceNumber: () => "sequenceNumber - 1" })
      .where('sequenceNumber > :currSequenceNumber AND sequenceNumber <= :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(CaseStudy)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }
}
