import { Module } from '@nestjs/common';
import { CaseStudyService } from './case-study.service';
import { CaseStudyController } from './case-study.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CaseStudy } from './entities/case-study.entity';

@Module({
  imports:[TypeOrmModule.forFeature([CaseStudy])],
  controllers: [CaseStudyController],
  providers: [CaseStudyService]
})
export class CaseStudyModule {}
