import { Test, TestingModule } from '@nestjs/testing';
import { FrontpageContentController } from './frontpage-content.controller';
import { FrontpageContentService } from './frontpage-content.service';

describe('FrontpageContentController', () => {
  let controller: FrontpageContentController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FrontpageContentController],
      providers: [FrontpageContentService],
    }).compile();

    controller = module.get<FrontpageContentController>(FrontpageContentController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
