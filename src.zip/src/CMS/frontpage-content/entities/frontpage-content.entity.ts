import { type } from "os";
import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { FrontpageContentType } from "./frontpage-content-type.enum";
import { FrontpageContentStatus } from "./status.enum";

@Entity({ name: 'frontpage-content' })
export class FrontpageContent {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({type: 'longtext'})
    content: string;

    @Column({ default: FrontpageContentType.WELCOME_TO_OUR_FIRM, unique: true })
    typeofcontent: FrontpageContentType;

    @Column({ default: FrontpageContentStatus.INACTIVE })
    status: FrontpageContentStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
}
