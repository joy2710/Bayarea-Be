export enum FrontpageContentType {
    WELCOME_TO_OUR_FIRM = 'Welcome to our firm',
    SCHEDULE_A_CONSULATION = 'Schedule a consultation',
    INFORMATION = 'Information'
}
