export enum FrontpageContentStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}