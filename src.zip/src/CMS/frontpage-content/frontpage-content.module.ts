import { Module } from '@nestjs/common';
import { FrontpageContentService } from './frontpage-content.service';
import { FrontpageContentController } from './frontpage-content.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FrontpageContent } from './entities/frontpage-content.entity';

@Module({
  imports:[TypeOrmModule.forFeature([FrontpageContent])],
  controllers: [FrontpageContentController],
  providers: [FrontpageContentService]
})
export class FrontpageContentModule {}
