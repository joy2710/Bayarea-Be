import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty } from "class-validator"
import { FrontpageContentType } from "../../entities/frontpage-content-type.enum";
import { FrontpageContentStatus } from "../../entities/status.enum";

export class CreateFrontpageContentDto {

    @ApiProperty()
    @IsNotEmpty()
    content: string;

    @ApiProperty({default: FrontpageContentType.WELCOME_TO_OUR_FIRM})
    @IsNotEmpty()
    @IsEnum(FrontpageContentType)
    typeofcontent: FrontpageContentType;

    @ApiProperty({ default: FrontpageContentStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(FrontpageContentStatus)
    status: FrontpageContentStatus;

}