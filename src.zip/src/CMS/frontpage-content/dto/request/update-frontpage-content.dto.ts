import { CreateFrontpageContentDto } from './create-frontpage-content.dto';

export class UpdateFrontpageContentDto extends CreateFrontpageContentDto {}
