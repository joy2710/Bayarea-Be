import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { FrontpageContentType } from '../../entities/frontpage-content-type.enum';
import { FrontpageContentStatus } from '../../entities/status.enum';

export class FrontpageContentResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  content: string;

  @ApiProperty({ example: FrontpageContentType.WELCOME_TO_OUR_FIRM})
  @Expose()
  typeofcontent: FrontpageContentType;

  @ApiProperty({ example: FrontpageContentStatus.INACTIVE })
  @Expose()
  status: FrontpageContentStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;
} 
