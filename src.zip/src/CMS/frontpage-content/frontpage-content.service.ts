import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateFrontpageContentDto } from './dto/request/create-frontpage-content.dto';
import { UpdateFrontpageContentDto } from './dto/request/update-frontpage-content.dto';
import { FrontpageContent } from './entities/frontpage-content.entity';
import { FrontpageContentWithMessageResponse } from './dto/response/frontpageContentWithResponce';

@Injectable()
export class FrontpageContentService {
  constructor(
    @InjectRepository(FrontpageContent) private frontpageContentRepository: Repository<FrontpageContent>
  ) { }

  async create(request: CreateFrontpageContentDto): Promise<FrontpageContentWithMessageResponse> {
    try {
      const frontpageContent = await this.frontpageContentRepository.create(request);
      const result = await this.frontpageContentRepository.save(frontpageContent);
      if (result) {
        return {
          message: `${Messages.Resource.Created}:Frontpage-Content`,
          data: result
        }
      }
    } catch (error) {
      if (error.code == 'ER_DUP_ENTRY') {
        throw new HttpException(
          error.message,
          HttpStatus.BAD_REQUEST,
        );
      }
    }
  }

  async findAll(): Promise<FrontpageContentWithMessageResponse> {
    const result = await this.frontpageContentRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Frontpage-Content`,
        data: result
      }
    }
  }

  async findOne(frontpageContentId: number): Promise<FrontpageContentWithMessageResponse> {
    try {
      const result = await this.frontpageContentRepository.findOne(
        {
          where:
            { id: frontpageContentId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Frontpage-Content`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Frontpage-Content`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(frontpageContentId: number, request: UpdateFrontpageContentDto): Promise<FrontpageContentWithMessageResponse> {
    const data = await this.frontpageContentRepository.findOne(frontpageContentId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound}: Frontpage-Content`, HttpStatus.NOT_FOUND);
    }
    await this.frontpageContentRepository.update(frontpageContentId, request);

    return {
      message: `${Messages.Resource.Updated} : Frontpage-Content`,
    }
  }

  async remove(frontpageContentId: number): Promise<FrontpageContentWithMessageResponse> {
    try {
      const deleteFrontpageContent = await this.frontpageContentRepository.delete(frontpageContentId);

      if (deleteFrontpageContent.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Frontpage-Content`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
