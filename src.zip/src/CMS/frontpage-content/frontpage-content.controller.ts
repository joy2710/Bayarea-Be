import { Controller, Get, Post, Body, Param, Delete,UseGuards } from '@nestjs/common';
import { ApiTags,ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

import { FrontpageContentService } from './frontpage-content.service';
import { CreateFrontpageContentDto } from './dto/request/create-frontpage-content.dto';
import { UpdateFrontpageContentDto } from './dto/request/update-frontpage-content.dto';
import { FrontpageContentParentRoute, FrontpageContentRoutes } from './frontpage-content.http.routes';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Frontpage-Content')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path: FrontpageContentParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class FrontpageContentController {
  constructor(private readonly frontpageContentService: FrontpageContentService) {}

  @Post(FrontpageContentRoutes.create)
  createFrontpageContent(@Body() body: CreateFrontpageContentDto) {
    return this.frontpageContentService.create(body);
  }

  @Public()
  @Get(FrontpageContentRoutes.view_all)
  findAllFrontpageContent() {
    return this.frontpageContentService.findAll();
  }

  @Public()
  @Get(FrontpageContentRoutes.view_one)
  findFrontpageContentById(@Param('frontpageContentId') id: string) {
    return this.frontpageContentService.findOne(+id);
  }

  @Post(FrontpageContentRoutes.update)
  updateFrontpageContentById(@Param('frontpageContentId') id: string, @Body() body: UpdateFrontpageContentDto) {
    return this.frontpageContentService.update(+id, body);
  }

  @Delete(FrontpageContentRoutes.delete)
  removeFrontpageContentById(@Param('frontpageContentId') id: string) {
    return this.frontpageContentService.remove(+id);
  }
}
