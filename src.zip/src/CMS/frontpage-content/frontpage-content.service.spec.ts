import { Test, TestingModule } from '@nestjs/testing';
import { FrontpageContentService } from './frontpage-content.service';

describe('FrontpageContentService', () => {
  let service: FrontpageContentService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FrontpageContentService],
    }).compile();

    service = module.get<FrontpageContentService>(FrontpageContentService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
