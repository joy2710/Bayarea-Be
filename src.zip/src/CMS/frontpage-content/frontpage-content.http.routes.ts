export const FrontpageContentParentRoute = 'frontpage-content';

export const FrontpageContentRoutes = {
  create: '',
  update: 'update/:frontpageContentId',
  delete: ':frontpageContentId',
  view_one: ':frontpageContentId',
  view_all: '',
};
