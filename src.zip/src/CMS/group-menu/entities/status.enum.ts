export enum GroupMenuStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}
