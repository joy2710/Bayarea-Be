import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { GroupMenuStatus } from "./status.enum";

@Entity({ name: 'group-menu' })
export class GroupMenu {
    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    groupName: string;

    @Column({ default: GroupMenuStatus.INACTIVE })
    status: GroupMenuStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
}
