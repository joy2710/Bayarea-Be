import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CreateGroupMenuDto } from './dto/request/create-group-menu.dto';
import { UpdateGroupMenuDto } from './dto/request/update-group-menu.dto';
import { GroupMenuWithMessageResponse } from './dto/response/groupMenuWithResponse';
import { GroupMenu } from './entities/group-menu.entity';

@Injectable()
export class GroupMenuService {
  
  constructor(
    @InjectRepository(GroupMenu) private groupMenuRepository: Repository<GroupMenu>,
  ) { }

  async create(createGroupMenuDto: CreateGroupMenuDto): Promise<GroupMenuWithMessageResponse> {
    const groupMenu = await this.groupMenuRepository.create(createGroupMenuDto);
    const result = await this.groupMenuRepository.save(groupMenu);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Group-Menu`,
        data: result
      }
    }
  }

  async findAll(): Promise<GroupMenuWithMessageResponse> {
    const result = await this.groupMenuRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Group-Menu`,
        data: result
      }
    }
  }

  async findOne(groupMenuId: number): Promise<GroupMenuWithMessageResponse> {
    try {
      const result = await this.groupMenuRepository.find({
        where:
          { id: groupMenuId },
        take: 1
      });

      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Group-Menu`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Group-Menu`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(groupMenuId: number, updateGroupMenuDto: UpdateGroupMenuDto): Promise<GroupMenuWithMessageResponse> {
    const data = await this.groupMenuRepository.findOne(groupMenuId)
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Group-Menu`, HttpStatus.NOT_FOUND);
    }
    await this.groupMenuRepository.update(groupMenuId, updateGroupMenuDto);
    return {
      message: `${Messages.Resource.Updated} : Group-Menu`,
    }
  }

  async remove(groupMenuId: number): Promise<GroupMenuWithMessageResponse> {
    try {
      const deleteGroupMenu = await this.groupMenuRepository.delete(groupMenuId);
      if (deleteGroupMenu.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Group-Menu`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
