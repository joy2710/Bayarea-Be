import { ApiProperty } from "@nestjs/swagger";
import { IsEnum } from "class-validator";
import { GroupMenuStatus } from "../../entities/status.enum";

export class CreateGroupMenuDto {
    @ApiProperty()
    groupName: string;
  
    @ApiProperty({ default: GroupMenuStatus.INACTIVE })
    @IsEnum(GroupMenuStatus)
    status: GroupMenuStatus;
}
