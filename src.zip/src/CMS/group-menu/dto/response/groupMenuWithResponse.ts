import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { GroupMenuResponse } from './group-menu.response';

export class GroupMenuWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: GroupMenuResponse | GroupMenuResponse[];

  constructor(message: string, data: GroupMenuResponse | GroupMenuResponse[]) {
    this.data = data;
    this.message = message;
  }
}