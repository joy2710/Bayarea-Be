import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { GroupMenuService } from './group-menu.service';
import { CreateGroupMenuDto } from './dto/request/create-group-menu.dto';
import { UpdateGroupMenuDto } from './dto/request/update-group-menu.dto';
import { GroupMenuParentRoute, GroupMenuRoutes } from './group-menu.http.routes';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Group-Menu')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller(GroupMenuParentRoute)
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class GroupMenuController {
  constructor(private readonly groupMenuService: GroupMenuService) {}

  @Post(GroupMenuRoutes.create)
  create(@Body() createGroupMenuDto: CreateGroupMenuDto) {
    return this.groupMenuService.create(createGroupMenuDto);
  }

  @Get(GroupMenuRoutes.view_all)
  findAll() {
    return this.groupMenuService.findAll();
  }

  @Get(GroupMenuRoutes.view_one)
  findOne(@Param('groupMenuId') id: string) {
    return this.groupMenuService.findOne(+id);
  }

  @Post(GroupMenuRoutes.update)
  update(@Param('groupMenuId') id: string, @Body() updateGroupMenuDto: UpdateGroupMenuDto) {
    return this.groupMenuService.update(+id, updateGroupMenuDto);
  }

  @Delete(GroupMenuRoutes.delete)
  remove(@Param('groupMenuId') id: string) {
    return this.groupMenuService.remove(+id);
  }
}
