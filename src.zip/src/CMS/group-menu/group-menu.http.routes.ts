export const GroupMenuParentRoute = 'group-menu';

export const GroupMenuRoutes = {
  create: '',
  update: 'update/:groupMenuId',
  delete: ':groupMenuId',
  view_one: ':groupMenuId',
  view_all: ''
};