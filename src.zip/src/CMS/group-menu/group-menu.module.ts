import { Module } from '@nestjs/common';
import { GroupMenuService } from './group-menu.service';
import { GroupMenuController } from './group-menu.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GroupMenu } from './entities/group-menu.entity';

@Module({
  imports:[TypeOrmModule.forFeature([GroupMenu])],
  controllers: [GroupMenuController],
  providers: [GroupMenuService]
})
export class GroupMenuModule {}
