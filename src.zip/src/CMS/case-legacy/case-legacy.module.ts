import { Module } from '@nestjs/common';
import { CaseLegacyService } from './case-legacy.service';
import { CaseLegacyController } from './case-legacy.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CaseLegacy } from './entities/case-legacy.entity';
import { ClientModule } from '../client/client.module';

@Module({
  imports: [TypeOrmModule.forFeature([CaseLegacy]),ClientModule],
  controllers: [CaseLegacyController],
  providers: [CaseLegacyService]
})
export class CaseLegacyModule {}
