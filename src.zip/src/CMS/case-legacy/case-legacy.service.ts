import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateCaseLegacyDto } from './dto/request/create-case-legacy.dto';
import { UpdateCaseLegacyDto } from './dto/request/update-case-legacy.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { CaseLegacy } from './entities/case-legacy.entity';
import { Repository } from 'typeorm';
import { CaseLegacyWithMessageResponse } from './dto/response/case-legacyContentWithResponse';
import { Messages } from 'src/common/constants/messages';
import { ClientService } from '../client/client.service';

@Injectable()
export class CaseLegacyService {
  constructor(
    @InjectRepository(CaseLegacy) private caseLegacyRepository: Repository<CaseLegacy>,
    private clientService: ClientService,
  ) { }

 async create(createCaseLegacyDto: CreateCaseLegacyDto):Promise<CaseLegacyWithMessageResponse> {
   const  caseLegacy = await this.caseLegacyRepository.create(createCaseLegacyDto);
   const result = await this.caseLegacyRepository.save(caseLegacy)
      return {
        message: `${Messages.Resource.Created} : Case Legacy`,
        data: result
    }
  }

async findAll():Promise<CaseLegacyWithMessageResponse> {
  const CaseList = await this.caseLegacyRepository.find()
  const clientList = await this.clientService.findAllClient();
 let arr:any = clientList.data
 CaseList.map((x: any) =>{
  arr.map(async(y) =>{
    if(x.clientId == y.id){
      x.firstName = y.firstName;
      x.email= y.email;
      x.lastName = y.lastName
    }
  })
 })
  if (CaseList) {
    return {
      message: `${Messages.Resource.Found}: Base Case List`,
      data: CaseList
    }
  }
}

 async findOne(id: number):Promise<CaseLegacyWithMessageResponse> {
  try {
    const result = await this.caseLegacyRepository.findOne(
      {
        where:
          { id: id }
      }
    );
    if (!result)
      throw new HttpException(`${Messages.Resource.NotFound}:Case Legacy`, HttpStatus.NOT_FOUND);
    return {
      message: `${Messages.Resource.Found} : Case Legacy`,
      data: result
    }
  } catch (error) {
    throw error;
  }
  }

async  update(id: number, updateCaseLegacyDto: UpdateCaseLegacyDto):Promise<CaseLegacyWithMessageResponse> {
    const data = await this.caseLegacyRepository.findOne(id);
    if (!data) {
      throw new HttpException(`Case Legacy not exist`, HttpStatus.NOT_FOUND);
    }
    await this.caseLegacyRepository.update(id, updateCaseLegacyDto)
    return {
      message: `${Messages.Resource.Updated} : Case Legacy`,
    }
  }

  remove(id: number) {
    return `This action removes a #${id} caseLegacy`;
  }

   // get clients detail by emailid
   async getLCaseLegacyByBaseCaseNo(BaseCaseNo: string) {
    try {
      const result = await this.caseLegacyRepository.findOne({
        where: { BaseCaseNo: BaseCaseNo },
      });
      return result;
    } catch (error) {
      throw error;
    }
  }
  

  async getClientListByClientId(clientId:any){
    try {
      const result = await this.caseLegacyRepository.findOne({
        where: { clientId: clientId },
      });
      return result;
    } catch (error) {
      throw error;
    }
  }
}
