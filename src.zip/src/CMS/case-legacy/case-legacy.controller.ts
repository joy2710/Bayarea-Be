import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { CaseLegacyService } from './case-legacy.service';
import { CreateCaseLegacyDto } from './dto/request/create-case-legacy.dto';
import { UpdateCaseLegacyDto } from './dto/request/update-case-legacy.dto';
import { CaseLegacyRoute, CaseLegacyRoutes } from './case-legacy.http.routes';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { Public } from 'src/auth/constants';


/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('case-legacy')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller('case-legacy')
@Controller({ path:CaseLegacyRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class CaseLegacyController {
  constructor(private readonly caseLegacyService: CaseLegacyService) {}

  @Post(CaseLegacyRoutes.create)
  create(@Body() createCaseLegacyDto: CreateCaseLegacyDto) {
    return this.caseLegacyService.create(createCaseLegacyDto);
  }

  @Public()
  @Get(CaseLegacyRoutes.view_all)
  findAll() {
    return this.caseLegacyService.findAll();
  }

  @Get(CaseLegacyRoutes.view_one)
  findOne(@Param('id') id: string) {
    return this.caseLegacyService.findOne(+id);
  }

  @Post(CaseLegacyRoutes.update)
  update(@Param('id') id: string, @Body() updateCaseLegacyDto: UpdateCaseLegacyDto) {
    return this.caseLegacyService.update(+id, updateCaseLegacyDto);
  }

  @Delete(CaseLegacyRoutes.delete)
  remove(@Param('id') id: string) {
    return this.caseLegacyService.remove(+id);
  }
  
  @Public()
  @Post(CaseLegacyRoutes.get_client_list_by_client_id)
  getClientListByClientId(@Param('clientId') clientId: number) {
    return this.caseLegacyService.getClientListByClientId(clientId);
  }
}
