import { Test, TestingModule } from '@nestjs/testing';
import { CaseLegacyService } from './case-legacy.service';

describe('CaseLegacyService', () => {
  let service: CaseLegacyService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CaseLegacyService],
    }).compile();

    service = module.get<CaseLegacyService>(CaseLegacyService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
