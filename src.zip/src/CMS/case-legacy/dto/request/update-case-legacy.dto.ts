import { PartialType } from '@nestjs/mapped-types';
import { CreateCaseLegacyDto } from './create-case-legacy.dto';

export class UpdateCaseLegacyDto extends PartialType(CreateCaseLegacyDto) {}
