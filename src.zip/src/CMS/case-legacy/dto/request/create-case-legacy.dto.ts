import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class CreateCaseLegacyDto {

    @ApiProperty()
    clinetId?:number;
    
    @ApiProperty()
    BaseCaseNo?:string;

}
