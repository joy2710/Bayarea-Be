import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { CaseLegacyResponse } from "./case-legacy-response";


export class CaseLegacyWithMessageResponse {
    @ApiProperty({
      title: 'Message',
      description: 'Specifies a response message',
      example: 'Process Successful',
    })
  
    @Expose()
    message: string;
  
    @ApiProperty({
      title: 'Data',
      description: 'Specifies response data',
    })
  
    @Expose()
    data?: CaseLegacyResponse | CaseLegacyResponse[];
  
    constructor(message: string, data: CaseLegacyResponse | CaseLegacyResponse[]) {
      this.data = data;
      this.message = message;
    }
  }