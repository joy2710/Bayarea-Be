export const CaseLegacyRoute = 'case-legacy';

export const CaseLegacyRoutes = {
  create: '',
  update: 'update/:id',
  delete: ':id',
  view_one: ':id',
  view_all: '',
  get_client_list_by_client_id:'clientList/:clientId'
};