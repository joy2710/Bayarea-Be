import { Client } from "src/CMS/client/entities/client.entity";
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: 'case-legacy' })
export class CaseLegacy {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: true })
    clientId: number;

    @Column({ default:null })
    BaseCaseNo: string;

    @ManyToOne(() => Client, (client: Client) => client.caselegacy, {
        eager: false,
        onDelete: 'CASCADE'
    })
     client: Client[];
}
