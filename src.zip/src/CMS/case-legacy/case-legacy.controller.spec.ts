import { Test, TestingModule } from '@nestjs/testing';
import { CaseLegacyController } from './case-legacy.controller';
import { CaseLegacyService } from './case-legacy.service';

describe('CaseLegacyController', () => {
  let controller: CaseLegacyController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CaseLegacyController],
      providers: [CaseLegacyService],
    }).compile();

    controller = module.get<CaseLegacyController>(CaseLegacyController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
