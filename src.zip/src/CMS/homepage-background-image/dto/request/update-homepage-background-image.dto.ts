import { CreateHomepageBackgroundImageDto } from './create-homepage-background-image.dto';

export class UpdateHomepageBackgroundImageDto extends CreateHomepageBackgroundImageDto {}
