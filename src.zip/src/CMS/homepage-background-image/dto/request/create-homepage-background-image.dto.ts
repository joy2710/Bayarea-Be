import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { HomepageBackgroundImageType } from "../../entities/homepage-background-image-type.enum";
import { HomepageBackgroundImageStatus } from "../../entities/status.enum";

export class CreateHomepageBackgroundImageDto {

    @ApiProperty()
    @IsNotEmpty()
    imageurl: string;

    @ApiProperty({ default: HomepageBackgroundImageType.TOP_MENU})
    @IsNotEmpty()
    @IsEnum(HomepageBackgroundImageType)
    type: HomepageBackgroundImageType;

    @ApiProperty({ default: HomepageBackgroundImageStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(HomepageBackgroundImageStatus)
    status: HomepageBackgroundImageStatus;
}
