import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { HomepageBackgroundImageResponse } from './homepage-background-image-response';

export class HomepageBackgroundImageWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: HomepageBackgroundImageResponse | HomepageBackgroundImageResponse[];

  constructor(message: string, data: HomepageBackgroundImageResponse | HomepageBackgroundImageResponse[]) {
    this.data = data;
    this.message = message;
  }
}
