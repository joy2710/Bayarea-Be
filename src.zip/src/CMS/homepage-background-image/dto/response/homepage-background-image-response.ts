import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { HomepageBackgroundImageType } from '../../entities/homepage-background-image-type.enum';
import { HomepageBackgroundImageStatus } from '../../entities/status.enum';

export class HomepageBackgroundImageResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  imageurl: string;

  @ApiProperty({ default: HomepageBackgroundImageType })
  @Expose()
  type: HomepageBackgroundImageType;

  @ApiProperty({ example: HomepageBackgroundImageStatus })
  @Expose()
  status: HomepageBackgroundImageStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;
}
