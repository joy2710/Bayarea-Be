export enum HomepageBackgroundImageStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}