import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { HomepageBackgroundImageType } from "./homepage-background-image-type.enum";
import { HomepageBackgroundImageStatus } from "./status.enum";

@Entity({ name:'homepage-background-image'})
export class HomepageBackgroundImage {

    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    imageurl:string;

    @Column({default:HomepageBackgroundImageType.TOP_MENU,unique: true})
    type:HomepageBackgroundImageType;

   @Column({default:HomepageBackgroundImageStatus.INACTIVE})
    status:HomepageBackgroundImageStatus;

    @CreateDateColumn({name:'createdDate'})
    createdDate: Date;

    @Column()
    createdBy:number;

    @UpdateDateColumn({name:'updatedDate',nullable:true,default:()=>'null'})
    updatedDate:Date;

    @Column({ nullable:true })
    updatedBy: string;
    
}
