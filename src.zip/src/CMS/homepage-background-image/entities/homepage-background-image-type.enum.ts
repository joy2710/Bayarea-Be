export enum HomepageBackgroundImageType {
    TOP_MENU = 'Top Menu',
    GETSTARTED = 'Get Started',
    OUR_WORK = 'Our Work',
    FOOTER = 'Footer',
    CASE_STUDY = 'Case Study',
    OUR_FIRM = 'Our Firm',
    WEBSITE_BACKGROUND = 'Site Background'
}
