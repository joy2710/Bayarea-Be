import { Controller, Get, Post, Body, Param, Delete, UseGuards, UseInterceptors, UploadedFile } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiBody, ApiConsumes } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { FileInterceptor } from '@nestjs/platform-express';
import { Observable, of } from 'rxjs';

import { HomepageBackgroundImageService } from './homepage-background-image.service';
import { CreateHomepageBackgroundImageDto } from './dto/request/create-homepage-background-image.dto';
import { UpdateHomepageBackgroundImageDto } from './dto/request/update-homepage-background-image.dto';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { HomepageBackgroundImageParentRoute, HomepageBackgroundImageRoutes } from './homepageBackgroundImage.http.routes';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Homepage-Background-Image')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: HomepageBackgroundImageParentRoute })
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

// @Public()

export class HomepageBackgroundImageController {
  constructor(private readonly homepageBackgroundImageService: HomepageBackgroundImageService) { }

  @Post(HomepageBackgroundImageRoutes.create)
  createHomepageBackgroundImage(@Body() body: CreateHomepageBackgroundImageDto) {
    return this.homepageBackgroundImageService.create(body);
  }

  @Public()
  @Get(HomepageBackgroundImageRoutes.view_all)
  findAllHomepageBackgroundImage() {
    return this.homepageBackgroundImageService.findAll();
  }

  @Public()
  @Get(HomepageBackgroundImageRoutes.view_one)
  findHomepageBackgroundImageById(@Param('homepageBackgroundImageId') id: string) {
    return this.homepageBackgroundImageService.findOne(+id);
  }

  @Post(HomepageBackgroundImageRoutes.update)
  updateHomepageBackgroundImageById(@Param('homepageBackgroundImageId') id: string, @Body() body: UpdateHomepageBackgroundImageDto) {
    return this.homepageBackgroundImageService.update(+id, body);
  }

  @Delete(HomepageBackgroundImageRoutes.delete)
  removeHomepageBackgroundImageById(@Param('homepageBackgroundImageId') id: string) {
    return this.homepageBackgroundImageService.remove(+id);
  }

  @Public()
  @Post(HomepageBackgroundImageRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {

    return of({ imagePath: `${file.destination}/${file.filename}` })
  }
}
