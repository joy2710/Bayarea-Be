import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateHomepageBackgroundImageDto } from './dto/request/create-homepage-background-image.dto';
import { UpdateHomepageBackgroundImageDto } from './dto/request/update-homepage-background-image.dto';
import { HomepageBackgroundImage } from './entities/homepage-background-image.entity';
import { HomepageBackgroundImageWithMessageResponse } from './dto/response/homepageBackgroundImageWithResponce';

@Injectable()
export class HomepageBackgroundImageService {
  constructor(
    @InjectRepository(HomepageBackgroundImage) private homepageBackgroundImageRepository: Repository<HomepageBackgroundImage>
  ) { }

  async create(request: CreateHomepageBackgroundImageDto): Promise<HomepageBackgroundImageWithMessageResponse> {
    const homepageBackgroundImage = await this.homepageBackgroundImageRepository.create(request);
    const result = await this.homepageBackgroundImageRepository.save(homepageBackgroundImage);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Homepage-background-image`,
        data: result
      }
    }
  }

  async findAll(): Promise<HomepageBackgroundImageWithMessageResponse> {
    const result = await this.homepageBackgroundImageRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Homepage-background-image`,
        data: result
      }
    }
  }

  async findOne(homepageBackgroundImageId: number): Promise<HomepageBackgroundImageWithMessageResponse> {
    try {
      const result = await this.homepageBackgroundImageRepository.findOne(
        {
          where:
            { id: homepageBackgroundImageId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Homepage-background-image`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Homepage-background-image`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(homepageBackgroundImageId: number, request: UpdateHomepageBackgroundImageDto): Promise<HomepageBackgroundImageWithMessageResponse> {
    const data = await this.homepageBackgroundImageRepository.findOne(homepageBackgroundImageId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Homepage-background-image`, HttpStatus.NOT_FOUND);
    }
    await this.homepageBackgroundImageRepository.update(homepageBackgroundImageId, request);
    return {
      message: `${Messages.Resource.Updated} : Homepage-background-image`,
    }
  }

  async remove(homepageBackgroundImageId: number): Promise<HomepageBackgroundImageWithMessageResponse> {
    try {
      const deleteHomepageBackgroundImage = await this.homepageBackgroundImageRepository.delete(homepageBackgroundImageId);
      if (deleteHomepageBackgroundImage.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Homepage-background-image`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
