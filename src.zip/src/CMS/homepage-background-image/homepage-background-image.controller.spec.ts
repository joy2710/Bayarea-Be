import { Test, TestingModule } from '@nestjs/testing';
import { HomepageBackgroundImageController } from './homepage-background-image.controller';
import { HomepageBackgroundImageService } from './homepage-background-image.service';

describe('HomepageBackgroundImageController', () => {
  let controller: HomepageBackgroundImageController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [HomepageBackgroundImageController],
      providers: [HomepageBackgroundImageService],
    }).compile();

    controller = module.get<HomepageBackgroundImageController>(HomepageBackgroundImageController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
