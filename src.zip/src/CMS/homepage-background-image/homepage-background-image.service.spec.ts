import { Test, TestingModule } from '@nestjs/testing';
import { HomepageBackgroundImageService } from './homepage-background-image.service';

describe('HomepageBackgroundImageService', () => {
  let service: HomepageBackgroundImageService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [HomepageBackgroundImageService],
    }).compile();

    service = module.get<HomepageBackgroundImageService>(HomepageBackgroundImageService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
