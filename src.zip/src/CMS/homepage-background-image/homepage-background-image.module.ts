import { Module } from '@nestjs/common';
import { HomepageBackgroundImageService } from './homepage-background-image.service';
import { HomepageBackgroundImageController } from './homepage-background-image.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HomepageBackgroundImage } from './entities/homepage-background-image.entity';

@Module({
  imports:[TypeOrmModule.forFeature([HomepageBackgroundImage])],
  controllers: [HomepageBackgroundImageController],
  providers: [HomepageBackgroundImageService]
})
export class HomepageBackgroundImageModule {}
