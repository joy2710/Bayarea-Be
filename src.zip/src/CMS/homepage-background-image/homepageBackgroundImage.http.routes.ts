export const HomepageBackgroundImageParentRoute = 'homepage-background-image';

export const HomepageBackgroundImageRoutes = {
  create: '',
  update: 'update/:homepageBackgroundImageId',
  delete: ':homepageBackgroundImageId',
  view_one: ':homepageBackgroundImageId',
  view_all: '',
  upload_image: 'image-upload',
};
