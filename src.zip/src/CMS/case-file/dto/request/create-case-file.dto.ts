import { ApiProperty } from "@nestjs/swagger";
import { IsOptional } from "class-validator";

export class CreateCaseFileDto {
    @ApiProperty()
    caseId?: number;

    @ApiProperty({default: null})
    folderId?: number;

    @ApiProperty()
    fileActualName?: string;

    @ApiProperty()
    filePath?: string;

    @ApiProperty()
    description?: string;

    @ApiProperty()
    specialNote?: string;

    @ApiProperty()
    fileUploadType?: string;

    @ApiProperty()
    status?:string;
    
    // @ApiProperty({ default:false})
    // @IsOptional()
    // dashboardStatus: boolean;

    @ApiProperty()
    orderDetailId: number

    @ApiProperty()
    manageServiceFormId: number

    @ApiProperty()
    employeeWorkStatus:string
}
