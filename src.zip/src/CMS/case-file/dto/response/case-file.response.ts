import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';

export class CaseFileResponse {
    @ApiProperty()
    @Expose()
    id: number;

    @ApiProperty()
    @Expose()
    caseId: number;

    @ApiProperty()
    @Expose()
    folderId: number;

    @ApiProperty()
    @Expose()
    fileActualName: string;

    @ApiProperty()
    @Expose()
    filePath: string;

    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    createdDate?: Date;

    @ApiProperty()
    @Expose()
    createdby?: string;

    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    updatedDate?: Date;

    @ApiProperty()
    @Expose()
    description: string;

    @ApiProperty()
    @Expose()
    specialNote: string;

    @ApiProperty()
    @Expose()
    fileUploadType:string;

    @ApiProperty()
    @Expose()
    status:string;

    // @ApiProperty()
    // dashboardStatus: boolean;

    @ApiProperty()
    @Expose()
    orderDetailId: number

    @ApiProperty()
    @Expose()
    manageServiceFormId: number;

    @ApiProperty()
    @Expose()
    employeeWorkStatus:string

}
