import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CaseFileResponse } from './case-file.response';

export class CaseFileWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CaseFileResponse | CaseFileResponse[];

  constructor(message: string, data: CaseFileResponse | CaseFileResponse[]) {
    this.data = data;
    this.message = message;
  }
}
