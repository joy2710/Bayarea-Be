import { Module, forwardRef } from '@nestjs/common';
import { CaseFileService } from './case-file.service';
import { CaseFileController } from './case-file.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CaseFile } from './entities/case-file.entity';
import { EventLog } from '../event-log/entities/event-log.entity';
import { EventLogService } from '../event-log/event-log.service';
import { FolderModule } from '../folder/folder.module';
import { Folder } from '../folder/entities/folder.entity';
import { FolderService } from '../folder/folder.service';
import { SettingModule } from '../setting/setting.module';
import { SettingService } from '../setting/setting.service';
import { Setting } from '../setting/entities/setting.entity';
import { ProductOrderDetailFormModule } from '../product-order-detail-form/product-order-detail-form.module';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { ProductOrderDetailFormService } from '../product-order-detail-form/product-order-detail-form.service';
import { Cases } from '../cases/entities/cases.entity';
import { ClientModule } from '../client/client.module';
import { ConfigService } from '@nestjs/config';
import { StatusLookupModule } from '../status-lookup/status-lookup.module';

@Module({
  imports: [TypeOrmModule.forFeature([CaseFile,EventLog,Folder,ProductOrderDetailForm,Setting,Cases]),forwardRef(() => FolderModule),forwardRef(() => ProductOrderDetailFormModule),forwardRef(() => SettingModule),forwardRef(() => ClientModule),forwardRef(() => StatusLookupModule)],
  controllers: [CaseFileController],
  providers: [CaseFileService,EventLogService,FolderService,ProductOrderDetailFormService,SettingService,ConfigService],
  exports:[CaseFileService,EventLogService,FolderService,ProductOrderDetailFormService,SettingService]
})
export class CaseFileModule {}
