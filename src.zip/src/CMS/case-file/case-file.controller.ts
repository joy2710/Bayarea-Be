import { Controller, Get, Post, Body, Patch, Param, Delete, UseInterceptors, UploadedFile, UseGuards, Req } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { Observable, of } from 'rxjs';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { storage } from 'src/common/helpers/uploadImage/uploadImage';
import { CaseFileParentRoute, CaseFileRoutes } from './case-file.http.routes';
import { CaseFileService } from './case-file.service';
import { CreateCaseFileDto } from './dto/request/create-case-file.dto';
import { UpdateCaseFileDto } from './dto/request/update-case-file.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('case-file')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CaseFileParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class CaseFileController {
  constructor(private readonly caseFileService: CaseFileService) {}

  @Post(CaseFileRoutes.create)
  create(@Body() createCaseFileDto: CreateCaseFileDto, @Req() req) {
   
    return this.caseFileService.create(createCaseFileDto,req);
  }

  @Get(CaseFileRoutes.view_all)
  findAll() {
    return this.caseFileService.findAll();
  }

  @Public()
  @Get(CaseFileRoutes.view_one)
  findOne(@Param('caseFileId') id: string) {
    return this.caseFileService.findOne(+id);
  }

  @Public()
  @Post(CaseFileRoutes.update)
  update(@Param('caseFileId') id: string, @Body() updateCaseFileDto: UpdateCaseFileDto) {
    return this.caseFileService.update(+id, updateCaseFileDto);
  }

  @Public()
  @Post(CaseFileRoutes.updateArchive)
  updateArchive(@Param('caseFileId') id: string, @Req() req, @Body() updateCaseFileDto: UpdateCaseFileDto) {
    return this.caseFileService.updateArchive(+id,req, updateCaseFileDto);
  }

  @Public()
  @Post(CaseFileRoutes.update_all)
  updateAll(@Req() req) {
    return this.caseFileService.updateAll(req);
  }

  @Delete(CaseFileRoutes.delete)
  remove(@Param('caseFileId') id: string, @Req() req) {
    return this.caseFileService.remove(+id,req);
  }

  @Public()
  @Post(CaseFileRoutes.file_upload)
  @UseInterceptors(FileInterceptor('file', storage))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {
    return of({ fileActualName: `${file.filename}`, filePath: `${file.destination}/${file.filename}` })
  }

  @Get(CaseFileRoutes.get_case_file_by_case_id)
  getCaseFileByCaseId(@Param('caseId') caseId: string) {
    return this.caseFileService.getCaseFileByCaseId(+caseId);
  }

  @Get(CaseFileRoutes.get_case_file_by_client_id)
  getCaseFileByClientId(@Param('clientId') clientId: string) {
    return this.caseFileService.getCaseFileByClientId(+clientId);
  }

  @Post(CaseFileRoutes.update_case_file_by_client_id)
  updateCaseFileByClientId(@Req() req) {
    return this.caseFileService.updateCaseFileByClientId(req);
  }

    @Post(CaseFileRoutes.update_case_file)
    updateOrderInBulk(@Req() req) {
      return this.caseFileService.updateCaseFileInBulk(req);
    }
}
