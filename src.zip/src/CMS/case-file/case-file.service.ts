import {
  forwardRef,
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CreateCaseFileDto } from './dto/request/create-case-file.dto';
import { UpdateCaseFileDto } from './dto/request/update-case-file.dto';
import { CaseFileWithMessageResponse } from './dto/response/caseFileWithResponse';
import { CaseFile } from './entities/case-file.entity';
import { EventLogService } from '../event-log/event-log.service';
import { ModuleName } from '../event-log/entities/module-name.enum';
import { CaseFiles } from '../event-log/entities/event-name.enum';
import { Folder } from '../folder/entities/folder.entity';
import { IMail } from 'src/common/model/interface/IMail';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { ProductOrderDetailFormStatus } from '../product-order-detail-form/entities/approve-type.enum';
import { DocumentUploadStatus } from './entities/status.enum';
import { Cases } from '../cases/entities/cases.entity';
import { ClientService } from '../client/client.service';
import { ConfigService } from '@nestjs/config';
import { StatusLookupService } from '../status-lookup/status-lookup.service';

var docController = require('../../common/helpers/pdf-generator/doc.controller');
const moment = require('moment');
var fs = require('fs');
var btoa = require('btoa');

@Injectable()
export class CaseFileService {
  constructor(
    @InjectRepository(CaseFile)
    private caseFileRepository: Repository<CaseFile>,
    @InjectRepository(Folder)
    private readonly FolderRepository: Repository<Folder>,
    @InjectRepository(ProductOrderDetailForm)
    private readonly productOrderDetailFormRepository: Repository<ProductOrderDetailForm>,
    @InjectRepository(Cases) private casesRepository: Repository<Cases>,
    private eventLogService: EventLogService,
    private readonly mailsService: MailService,
    @Inject(forwardRef(() => ClientService))
     private clientService : ClientService,
     private configService: ConfigService,
     @Inject(forwardRef(() => StatusLookupService))
     private statusLookupService: StatusLookupService,

  ) {}
  async create(
    createCaseFileDto: CreateCaseFileDto,
    req
  ): Promise<CaseFileWithMessageResponse> {
    createCaseFileDto['status'] = DocumentUploadStatus.Submitted_For_Approval;
    const result = await this.caseFileRepository.save(createCaseFileDto);
    const singleCase = await this.casesRepository.findOne(result.caseId);
    const caseId = result.caseId
    const caseOrderDetailData = await this.casesRepository
      .createQueryBuilder('case')
      .leftJoinAndSelect('case.orderDetail', 'orderDetail')
      .leftJoinAndSelect('orderDetail.order', 'order')
      .where('case.id = :caseId', { caseId})
      .select([
        'case.id',              
        'orderDetail.id',      
        'order',             
      ])
      .getOne();
      let orderData;
      if (caseOrderDetailData && caseOrderDetailData.orderDetail) {
         orderData = caseOrderDetailData.orderDetail[0]?.order;
      }
    await this.eventLogService.create({
      moduleName: ModuleName.CASE_FILE,
      eventName: CaseFiles.ADD_CASE_FILE,
      baseCaseNumber:singleCase.baseCaseNumber,
      eventUserId: req.headers['userdetailid'],
      eventUserName: req.headers['userdetail'],
      eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
      oldValue: '',
      newValue: JSON.stringify(result),
      eventPrimeryKey: result.id,
    });
    const newCaseData =  {
      baseCaseNumber:singleCase.baseCaseNumber,
      caseNumber :singleCase.caseNumber,
      clientId:singleCase.clientId,
      status:singleCase.status,
      originType:singleCase.originType,
      createdDate:singleCase.createdDate
    }
  //   const CasetypeValue = otherData["1"];
  //   const qualityVlaue = otherData["4"];
  //   const caseStatusValue = otherData["8"];
  //   const newCaseData = {
  //     'case number': singleCase.caseNumber,
  //     'case type': CasetypeValue,
  //     'Quality': qualityVlaue,
  //     'Case Status': caseStatusValue,
  //     'origin type': singleCase.originType,
  // };
  const pathPrefix = `${this.configService.get<string>(
    'FOLDER_PATH',
  )}/`;

    const statusLookup: any = await this.statusLookupService.getByStatusName('Upload Document Page');
    const updatedCaseFiles = (Array.isArray(result) ? result : [result]).map((file: any) => {
      const status = statusLookup.data.find(status => status.id.toString() === file.status);
    const createdDate = file.createdDate ? moment(new Date(file.createdDate)).format(
      'YYYY-MM-DD',
    ): null;
    const description = file.description ? file.description.replace(/<\/?[^>]+(>|$)/g, "") : "";
    const filePath =
                  pathPrefix + file.filePath.replace(/ /g, '%20');
      return {
        ...file,
        status: status ? status.displayName : file.status, 
        createdDate,  
        filePath,
        description
      };
    });
    let frontUrl = this.configService.get<string>('FRONT_URL');
    var mail: IMail = {
      to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
      subject: `CIS Update: case updated, case # ${singleCase.caseNumber} ${(orderData?.firstName + ' ' + (orderData?.middleName ?? '') + ' ' + orderData?.lastName)}  ${btoa(orderData?.id).replace(/=+$/, '')}`,
      url: req.headers['userdetail']+ ' ' + 'has uploaded new document',
      data: newCaseData,
      orderdata: updatedCaseFiles,
      requestdata: req.headers['userdetailid'],
      fronturl: frontUrl,
    };
    await this.mailsService.sendingMail(mail, TemplateTypes.new_case_file);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Case-file`,
        data: result,
      };
    }
  }


  async findAll(): Promise<any> {
    const result = await this.caseFileRepository.find({
      relations: ['folder', 'case'],
    });
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Case-file`,
        data: result,
      };
    }
  }

  async findOne(caseFileId: number): Promise<CaseFileWithMessageResponse> {
    try {
      const result = await this.caseFileRepository.findOne({
        where: { id: caseFileId },
      });
      if (!result)
        throw new HttpException(`Case-file id not exist`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Case-file`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }

  async update(
    caseFileId: number,
    updateCaseFileDto: UpdateCaseFileDto,
  ): Promise<CaseFileWithMessageResponse> {
    const data = await this.caseFileRepository.findOne(caseFileId);
    if (!data) {
      throw new HttpException(`Case-file id not exist`, HttpStatus.NOT_FOUND);
    }
   await this.caseFileRepository.update(caseFileId, updateCaseFileDto);
    const result = await this.caseFileRepository.findOne(caseFileId);
    const singleCase = await this.casesRepository.findOne(data.caseId);
    const newCaseData =  {
      baseCaseNumber:singleCase.baseCaseNumber,
      caseNumber :singleCase.caseNumber,
      clientId:singleCase.clientId,
      status:singleCase.status,
      originType:singleCase.originType,
      createdDate:singleCase.createdDate
    }
    // const CasetypeValue = otherData['1'];
    // const qualityVlaue = otherData['4'];
    // const caseStatusValue = otherData['8'];
    // const newCaseData = {
    //   'case number': singleCase.caseNumber,
    //   'case type': CasetypeValue,
    //   Quality: qualityVlaue,
    //   'Case Status': caseStatusValue,
    //   'origin type': singleCase.originType,
    // };
    // console.log('222222')
    const statusLookup: any = await this.statusLookupService.getByStatusName(
      'Upload Document Page',
    );
    const pathPrefix = `${this.configService.get<string>('FOLDER_PATH')}/`;
    const updatedCaseFiles = (Array.isArray(result) ? result : [result]).map(
      (file: any) => {
        const status = statusLookup.data.find(
          (status) => status.id.toString() === file.status,
        );
        const createdDate = file.createdDate
          ? moment(new Date(file.createdDate)).format('YYYY-MM-DD')
          : null;

        const description = file.description
          ? file.description.replace(/<\/?[^>]+(>|$)/g, '')
          : '';
        const filePath = pathPrefix + file.filePath.replace(/ /g, '%20');
        return {
          ...file,
          status: status ? status.displayName : file.status,
          createdDate,
          filePath,
          description,
        };
      },
    );

    const unChangesCaseFiles = (Array.isArray(data) ? data : [data]).map(
      (file: any) => {
        const status = statusLookup.data.find(
          (status) => status.id.toString() === file.status,
        );
        const createdDate = file.createdDate
          ? moment(new Date(file.createdDate)).format('YYYY-MM-DD')
          : null;
        const description = file.description
          ? file.description.replace(/<\/?[^>]+(>|$)/g, '')
          : '';
        const filePath = pathPrefix + file.filePath.replace(/ /g, '%20');
        return {
          ...file,
          status: status ? status.displayName : file.status,
          createdDate,
          filePath,
          description,
        };
      },
    );
    const oldData = JSON.stringify(unChangesCaseFiles);
    const newData = JSON.stringify(updatedCaseFiles);
    const oldCaseFiles = JSON.parse(oldData);
    const newCaseFiles = JSON.parse(newData);
    const newCaseFileData = {
      'Doc Type': newCaseFiles[0].fileUploadType,
      'File name': newCaseFiles[0].fileActualName,
      'Description  ': newCaseFiles[0].description,
      'File Date': newCaseFiles[0].createdDate,
      Status: newCaseFiles[0].status,
    };
    const oldCaseFileData = {
      'Doc Type': oldCaseFiles[0].fileUploadType,
      'File name': oldCaseFiles[0].fileActualName,
      'Description  ': oldCaseFiles[0].description,
      'File Date': oldCaseFiles[0].createdDate,
      Status: oldCaseFiles[0].status,
    };
    let changes: { key: string; oldValue: any; newValue: any }[] = [];
    let notChanges: { key: string; oldValue: any; newValue: any }[] = [];
    let finalChanges = {};

    const deepEqual = (a, b) => {
      if (Array.isArray(a) && Array.isArray(b)) {
        return JSON.stringify(a) === JSON.stringify(b);
      }
      return a === b;
    };
    if (newData !== oldData) {
      Object.keys(newCaseFileData).forEach((key) => {
        if (!deepEqual(oldCaseFileData[key], newCaseFileData[key])) {
          changes.push({
            key: key,
            oldValue: oldCaseFileData[key],
            newValue: key === 'clientRootPath' ? '' : newCaseFileData[key],
          });
        } else {
          notChanges.push({
            key: key,
            oldValue: oldCaseFileData[key],
            newValue: '',
          });
        }
      });
      finalChanges = [...changes, ...notChanges];
    }
    const caseId= data.caseId
    const caseOrderDetailData = await this.casesRepository
    .createQueryBuilder('case')
    .leftJoinAndSelect('case.orderDetail', 'orderDetail')
    .leftJoinAndSelect('orderDetail.order', 'order')
    .where('case.id = :caseId', { caseId})
    .select([
      'case.id',              
      'orderDetail.id',     
      'order',          
    ])
    .getOne();
    let orderData;
    if (caseOrderDetailData && caseOrderDetailData.orderDetail) {
       orderData = caseOrderDetailData.orderDetail[0]?.order;
    }
    let frontUrl = this.configService.get<string>('FRONT_URL');
    var mail: IMail = {
      to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
      subject: `CIS Update: case updated, case # ${singleCase.caseNumber} ${(orderData?.firstName + ' ' + (orderData?.middleName ?? '') + ' ' + orderData?.lastName)}  ${btoa(orderData?.id).replace(/=+$/, '')}`,
      url: 'Document has been updated',
      data: newCaseData,
      orderdata: finalChanges,
      fronturl: frontUrl,
    };
    await this.mailsService.sendingMail(mail, TemplateTypes.update_case_file);
    return {
      message: `${Messages.Resource.Updated} : Case-file`,
    };
  }


 async updateArchive(caseFileId: number,
    req,
    updateCaseFileDto: UpdateCaseFileDto,
    ): Promise<CaseFileWithMessageResponse>{
     
      const data = await this.caseFileRepository.findOne(caseFileId);
      if (!data) {
        throw new HttpException(`Case-file id not exist`, HttpStatus.NOT_FOUND);
      }
      var moment = require('moment');
      let date = moment(new Date()).format("hh:mm");
      fs.copyFileSync(
        `${this.configService.get<string>('UPLOADED_FILES')}/${data.fileActualName}`,
        `${this.configService.get<string>('UPLOADED_FILES_OLD')}/${data.fileActualName.replace('.', `_OLD.`)}`,
      );
      updateCaseFileDto['status'] = DocumentUploadStatus.Archived;
      const result = await this.caseFileRepository.update(caseFileId, updateCaseFileDto);
      const dataUpdated = await this.caseFileRepository.findOne(caseFileId);
      const productform = await this.productOrderDetailFormRepository.find({
        where: { documentId: dataUpdated.id },
      })
      for (let x of productform) {
        await this.productOrderDetailFormRepository.update(x.id, {
          userAnswer:'',
          isApprove: ProductOrderDetailFormStatus.NOTSTARTED,
        })
      }
      const singleCase = await this.casesRepository.findOne(data.caseId);
      await this.eventLogService.create({
        moduleName: ModuleName.CASE_FILE,
        eventName: CaseFiles.DELETE_CASE_FILE,
        baseCaseNumber:singleCase.baseCaseNumber,
        eventUserId: req.headers['userdetailid'],
        eventUserName: req.headers['userdetail'],
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue: JSON.stringify(data),
        newValue:JSON.stringify(dataUpdated),
        eventPrimeryKey: data.id,
      });
      return {
        message: `${Messages.Resource.Updated} : Case-file`,
      };
  
  }
  async updateAutoArchive(caseFileId: number,
    request,
    updateCaseFileDto: UpdateCaseFileDto,
    ): Promise<CaseFileWithMessageResponse>{
  
      const data = await this.caseFileRepository.findOne(caseFileId);
      if (!data) {
        throw new HttpException(`Case-file id not exist`, HttpStatus.NOT_FOUND);
      }

      var moment = require('moment');
      // let date = moment(new Date()).format("hh:mm");
      // fs.copyFileSync(
      //   `${this.configService.get<string>('UPLOADED_FILES')}/${data.fileActualName}`,
      //   `${this.configService.get<string>('UPLOADED_FILES')}/${data.fileActualName.replace('.', `_ARCHIVED`)}`,
      // );
      updateCaseFileDto['status'] = DocumentUploadStatus.Archived;
      const result = await this.caseFileRepository.update(caseFileId, updateCaseFileDto);
      const dataUpdated = await this.caseFileRepository.findOne(caseFileId);
      const singleCase = await this.casesRepository.findOne(dataUpdated.caseId);
      await this.eventLogService.create({
        moduleName: ModuleName.CASE_FILE,
        eventName: CaseFiles.DELETE_CASE_FILE,
        baseCaseNumber:singleCase.baseCaseNumber,
        eventUserId: request.headers['userdetailid'],
        eventUserName: request.headers['userdetail'],
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue: JSON.stringify(data),
        newValue:JSON.stringify(dataUpdated),
        eventPrimeryKey: data.id,
      });
      return {
        message: `${Messages.Resource.Updated} : Case-file`,
      };
  
  }


  async remove(
    caseFileId: number,
    req
  ): Promise<CaseFileWithMessageResponse> {
    try {
      const result = await this.caseFileRepository.findOne({
        where: { id: caseFileId },
      });
      var moment = require('moment');
      let date = moment(new Date()).format("hh:mm");
      fs.copyFileSync(
        `${this.configService.get<string>('UPLOADED_FILES')}/${result.fileActualName}`,
        `${this.configService.get<string>('UPLOADED_FILES_OLD')}/${result.fileActualName.replace('.', `_ARCHIVED`)}`,
      );

      const deleteCaseAssign = await this.caseFileRepository.delete(caseFileId);
      const dataUpdated = await this.caseFileRepository.findOne(caseFileId);
      const singleCase = await this.casesRepository.findOne(dataUpdated.caseId);
      await this.eventLogService.create({
        moduleName: ModuleName.CASE_FILE,
        eventName: CaseFiles.DELETE_CASE_FILE,
        baseCaseNumber:singleCase.baseCaseNumber,
        eventUserId: req.headers['userdetailid'],
        eventUserName: req.headers['userdetail'],
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue: JSON.stringify(result),
        newValue: '',
        eventPrimeryKey: result.id,
      });
      if (deleteCaseAssign.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Case-file`,
        };
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async getCaseFileByCaseId(caseId: number) {
    const result = await this.caseFileRepository
      .createQueryBuilder('caseFile')
      .leftJoinAndSelect('caseFile.case', 'case')
      .leftJoinAndSelect('caseFile.folder', 'folder')
      .where('case.id = :caseId', { caseId: caseId })
      .getMany();
    return result;
  }

  async getCaseFileByClientId(clientId: number) {
    const result = await this.caseFileRepository
      .createQueryBuilder('caseFile')
      .leftJoinAndSelect('caseFile.case', 'case')
      .where('case.clientId = :clientId', { clientId: clientId })
      .getMany();
    return result;
  }

  caseId: number;
  
  async updateAll(req: any): Promise<any> {
    let list: any[] = [];
    let filePath: string;
    const staticRoot = await this.FolderRepository
      .createQueryBuilder('folder')
      .select('folder.name', 'name')
      .where(`folder.systemfunction = 'Approved Final ID'`)
      .getRawOne();
  
    // Process each ID and collect data
    await Promise.all(
      req.body.id.map(async (x) => {
        const res = await this.caseFileRepository.findOne({
          where: { id: x },
          relations: ['case', 'case.client','case.orderDetail' , 'case.orderDetail.order'],
        });
        
        if (res) {
          await this.caseFileRepository.update(res.id, {
            status: DocumentUploadStatus.Client_Approved_For_Work,
          });
          this.caseId = res.caseId;
          list.push(res);
        }
      })
    );
  
    // Ensure there is data to process
    if (list.length === 0) {
      throw new HttpException(
        `${Messages.Resource.Updated} : Validate Document Updated`,
        HttpStatus.NOT_FOUND
      );
    }
  
    // Map the data for further processing
    const mappedData = list.map((item: any) => {
      return {
        Description: item.description,
        fileName: item.fileActualName,
        caseNumber: item.case.baseCaseNumber,
        downloadFilePth: item.filePath,
        clientRootPath: `${item.case.client.clientRootPath}/${item.case.baseCaseNumber}/${staticRoot.name}`,
        firstName: item.case.client.firstName,
        finalCaseNumber: item.case.caseNumber,
        id: item.case.id,
        manageServiceFormId:item.manageServiceFormId
      };
    });
     const clientDashboardData:any = await this.clientService.findClientDashboardDetailsByCLientId(list[0].case.clientId)
     clientDashboardData.forEach((x) => {
      if (x.url.search(this.configService.get<string>('FRONT_URL')) === -1) {
        x.url = `${this.configService.get<string>('FRONT_URL')}${x.url}`;
      }
      x.status_date = moment(x.status_date).format('YYYY-MM-DD');
    });
    const orderData =list[0].case.orderDetail[0]?.order
    const object = mappedData[0];
    await this.eventLogService.create({
      moduleName: ModuleName.CASE_FILE,
      eventName: CaseFiles.CASE_FILE_APPROVED,
      baseCaseNumber: object.caseNumber,
      eventUserId: req.headers['userdetailid'],
      eventUserName: req.headers['userdetail'],
      eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
      oldValue: JSON.stringify(object),
      newValue: '',
      eventPrimeryKey: object.id,
    });
    // Generate file path
    filePath = await docController.print(mappedData);
  
    try {
      let date = moment(new Date()).format('YYYY-MMMM-DD');
      const existingFile = await this.caseFileRepository.findOne({
        where: { filePath: filePath },
      });
  
      const fs = require("fs");
      const stats = fs.statSync(mappedData[0].downloadFilePth);
      const fileSize = stats.size / (1024 * 1024);
      if (!existingFile) {
        let  fileActualName = filePath.replace(`${this.configService.get<string>('UPLOADED_FILES_OLD')}/`,'')
        await this.caseFileRepository.save({
          caseId: this.caseId,
          filePath: filePath,
          fileActualName: fileActualName,
          fileUploadType:'Validated Docs',
          description: 'Client Approved documents to use as the basis for this casework',
          status: DocumentUploadStatus.Client_Validated_Docs,
          createdDate: date,
        });
  
        let attachmentFilePathZip = [];
        const actualfile = filePath.replace(`${this.configService.get<string>('UPLOADED_FILES_OLD')}`+'/', "")
        if (fileSize <= 20) {
          attachmentFilePathZip.push(actualfile);
        }
        clientDashboardData[5].active = true;
        const subjectsub = `CIS Update: Final ID Documents validated, ${mappedData[0].finalCaseNumber} ${attachmentFilePathZip}`;
        let frontUrl =`${this.configService.get<string>('FRONT_URL')}`;
        const mail: IMail = {
          to: `${this.configService.get<string>('ADMIN_EMAIL')}`,
          subject: subjectsub,
          orderdata:orderData,
          otherdata: clientDashboardData,
          data: mappedData[0].firstName,
          requestdata: req.headers['userdetailid'],
          attachmentFilePathZip: attachmentFilePathZip,
          fronturl: frontUrl
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.Validate_Docs);
        console.log(`File inserted for filePath: ${filePath}`);
      } else {
        console.log(`File with filePath ${filePath} already exists. Not inserting a duplicate.`);
      }
    } catch (error) {
      console.error('Error during file insertion:', error);
    }
  }
  

  async updateCaseFileByClientId(req: any) {
    const ids = req.body.id;
    ids.map(async (id: any) => {
      // await this.caseFileRepository.update(id, {
      //   dashboardStatus:true
      // });
      const singleCasefile = await this.caseFileRepository.findOne(id);
      const singleCase = await this.casesRepository.findOne(singleCasefile.caseId);
      await this.eventLogService.create({
        moduleName: ModuleName.CASE_FILE,
        eventName: CaseFiles.CASE_FILE_VALIDATE,
        baseCaseNumber:singleCase.baseCaseNumber,
        eventUserId: req.headers['userdetailid'],
        eventUserName: req.headers['userdetail'],
        eventDateTime: moment(new Date()).format('YYYY-MM-DD HH:mm'),
        oldValue: '',
        newValue: JSON.stringify(singleCasefile),
        eventPrimeryKey: singleCasefile.id,
      });
    })
    return {
      message: `${Messages.Resource.Updated} : Case-file`,
    };
  }
 
  async updateCaseFileInBulk(req: any): Promise<any> {
    const ids = req.body.id;
    let updatedData: any;
        updatedData = {  
          status: req.body.status,
        };
    
    for (let id of ids) {
      await this.caseFileRepository.update(id, updatedData);
    }
    return {
      message: `${Messages.Resource.Updated} : case-file`,
    };
  }
}

