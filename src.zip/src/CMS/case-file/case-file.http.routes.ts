export const CaseFileParentRoute = 'case-file';

export const CaseFileRoutes = {
  create: '',
  update: 'update/:caseFileId',
  delete: ':caseFileId',
  view_one: ':caseFileId',
  view_all: '',
  file_upload: 'fileUpload',
  get_case_file_by_case_id: 'getCaseFileByCaseId/:caseId',
  get_case_file_by_client_id: 'getCaseFileByClientId/:clientId',
  update_all:'updateAll/updateFile',
  updateArchive:'updateArchive/:caseFileId',
  update_case_file_by_client_id: 'validateSelectedCaseFile',
  update_case_file: 'updateCaseFile',
};
