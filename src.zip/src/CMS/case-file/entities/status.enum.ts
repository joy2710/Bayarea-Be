export enum DocumentUploadStatus {
    Submitted_For_Approval = '2',
    Client_Approved_For_Work= '3',
    Archived  = '4',
    Client_Validated_Docs='5',
}