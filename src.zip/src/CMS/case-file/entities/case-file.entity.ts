import { Cases } from "src/CMS/cases/entities/cases.entity";
import { Folder } from "src/CMS/folder/entities/folder.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"

@Entity({ name: 'case-file' })
export class CaseFile {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({nullable:false})
    caseId: number;

    @ManyToOne(() => Cases, (cases: Cases) => cases.caseFile, {
        eager: false,
        onDelete: 'CASCADE'
    })
    case: Cases[];

    @Column({default: null})
    folderId: number;

    @ManyToOne(() => Folder, (folder: Folder) => folder.caseFile, {
        eager: false,
        onDelete: 'CASCADE'
    })
    folder: Folder[];

    @Column({})
    fileActualName: string;

    @Column({nullable:false})
    filePath: string;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    
    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({nullable:false,type: 'longtext'})
    description: string;

    @Column()
    specialNote:string;

    @Column({nullable:false})
    fileUploadType:string;

    @Column({nullable:false})
    status:string;

    // @Column({ default:false })
    // dashboardStatus: boolean;

    @Column({default: null})
    orderDetailId: number

    @Column({default: null})
    manageServiceFormId: number;

    @Column()
    employeeWorkStatus:string;
}
