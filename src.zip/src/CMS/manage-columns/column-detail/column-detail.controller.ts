import { Controller, Get, Post, Body, Param, Delete, UseGuards, Req } from '@nestjs/common';
import { ColumnDetailService } from './column-detail.service';
import { CreateColumnDetailDto } from './dto/request/create-column-detail.dto';
import { UpdateColumnDetailDto } from './dto/request/update-column-detail.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { columnDetailParentRoute, columnDetailRoutes } from './column-detail.http.routes';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Column-Detail')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path:columnDetailParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class ColumnDetailController {
  constructor(private readonly columnDetailService: ColumnDetailService) {}

  @Post(columnDetailRoutes.create)
  createColumnDetail(@Body() body: CreateColumnDetailDto, @Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.columnDetailService.create(body, userDetail,userdetailid);
  }

  @Get(columnDetailRoutes.view_all)
  findAllColumnDetail() {
    return this.columnDetailService.findAll();
  }

  @Get(columnDetailRoutes.view_one)
  findColumnDetailById(@Param('columnDetailId') id: string) {
    return this.columnDetailService.findOne(+id);
  }

  @Post(columnDetailRoutes.update)
  updateColumnDetailById(@Param('columnDetailId') id: string, @Body() body: UpdateColumnDetailDto, @Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.columnDetailService.update(+id, body,userDetail,userdetailid);
  }

  @Delete(columnDetailRoutes.delete)
  removeColumnDetailById(@Param('columnDetailId') id: string, @Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.columnDetailService.remove(+id,userDetail,userdetailid);
  }

// GET-BY-FORMTYPE
  @Get(columnDetailRoutes.getByFormType)
  getColumnsDetailByFormtype(@Param('formType') formType: string) {
    return this.columnDetailService.getByFormType(formType);
  }

  // GET-ALL-COLUMNS-BY-FORMTYPE
  @Public()
  @Get(columnDetailRoutes.getAllByFormType)
  getAllColumnsDetailByFormtype(@Param('formType') formType: string) {
    return this.columnDetailService.getAllByFormType(formType);
  }
}
