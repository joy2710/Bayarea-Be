import { Test, TestingModule } from '@nestjs/testing';
import { ColumnDetailService } from './column-detail.service';

describe('ColumnDetailService', () => {
  let service: ColumnDetailService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ColumnDetailService],
    }).compile();

    service = module.get<ColumnDetailService>(ColumnDetailService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
