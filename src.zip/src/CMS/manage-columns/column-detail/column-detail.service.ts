import { BadRequestException, HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Messages } from 'src/common/constants/messages';
import { CreateColumnDetailDto } from './dto/request/create-column-detail.dto';
import { UpdateColumnDetailDto } from './dto/request/update-column-detail.dto';
import { ColumnDetailWithMessageResponse } from './dto/response/columnDetailWithResponce';
import { ColumnDetail } from './entities/column-detail.entity';
import { ColumnDetailStatus } from './entities/status.enum';
import { EventLogService } from 'src/CMS/event-log/event-log.service';
import { ModuleName } from 'src/CMS/event-log/entities/module-name.enum';
import { AdminAction, CisColumnAction, ClientColumnAction } from 'src/CMS/event-log/entities/event-name.enum';
import { FormType } from './entities/form-type.enum';
const moment = require('moment');

@Injectable()
export class ColumnDetailService {

  constructor(
    @InjectRepository(ColumnDetail) private columnDetailRepository: Repository<ColumnDetail>,
    private eventLogService: EventLogService
  ) { }

  async create(request: CreateColumnDetailDto,userDetail,userdetailid): Promise<ColumnDetailWithMessageResponse> {
    try {
      const columnDetail = await this.columnDetailRepository.create(request);
      const result = await this.columnDetailRepository.save(columnDetail);
     
      if (result.formType == FormType.CIS_COLUMNS) {
        await this.eventLogService.create({
          moduleName: ModuleName.CIS_COLUMN,
          eventName: CisColumnAction.ADD_CIS_COLUMN,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
          oldValue: '',
         newValue : JSON.stringify(result),
         eventPrimeryKey: result.id
    
        });
      }
      else if (result.formType == FormType.CLIENT_COLUMNS) {
        await this.eventLogService.create({
          moduleName: ModuleName.CLIENT_COLUMN,
          eventName: ClientColumnAction.ADD_CLIENT_COLUMN,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
          oldValue: JSON.stringify(result),
         newValue : '',
         eventPrimeryKey: result.id
    
        });
      }
      else if (result.formType == FormType.ADMIN_COLUMNS) {
        await this.eventLogService.create({
          moduleName: ModuleName.ADMIN_COLUMN,
          eventName: AdminAction.ADD_ADMIN_COLUMN,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
          oldValue: JSON.stringify(result),
         newValue : '',
         eventPrimeryKey: result.id
    
        });
      }
      return {
        message: `${Messages.Resource.Created} : Column-detail`,
        data: result
      }
    } catch (error) {
      if (error.response) {
        return new BadRequestException(error?.response)

      } else {
        return new BadRequestException(error?.sqlMessage)

      }
    }
  }

  async findAll(): Promise<ColumnDetailWithMessageResponse> {
    const result = await this.columnDetailRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Column-detail`,
        data: result
      }
    }
  }

  async findOne(columnDetailId: number): Promise<ColumnDetailWithMessageResponse> {
    try {
      const result = await this.columnDetailRepository.findOne(
        {
          where:
            { id: columnDetailId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Column-detail`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Column-detail`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(columnDetailId: number, request: UpdateColumnDetailDto,userDetail,userdetailid): Promise<ColumnDetailWithMessageResponse> {
    const data = await this.columnDetailRepository.findOne(columnDetailId)
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Column-detail`, HttpStatus.NOT_FOUND);
    }
    await this.columnDetailRepository.update(columnDetailId, request);
    const updatedData= await this.columnDetailRepository.findOne(columnDetailId)
    if (data.formType == FormType.CIS_COLUMNS) {
      await this.eventLogService.create({
        moduleName: ModuleName.CIS_COLUMN,
        eventName: CisColumnAction.UPDATE_CIS_COLUMN,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
        oldValue: JSON.stringify(data),
       newValue : JSON.stringify(updatedData),
       eventPrimeryKey: updatedData.id
  
      });
    }
    else if (data.formType == FormType.CLIENT_COLUMNS) {

      await this.eventLogService.create({
        moduleName: ModuleName.CLIENT_COLUMN,
        eventName: ClientColumnAction.UPDATE_CLIENT_COLUMN,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
        oldValue: JSON.stringify(data),
        newValue : JSON.stringify(updatedData),
        eventPrimeryKey: updatedData.id
  
      });
    }
    else if (data.formType == FormType.ADMIN_COLUMNS) {
      await this.eventLogService.create({
        moduleName: ModuleName.ADMIN_COLUMN,
        eventName: AdminAction.ADD_ADMIN_COLUMN,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
        oldValue: JSON.stringify(data),
        newValue : JSON.stringify(updatedData),
        eventPrimeryKey: updatedData.id
  
      });
    }
    return {
      message: `${Messages.Resource.Updated} : Column-detail`,
    }
  }

  async remove(columnDetailId: number, userDetail,userdetailid) {
    try {
      const deletedData= await this.columnDetailRepository.findOne(columnDetailId)
      const deletecolumnDetail = await this.columnDetailRepository.delete(columnDetailId)
      //Code clean 
      // const updatedData= await this.columnDetailRepository.findOne(columnDetailId)
      if (deletedData.formType == FormType.CIS_COLUMNS) {
        await this.eventLogService.create({
          moduleName: ModuleName.CIS_COLUMN,
          eventName: CisColumnAction.DELETE_CIS_COLUMN,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
          oldValue: JSON.stringify(deletedData),
         newValue : '',
         eventPrimeryKey: deletedData.id
    
        });
      }
      else if (deletedData.formType == FormType.CLIENT_COLUMNS) {
        await this.eventLogService.create({
          moduleName: ModuleName.CLIENT_COLUMN,
          eventName: ClientColumnAction.DELETE_CLIENT_COLUMN,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
          oldValue: JSON.stringify(deletedData),
          newValue : '',
          eventPrimeryKey: deletedData.id
    
        });
      }
      else if (deletedData.formType == FormType.ADMIN_COLUMNS) {
        await this.eventLogService.create({
          moduleName: ModuleName.ADMIN_COLUMN,
          eventName: AdminAction.DELETE_ADMIN_COLUMN,
          baseCaseNumber:'',
          eventUserId: userdetailid,
          eventUserName: userDetail,
          eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
          oldValue: JSON.stringify(deletedData),
          newValue : '',
          eventPrimeryKey: deletedData.id
    
        });
      }
      if (deletecolumnDetail.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Column-detail`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
  
  // GET-COLUMNS-DETAIL-BY-FORMTYPE
  async getByFormType(formType: string): Promise<ColumnDetailWithMessageResponse> {
    const columnDetail = await this.columnDetailRepository.find({
      where:
        { formType: formType, status: ColumnDetailStatus.ACTIVE }
    });


    if (!columnDetail) {
      return {
        message: `Columns-detail not exist for this form : "${formType}"`,
        data: []
      }

    }

    return {
      message: 'Columns-detail Successfully get',
      data: columnDetail
    }
  }

  // GET-ALL-COLUMNS-DETAIL-BY-FORMTYPE
  async getAllByFormType(formType: string): Promise<ColumnDetailWithMessageResponse> {
    const columnDetail = await this.columnDetailRepository.find({
  
      where:
        { formType: formType }
    });


    if (!columnDetail) {
      return {
        message: `Columns-detail not exist for this form : "${formType}"`,
        data: []
      }

    }
    return {
      message: 'Columns-detail Successfully get',
      data: columnDetail
    }
  }
}

