import { Test, TestingModule } from '@nestjs/testing';
import { ColumnDetailController } from './column-detail.controller';
import { ColumnDetailService } from './column-detail.service';

describe('ColumnDetailController', () => {
  let controller: ColumnDetailController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ColumnDetailController],
      providers: [ColumnDetailService],
    }).compile();

    controller = module.get<ColumnDetailController>(ColumnDetailController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
