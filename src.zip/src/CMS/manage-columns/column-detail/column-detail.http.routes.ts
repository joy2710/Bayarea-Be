export const columnDetailParentRoute = 'column-detail';

export const columnDetailRoutes = {
  create: '',
  update: 'update/:columnDetailId',
  delete: ':columnDetailId',
  view_one: ':columnDetailId',
  view_all: '',
  getByFormType:'formType/:formType',
  getAllByFormType:'all-formType/:formType'
};
