import { Module } from '@nestjs/common';
import { ColumnDetailService } from './column-detail.service';
import { ColumnDetailController } from './column-detail.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ColumnDetail } from './entities/column-detail.entity';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { EventLogService } from 'src/CMS/event-log/event-log.service';
import { EventLog } from 'src/CMS/event-log/entities/event-log.entity';
import { Setting } from 'src/CMS/setting/entities/setting.entity';
import { ConfigService } from '@nestjs/config';

@Module({
  imports:[TypeOrmModule.forFeature([ColumnDetail,EventLog,Setting])],
  controllers: [ColumnDetailController],
  providers: [ColumnDetailService, MailService, EventLogService,ConfigService],
  exports: [MailService,EventLogService]
})
export class ColumnDetailModule {}
