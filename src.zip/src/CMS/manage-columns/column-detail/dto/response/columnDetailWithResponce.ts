import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ColumnDetailResponse } from './column-detail-response';

export class ColumnDetailWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: ColumnDetailResponse | ColumnDetailResponse[];

  constructor(message: string, data: ColumnDetailResponse | ColumnDetailResponse[]) {
    this.data = data;
    this.message = message;
  }
}
