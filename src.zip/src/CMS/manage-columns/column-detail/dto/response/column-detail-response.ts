import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { DataType } from '../../entities/data-type.enum';
import { FormType } from '../../entities/form-type.enum';
import { ColumnDetailStatus } from '../../entities/status.enum';

export class ColumnDetailResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty({ example: DataType })
  @Expose()
  dataType: DataType;

  @ApiProperty()
  @Expose()
  value: string[];

  @ApiProperty()
  @Expose()
  required: Boolean;

  @ApiProperty({ example: FormType })
  @Expose()
  formType: FormType;

  @ApiProperty()
  @Expose()
  groupName: string;

  @ApiProperty({ example: ColumnDetailStatus })
  @Expose()
  status: ColumnDetailStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;


  @ApiProperty()
  @Expose()
  ishideColumn:boolean;

}
