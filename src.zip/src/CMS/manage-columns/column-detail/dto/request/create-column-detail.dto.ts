import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsEnum, IsNotEmpty, IsOptional, IsString } from "class-validator";
import { DataType } from "../../entities/data-type.enum";
import { FormType } from "../../entities/form-type.enum";
import { ColumnDetailStatus } from "../../entities/status.enum";

export class CreateColumnDetailDto {

    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty({default: DataType.TEXT})
    @IsNotEmpty()
    @IsEnum(DataType)
    dataType: DataType;

    @ApiProperty({example: ["string"], isArray: true})
    @IsString({ each: true })
    @IsOptional()
    value: string[];

    @ApiProperty()
    @IsBoolean()
    required: true;

    @ApiProperty({ default: FormType.CIS_COLUMNS })
    @IsNotEmpty()
    @IsEnum(FormType)
    formType: FormType;

    @ApiProperty()
    @IsOptional()
    groupName: string;

    @ApiProperty({ default: ColumnDetailStatus.ACTIVE })
    @IsNotEmpty()
    @IsEnum(ColumnDetailStatus)
    status: ColumnDetailStatus;

    @ApiProperty()
    @IsOptional()
    ishideColumn:boolean;

}
