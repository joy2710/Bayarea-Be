import { CreateColumnDetailDto } from './create-column-detail.dto';

export class UpdateColumnDetailDto extends CreateColumnDetailDto {}
