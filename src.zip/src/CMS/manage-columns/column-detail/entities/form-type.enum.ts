export enum FormType {
    CIS_COLUMNS = 'Mng. Cases',
    CLIENT_COLUMNS = 'Mng. Client',
    ADMIN_COLUMNS='Admin Columns',
    STATUS_COLUMNS='Status Columns',
    INTAKE='Intake'
}

