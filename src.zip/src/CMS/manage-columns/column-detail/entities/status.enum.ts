export enum ColumnDetailStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}