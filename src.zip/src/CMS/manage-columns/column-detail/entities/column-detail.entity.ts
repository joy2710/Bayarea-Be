import { ColumnPermission } from "src/CMS/column-permission/entities/column-permission.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { DataType } from "./data-type.enum";
import { FormType } from "./form-type.enum";
import { ColumnDetailStatus } from "./status.enum";

@Entity({ name: 'column-detail' }) 
export class ColumnDetail {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({ unique: true, nullable: false })
    name: string;

    @Column({ default: DataType.TEXT })
    dataType: DataType;

    @Column({ type: 'simple-array', nullable: true, default: null })
    value: string[];

    @Column({ default: false, type: Boolean })
    required: true;

    @Column({ default: FormType.CIS_COLUMNS })
    formType : FormType;

    @Column({ nullable: true })
    groupName: string;

    @Column({ default: ColumnDetailStatus.ACTIVE })
    status: ColumnDetailStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @OneToMany(() => ColumnPermission, (columnPermission: ColumnPermission) => columnPermission.column)
    columnPermission: ColumnPermission;

    @Column({default: false})
    ishideColumn:boolean;

}
