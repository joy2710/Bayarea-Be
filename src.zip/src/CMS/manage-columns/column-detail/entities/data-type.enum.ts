export enum DataType {
    TEXT = 'text',
    DROPDOWN = 'dropdown',
    NUMBER='number',
}