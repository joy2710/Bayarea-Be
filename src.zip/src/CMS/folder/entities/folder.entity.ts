
import { CaseFile } from "src/CMS/case-file/entities/case-file.entity";
import { FolderPermission } from "src/CMS/folder-permission/entities/folder-permission.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { FolderStatus } from "./status.enum";

@Entity({ name: 'folder' })
export class Folder {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    systemfunction: string;

    @Column({ default: FolderStatus.INACTIVE })
    status: FolderStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
   
    @OneToMany(() => CaseFile, (caseFile: CaseFile) => caseFile.filePath)
    caseFile: CaseFile;
  
     
    @OneToMany(() => FolderPermission, (folderPermission: FolderPermission) => folderPermission.folder)
    folderPermission: FolderPermission;
}
