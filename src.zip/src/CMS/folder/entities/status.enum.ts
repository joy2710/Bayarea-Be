export enum FolderStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}