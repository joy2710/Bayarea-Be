import { Controller, Get, Post, Body, Param, Delete, UseGuards, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CreateFolderDto } from './dto/request/create-folder.dto';
import { UpdateFolderDto } from './dto/request/update-folder.dto';
import { FolderParentRoute, FolderRoutes } from './folder.https.routes';
import { FolderService } from './folder.service';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Folder')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:FolderParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class FolderController {
  constructor(private readonly folderService: FolderService) {}

  @Post(FolderRoutes.create)
  create(@Body() createFolderDto: CreateFolderDto, @Req() req) {
   let userDetail=req.headers['userdetail']
   let userdetailid=req.headers['userdetailid']
    return this.folderService.create(createFolderDto,userDetail,userdetailid);
  }

  @Public()
  @Get(FolderRoutes.view_all)
  findAll() {
    return this.folderService.findAll();
  }

  @Public()
  @Get(FolderRoutes.view_one)
  findOne(@Param('folderId') id: string) {
    return this.folderService.findOne(+id);
  }

  @Post(FolderRoutes.update)
  update(@Param('folderId') id: string, @Body() updateFolderDto: UpdateFolderDto,@Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.folderService.update(+id, updateFolderDto, userDetail,userdetailid);
  }

  @Delete(FolderRoutes.delete)
  remove(@Param('folderId') id: string, @Req() req) {
    let userDetail=req.headers['userdetail']
    let userdetailid=req.headers['userdetailid']
    return this.folderService.remove(+id, userDetail,userdetailid);
  }


  @Post(FolderRoutes.movefolder)
  copyfolder() {
    return this.folderService.copyfolder();
  }
}
