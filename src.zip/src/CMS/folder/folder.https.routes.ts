export const FolderParentRoute = 'folder';

export const FolderRoutes = {
  create: '',
  update: 'update/:folderId',
  delete: ':folderId',
  view_one: ':folderId',
  view_all: '',
  movefolder: 'syncFolder'
};