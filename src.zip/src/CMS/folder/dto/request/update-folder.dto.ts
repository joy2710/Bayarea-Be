
import { CreateFolderDto } from './create-folder.dto';

export class UpdateFolderDto extends (CreateFolderDto) {}
