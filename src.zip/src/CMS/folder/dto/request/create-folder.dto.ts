import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { FolderStatus } from "../../entities/status.enum";


export class CreateFolderDto {
    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty()
    @IsNotEmpty()
    systemfunction: string;

    @ApiProperty({ default: FolderStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(FolderStatus)
    status: FolderStatus;   
} 


