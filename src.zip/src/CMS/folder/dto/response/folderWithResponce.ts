import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { FolderResponse } from './folder-response';


export class FolderWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: FolderResponse | FolderResponse[];

  constructor(message: string, data: FolderResponse | FolderResponse[]) {
    this.data = data;
    this.message = message;
  }
}
