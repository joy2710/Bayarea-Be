import { Module, forwardRef } from '@nestjs/common';
import { FolderService } from './folder.service';
import { FolderController } from './folder.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Folder } from './entities/folder.entity';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { EventLogService } from '../event-log/event-log.service';
import { EventLog } from '../event-log/entities/event-log.entity';
import { SettingModule } from '../setting/setting.module';
import { SettingService } from '../setting/setting.service';
import { Setting } from '../setting/entities/setting.entity';
import { ConfigService } from '@nestjs/config';

@Module({
  imports: [TypeOrmModule.forFeature([Folder, EventLog,Setting]),forwardRef(() => SettingModule)],
  controllers: [FolderController],
  providers: [FolderService,MailService,EventLogService,SettingService,ConfigService],
  exports:[MailService,EventLogService,SettingService]
})
export class FolderModule {}
