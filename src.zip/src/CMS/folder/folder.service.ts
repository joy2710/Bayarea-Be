import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CreateFolderDto } from './dto/request/create-folder.dto';
import { UpdateFolderDto } from './dto/request/update-folder.dto';
import { FolderWithMessageResponse } from './dto/response/folderWithResponce';
import { Folder } from './entities/folder.entity';
import { ModuleName } from '../event-log/entities/module-name.enum';
import { FolderAction } from '../event-log/entities/event-name.enum';
import { EventLogService } from '../event-log/event-log.service';
import { Setting } from '../setting/entities/setting.entity';
import { ConfigService } from '@nestjs/config';
const moment = require('moment');
const fs = require('fs-extra')

@Injectable()
export class FolderService {
  constructor(
    @InjectRepository(Folder) private folderRepository: Repository<Folder>,
    private eventLogService: EventLogService,
    @InjectRepository(Setting)
    private readonly settingRepository: Repository<Setting>,
    private configService: ConfigService

  ) { }
  async create(createFolderDto: CreateFolderDto, userDetail,userdetailid): Promise<FolderWithMessageResponse> {
    const folder = await this.folderRepository.create(createFolderDto);
    const existingFile = await this.folderRepository.findOne({
      where:
        { systemfunction: folder.systemfunction}
    });
    if(!existingFile){
    const result = await this.folderRepository.save(folder);
    await this.eventLogService.create({
      moduleName: ModuleName.FOLDER,
      eventName: FolderAction.ADD_FOLDER,
      baseCaseNumber:'',
      eventUserId: userdetailid,
      eventUserName: userDetail,
      eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
      oldValue: '',
     newValue : JSON.stringify(result),
     eventPrimeryKey:result.id,

    });
    const mailNewData = {
      'Folder name': result.name,
    }
    return {
      message: `${Messages.Resource.Created} : Folder`,
      data: result
    }
  }

  }

  async findAll(): Promise<FolderWithMessageResponse> {
    const result = await this.folderRepository.find()
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Folder`,
        data: result
      }
    }
  }

  async findOne(folderId: number): Promise<FolderWithMessageResponse> {
    try {
      const result = await this.folderRepository.findOne(
        {
          where:
            { id: folderId }
        }
      );
      if (!result)
        throw new HttpException(`Folder-id not exist`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Folder`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(folderId: number, updateFolderDto: UpdateFolderDto, userDetail,userdetailid): Promise<FolderWithMessageResponse> {
    const data = await this.folderRepository.findOne(folderId);

    if (!data) {
      throw new HttpException(`Folder-id not exist`, HttpStatus.NOT_FOUND);
    }
    await this.folderRepository.update(folderId, updateFolderDto)
    const updatedData = await this.folderRepository.findOne(folderId)
    await this.eventLogService.create({
      moduleName: ModuleName.FOLDER,
      eventName: FolderAction.UPDATE_FOLDER,
      baseCaseNumber:'',
      eventUserId: userdetailid,
      eventUserName: userDetail,
      eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
      oldValue: JSON.stringify(data),
      newValue: JSON.stringify(updatedData),
      eventPrimeryKey:updatedData.id,

    });
    return {
      message: `${Messages.Resource.Updated} : Folder`,
    }
  }

  async remove(folderId: number, userDetail,userdetailid): Promise<FolderWithMessageResponse> {
    try {
      const deletedData = await this.folderRepository.findOne(folderId)
      const deleteFolder = await this.folderRepository.delete(folderId);
      await this.eventLogService.create({
        moduleName: ModuleName.FOLDER,
        eventName: FolderAction.DELETE_FOLDER,
        baseCaseNumber:'',
        eventUserId: userdetailid,
        eventUserName: userDetail,
        eventDateTime: moment(new Date()).format("YYYY-MM-DD HH:mm"),
        oldValue: JSON.stringify(deletedData),
        newValue: '',
        eventPrimeryKey:deletedData.id,
  
      });
      if (deleteFolder.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Folder`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
  async copyfolder(){
   const clientPath = await this.settingRepository.find();
   if(clientPath[0].baseRootPath != ''){
    await  fs.copySync(`${this.configService.get<string>('UPLOADED_FILES')}`+'/'+clientPath[0].baseRootPath , `${this.configService.get<string>('UPLOADED_FILES_PRIVATE')}`+'/'+clientPath[0].baseRootPath, {recursive: true});
   }
   return {
    message: `${Messages.Resource.Updated} : Folder`,
  }
  }

}
