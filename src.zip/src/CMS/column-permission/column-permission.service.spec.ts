import { Test, TestingModule } from '@nestjs/testing';
import { ColumnPermissionService } from './column-permission.service';

describe('ColumnPermissionService', () => {
  let service: ColumnPermissionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ColumnPermissionService],
    }).compile();

    service = module.get<ColumnPermissionService>(ColumnPermissionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
