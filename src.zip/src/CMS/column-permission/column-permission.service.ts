import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, getManager, getRepository, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateColumnPermissionDto } from './dto/request/create-column-permission.dto';
import { ColumnPermission } from './entities/column-permission.entity';
import { ColumnPermissionWithMessageResponse } from './dto/response/columnPermissionWithResponce';
import { RoleService } from '../role/role.service';
import { ColumnDetailService } from '../manage-columns/column-detail/column-detail.service';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';


@Injectable()
export class ColumnPermissionService {
  constructor(
    @InjectRepository(ColumnPermission) private columnPermissionRepository: Repository<ColumnPermission>,
    private readonly roleRepository: RoleService,
    private readonly columnDetailRepository: ColumnDetailService,
    private readonly mailsService: MailService
    ) { }

  async createOrUpdatePermission(request: CreateColumnPermissionDto): Promise<ColumnPermissionWithMessageResponse> {

    var result: any;
    var message:any;
     await this.roleRepository.findOne(request.roleId);
     await this.columnDetailRepository.findOne(request.columnId);
    const columnsPermissionExist = await getRepository(ColumnPermission)
      .createQueryBuilder()
      .where({ roleId: request.roleId, columnId: request.columnId })
      .getOne();
    if (!columnsPermissionExist) {

      const columnPermission = await this.columnPermissionRepository.create(request);
      result = await this.columnPermissionRepository.save(columnPermission);
      message=`${Messages.Resource.Created} : Column-permission`;
    } else {
      result = await getConnection()
        .createQueryBuilder()
        .update(ColumnPermission)
        .set({ isNoaccess: request.isNoaccess, isRead: request.isRead, isReadWrite: request.isReadWrite })
        .where({ roleId: request.roleId, columnId: request.columnId })
        .execute();
        message=`${Messages.Resource.Updated} : Column-permission`;
    }
      return {
        message: message,
      }
  }
  async findColumnPermissionByRoleId(roleId: number) {
    try {
      var permissionList: any;
      const result = getManager().query('SELECT A.id as ID,A.name ,B.* FROM `column-detail` AS A left outer join (select * from `column-permission` where roleId=' + `${roleId}) B on A.id=B.columnId`)
      await result.then((val: any) => {
        permissionList = val;
        return permissionList

      })
      if (!permissionList)
        throw new HttpException(`Column-permission by role-id not found`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Column-permission by role-id`,
        data: permissionList
      }
    } catch (error) {
      throw error;
    }
  }
}


