import { CreateColumnPermissionDto } from './create-column-permission.dto';

export class UpdateColumnPermissionDto extends CreateColumnPermissionDto { }
