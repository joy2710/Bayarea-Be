import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsOptional } from "class-validator";

export class CreateColumnPermissionDto {

    @ApiProperty()
    roleId: number;

    @ApiProperty()
    columnId: number;

    @ApiProperty()
    @IsOptional()
    @IsBoolean()
    isNoaccess: boolean;

    @ApiProperty()
    @IsOptional()
    @IsBoolean()
    isRead: boolean;

    @ApiProperty()
    @IsOptional()
    @IsBoolean()
    isReadWrite: boolean;
}
