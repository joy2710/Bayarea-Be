import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ColumnPermissionResponse } from './column-permission-response';

export class ColumnPermissionWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: ColumnPermissionResponse | ColumnPermissionResponse[];

  constructor(message: string, data: ColumnPermissionResponse | ColumnPermissionResponse[]) {
    this.data = data;
    this.message = message;
  }
}
