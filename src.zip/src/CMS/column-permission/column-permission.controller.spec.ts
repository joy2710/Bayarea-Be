import { Test, TestingModule } from '@nestjs/testing';
import { ColumnPermissionController } from './column-permission.controller';
import { ColumnPermissionService } from './column-permission.service';

describe('ColumnPermissionController', () => {
  let controller: ColumnPermissionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ColumnPermissionController],
      providers: [ColumnPermissionService],
    }).compile();

    controller = module.get<ColumnPermissionController>(ColumnPermissionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
