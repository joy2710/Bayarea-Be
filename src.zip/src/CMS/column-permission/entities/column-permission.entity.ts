import { ColumnDetail } from "src/CMS/manage-columns/column-detail/entities/column-detail.entity";
import { Role } from "src/CMS/role/entities/role.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"

@Entity({ name: 'column-permission' })

export class ColumnPermission {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    roleId: number;

    @Column()
    columnId: number;

    @Column('bool')
    isNoaccess: boolean;

    @Column('bool')
    isRead: boolean;

    @Column('bool')
    isReadWrite: boolean;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @ManyToOne(() => Role, (role: Role) => role.columnPermission,
        {
            eager: false,
            onDelete: 'CASCADE'
        })
    role: Role[];

    @ManyToOne(() => ColumnDetail, (columnDetail: ColumnDetail) => columnDetail.columnPermission,
        {
            eager: false,
            onDelete: 'CASCADE'
        })
    column: ColumnDetail[];

}

