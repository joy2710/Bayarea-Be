import { Module } from '@nestjs/common';
import { ColumnPermissionService } from './column-permission.service';
import { ColumnPermissionController } from './column-permission.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ColumnPermission } from './entities/column-permission.entity';
import { Role } from '../role/entities/role.entity';
import { RoleService } from '../role/role.service';
import { RoleModule } from '../role/role.module';
import { ColumnDetail } from '../manage-columns/column-detail/entities/column-detail.entity';
import { ColumnDetailModule } from '../manage-columns/column-detail/column-detail.module';
import { ColumnDetailService } from '../manage-columns/column-detail/column-detail.service';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { Setting } from '../setting/entities/setting.entity';
import { ConfigService } from '@nestjs/config';

@Module({
  imports: [TypeOrmModule.forFeature([ColumnPermission,Role,ColumnDetail,Setting]),RoleModule,ColumnDetailModule],
  controllers: [ColumnPermissionController],
  providers: [ColumnPermissionService,RoleService,ColumnDetailService,MailService,ConfigService],
  exports : [MailService]
})
export class ColumnPermissionModule { }
