import { Controller, Get, Post, Body, Param, UseGuards, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { ColumnPermissionParentRoute, ColumnPermissionRoutes } from './column-permission.http.routes';
import { ColumnPermissionService } from './column-permission.service';
import { CreateColumnPermissionDto } from './dto/request/create-column-permission.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Column-permission')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: ColumnPermissionParentRoute })
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class ColumnPermissionController {
  constructor(private readonly columnPermissionService: ColumnPermissionService) { }

  @Post(ColumnPermissionRoutes.create)
  create(@Body() body: CreateColumnPermissionDto) {
    return this.columnPermissionService.createOrUpdatePermission(body);
  }
  // GET-BY-ROLE-ID
  @Get(ColumnPermissionRoutes.get_by_role)
  findColumnPermissionByRoleId(@Param('roleId') id: string) {
    return this.columnPermissionService.findColumnPermissionByRoleId(+id);
  }

}
