export const ColumnPermissionParentRoute = 'column-permission';

export const ColumnPermissionRoutes = {
  create: '',
  get_by_role:'role-type/:roleId'
};
