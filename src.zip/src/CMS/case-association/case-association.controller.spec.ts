import { Test, TestingModule } from '@nestjs/testing';
import { CaseAssociationController } from './case-association.controller';
import { CaseAssociationService } from './case-association.service';

describe('CaseAssociationController', () => {
  let controller: CaseAssociationController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CaseAssociationController],
      providers: [CaseAssociationService],
    }).compile();

    controller = module.get<CaseAssociationController>(CaseAssociationController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
