import { PartialType } from '@nestjs/mapped-types';
import { CreateCaseAssociationDto } from './create-case-association.dto';

export class UpdateCaseAssociationDto extends CreateCaseAssociationDto {}
