import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CaseAssociationResponse } from './case-association-response';

export class CaseAssociationWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CaseAssociationResponse | CaseAssociationResponse[];

  constructor(message: string, data: CaseAssociationResponse | CaseAssociationResponse[]) {
    this.data = data;
    this.message = message;
  }
}
