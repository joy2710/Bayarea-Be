export const CaseAssociationRoute ='caseAssociation';

export const CaseAssociationRoutes ={
    create: '',
    update: 'update/:caseAssociationId',
    delete: ':caseAssociationId',
    view_one: ':caseAssociationId',
    view_all: '',
}