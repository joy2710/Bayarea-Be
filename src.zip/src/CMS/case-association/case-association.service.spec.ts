import { Test, TestingModule } from '@nestjs/testing';
import { CaseAssociationService } from './case-association.service';

describe('CaseAssociationService', () => {
  let service: CaseAssociationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CaseAssociationService],
    }).compile();

    service = module.get<CaseAssociationService>(CaseAssociationService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
