import { Module } from '@nestjs/common';
import { CaseAssociationService } from './case-association.service';
import { CaseAssociationController } from './case-association.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CaseAssociation } from './entities/case-association.entity';

@Module({
  imports:[TypeOrmModule.forFeature([CaseAssociation])],
  controllers: [CaseAssociationController],
  providers: [CaseAssociationService]
})
export class CaseAssociationModule {}
