import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateCaseAssociationDto } from './dto/request/create-case-association.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CaseAssociation } from './entities/case-association.entity';
import { CaseAssociationWithMessageResponse } from './dto/response/caseAssociationWithResponce';
import { Messages } from 'src/common/constants/messages';


@Injectable()
export class CaseAssociationService {
  constructor(
    @InjectRepository(CaseAssociation) private caseAssociationRepository: Repository<CaseAssociation>
  ) { }
  async create(request: CreateCaseAssociationDto): Promise<CaseAssociationWithMessageResponse> {
    const data = await this.caseAssociationRepository.create(request);
    const result = await this.caseAssociationRepository.save(data);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Case-Association`,
        data: result
      }
    }
  }
  async findAll(): Promise<CaseAssociationWithMessageResponse> {
    const result = await this.caseAssociationRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Case-Association`,
        data: result
      }
    }
  }
  async findOne(caseAssociationId: number): Promise<CaseAssociationWithMessageResponse> {
    try {
      const result = await this.caseAssociationRepository.findOne(
        {
          where:
            { id: caseAssociationId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Case-Association`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Case-Association`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }


  async update(caseAssociationId: number, request: CreateCaseAssociationDto): Promise<CaseAssociationWithMessageResponse> {
    const data = await this.caseAssociationRepository.findOne(caseAssociationId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Case-Association`, HttpStatus.NOT_FOUND);
    }
    await this.caseAssociationRepository.update(caseAssociationId, request)
    return {
      message: `${Messages.Resource.Updated} : Case-Association`,
    }

  }

  async remove(caseAssociationId: number): Promise<CaseAssociationWithMessageResponse> {
    try {
      const deletecaseAssociation = await this.caseAssociationRepository.delete(caseAssociationId)
      if (deletecaseAssociation.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Case-Association`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }


}
