import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Req } from '@nestjs/common';
import { CaseAssociationService } from './case-association.service';
import { CreateCaseAssociationDto } from './dto/request/create-case-association.dto';
import { UpdateCaseAssociationDto } from './dto/request/update-case-association.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CaseAssociationRoute } from './case-association.http.routes';
import { CaseAssignRoutes } from '../case-assign/case-assign.http.routes';

@ApiTags('Case-association')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CaseAssociationRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
export class CaseAssociationController {
  constructor(private readonly caseAssociationService: CaseAssociationService) {}

  @Post(CaseAssignRoutes.create)
  create(@Body() createCaseAssociationDto: CreateCaseAssociationDto) {
    return this.caseAssociationService.create(createCaseAssociationDto);
  }

  @Get(CaseAssignRoutes.view_all)
  findAll() {
    return this.caseAssociationService.findAll();
  }

  @Get(CaseAssignRoutes.view_one)
  findOne(@Param('caseAssociationId') id: string) {
    return this.caseAssociationService.findOne(+id);
  }

  @Post(CaseAssignRoutes.update)
  update(@Param('caseAssociationId') id: string, @Body() updateCaseAssociationDto: UpdateCaseAssociationDto) {
    return this.caseAssociationService.update(+id, updateCaseAssociationDto);
  }

  @Delete(CaseAssignRoutes.delete)
  remove(@Param('caseAssociationId') id: string) {
    return this.caseAssociationService.remove(+id);
  }


}
