export const FooterLogoScrollerParentRoute = 'footer-logo-scroller';

export const FooterLogoScrollerRoutes = {
  create: '',
  update: 'update/:footerLogoScrollerId',
  delete: ':footerLogoScrollerId',
  view_one: ':footerLogoScrollerId',
  view_all: '',
  upload_image: 'image-upload',
  updateDragAndDrop: 'dragandDrop'
};