import { Test, TestingModule } from '@nestjs/testing';
import { FooterLogoScrollerService } from './footer-logo-scroller.service';

describe('FooterLogoScrollerService', () => {
  let service: FooterLogoScrollerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FooterLogoScrollerService],
    }).compile();

    service = module.get<FooterLogoScrollerService>(FooterLogoScrollerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
