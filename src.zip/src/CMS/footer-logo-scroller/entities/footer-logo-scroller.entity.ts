import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { FooterLogoScrollerStatus } from "./footer-logo.-scroller-status.enum";

@Entity({ name: 'footer-logo-scroller' })
export class FooterLogoScroller {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column()
    imageUrl: string;

    @Column()
    navigationurl: string;

    @Column({ default: FooterLogoScrollerStatus.INACTIVE })
    status: FooterLogoScrollerStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column()
    sequenceNumber: number;
}
