export enum FooterLogoScrollerStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}