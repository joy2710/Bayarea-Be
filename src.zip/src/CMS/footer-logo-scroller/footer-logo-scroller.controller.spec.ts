import { Test, TestingModule } from '@nestjs/testing';
import { FooterLogoScrollerController } from './footer-logo-scroller.controller';
import { FooterLogoScrollerService } from './footer-logo-scroller.service';

describe('FooterLogoScrollerController', () => {
  let controller: FooterLogoScrollerController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FooterLogoScrollerController],
      providers: [FooterLogoScrollerService],
    }).compile();

    controller = module.get<FooterLogoScrollerController>(FooterLogoScrollerController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
