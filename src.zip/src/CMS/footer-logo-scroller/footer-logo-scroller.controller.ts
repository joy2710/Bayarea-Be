import { Controller, Get, Post, Body, Patch, Param, Delete, UseInterceptors, UploadedFile, Query, UseGuards } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { Observable, of } from 'rxjs';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { CreateFooterLogoScrollerDto } from './dto/request/create-footer-logo-scroller.dto';
import { UpdateFooterLogoScrollerDto } from './dto/request/update-footer-logo-scroller.dto';
import { FooterLogoScrollerParentRoute, FooterLogoScrollerRoutes } from './footer-logo-scroller.http.routes';
import { FooterLogoScrollerService } from './footer-logo-scroller.service';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Footer-Logo-Scroller')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: FooterLogoScrollerParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class FooterLogoScrollerController {
  constructor(private readonly footerLogoScrollerService: FooterLogoScrollerService) {}

  @Post(FooterLogoScrollerRoutes.create)
  create(@Body() createFooterLogoScrollerDto: CreateFooterLogoScrollerDto) {
    return this.footerLogoScrollerService.create(createFooterLogoScrollerDto);
  }

  @Public()
  @Get(FooterLogoScrollerRoutes.view_all)
  findAll() {
    return this.footerLogoScrollerService.findAll();
  }

  @Public()
  @Get(FooterLogoScrollerRoutes.view_one)
  findOne(@Param('footerLogoScrollerId') id: string) {
    return this.footerLogoScrollerService.findOne(+id);
  }

  @Post(FooterLogoScrollerRoutes.update)
  update(@Param('footerLogoScrollerId') id: string, @Body() updateFooterLogoScrollerDto: UpdateFooterLogoScrollerDto) {
    return this.footerLogoScrollerService.update(+id, updateFooterLogoScrollerDto);
  }

  @Delete(FooterLogoScrollerRoutes.delete)
  remove(@Param('footerLogoScrollerId') id: string) {
    return this.footerLogoScrollerService.remove(+id);
  }

  @Public()
  @Post(FooterLogoScrollerRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {

    return of({ imagePath: `${file.destination}/${file.filename}` })
  }

  @Public()
  @Post(FooterLogoScrollerRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.footerLogoScrollerService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }
}

