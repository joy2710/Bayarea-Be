import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { FooterLogoScrollerStatus } from "../../entities/footer-logo.-scroller-status.enum";

export class CreateFooterLogoScrollerDto {
    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    @IsNotEmpty()
    imageUrl: string;

    @ApiProperty()
    @IsNotEmpty()
    navigationurl: string;

    @ApiProperty({ default: FooterLogoScrollerStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(FooterLogoScrollerStatus)
    status: FooterLogoScrollerStatus;

    @ApiProperty()
    @IsOptional()
    sequenceNumber?: number;
}
