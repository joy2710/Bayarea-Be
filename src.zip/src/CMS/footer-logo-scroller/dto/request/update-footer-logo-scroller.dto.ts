import { PartialType } from '@nestjs/swagger';
import { CreateFooterLogoScrollerDto } from './create-footer-logo-scroller.dto';

export class UpdateFooterLogoScrollerDto extends PartialType(CreateFooterLogoScrollerDto) {}
