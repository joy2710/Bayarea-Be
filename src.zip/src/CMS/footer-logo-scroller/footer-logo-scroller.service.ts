import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { getConnection, Repository } from 'typeorm';
import { CreateFooterLogoScrollerDto } from './dto/request/create-footer-logo-scroller.dto';
import { UpdateFooterLogoScrollerDto } from './dto/request/update-footer-logo-scroller.dto';
import { FooterLogoScroller } from './entities/footer-logo-scroller.entity';

@Injectable()
export class FooterLogoScrollerService {
  constructor(
    @InjectRepository(FooterLogoScroller) private footerLogoScrollerRepository: Repository<FooterLogoScroller>
  ) { }

  async create(request: CreateFooterLogoScrollerDto) {
    const footerLogo = await this.footerLogoScrollerRepository.create(request);
    const result = await this.footerLogoScrollerRepository.save(footerLogo);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Footer-Logo-Scroller`,
        data: result
      }
    }
  }

  async findAll() {
    const result = await this.footerLogoScrollerRepository
    .createQueryBuilder()
    .orderBy('sequenceNumber', "ASC")
    .getMany();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Footer-Logo-Scroller`,
        data: result
      }
    }
  }

  async findOne(footerLogoScrollerId: number) {
    try {
      const result = await this.footerLogoScrollerRepository.findOne(
        {
          where:
            { id: footerLogoScrollerId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Footer-Logo-Scroller`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Footer-Logo-Scroller`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(footerLogoScrollerId: number, request: UpdateFooterLogoScrollerDto) {
    const data = await this.footerLogoScrollerRepository.findOne(footerLogoScrollerId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Footer-Logo-Scroller`, HttpStatus.NOT_FOUND);
    }
    await this.footerLogoScrollerRepository.update(footerLogoScrollerId, request)
    return {
      message: `${Messages.Resource.Updated} : Footer-Logo-Scroller`,
    }
  }

  async remove(footerLogoScrollerId: number) {
    try {
      const deleteCaseStudy = await this.footerLogoScrollerRepository.delete(footerLogoScrollerId)
      if (deleteCaseStudy.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Footer-Logo-Scroller`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(FooterLogoScroller)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(FooterLogoScroller)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(FooterLogoScroller)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(FooterLogoScroller)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(FooterLogoScroller)
      .set({ sequenceNumber: () => "sequenceNumber - 1" })
      .where('sequenceNumber > :currSequenceNumber AND sequenceNumber <= :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(FooterLogoScroller)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }
}
