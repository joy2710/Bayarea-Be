import { Module } from '@nestjs/common';
import { FooterLogoScrollerService } from './footer-logo-scroller.service';
import { FooterLogoScrollerController } from './footer-logo-scroller.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FooterLogoScroller } from './entities/footer-logo-scroller.entity';

@Module({
  imports: [TypeOrmModule.forFeature([FooterLogoScroller])],
  controllers: [FooterLogoScrollerController],
  providers: [FooterLogoScrollerService]
})
export class FooterLogoScrollerModule {}
