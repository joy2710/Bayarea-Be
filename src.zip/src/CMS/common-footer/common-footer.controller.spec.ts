import { Test, TestingModule } from '@nestjs/testing';
import { CommonFooterController } from './common-footer.controller';
import { CommonFooterService } from './common-footer.service';

describe('CommonFooterController', () => {
  let controller: CommonFooterController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CommonFooterController],
      providers: [CommonFooterService],
    }).compile();

    controller = module.get<CommonFooterController>(CommonFooterController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
