import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty } from "class-validator";
import { CommonFooterStatus } from "../../entities/status.enum";

export class CreateCommonFooterDto {

    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;

    @ApiProperty({ default: CommonFooterStatus.INACTIVE})
    @IsNotEmpty()
    @IsEnum(CommonFooterStatus)
    status: CommonFooterStatus;
    
}
