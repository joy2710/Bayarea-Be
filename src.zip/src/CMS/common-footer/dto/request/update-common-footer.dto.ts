import { CreateCommonFooterDto } from './create-common-footer.dto';

export class UpdateCommonFooterDto extends CreateCommonFooterDto {}
