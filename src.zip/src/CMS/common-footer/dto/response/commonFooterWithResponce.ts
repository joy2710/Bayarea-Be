import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CommonFooterResponse } from './common-footer-response';

export class CommonFooterWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CommonFooterResponse | CommonFooterResponse[];

  constructor(message: string, data: CommonFooterResponse | CommonFooterResponse[]) {
    this.data = data;
    this.message = message;
  }
}
