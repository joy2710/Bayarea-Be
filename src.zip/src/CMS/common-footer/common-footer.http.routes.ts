export const CommonFooterParentRoute = 'common-footer';

export const CommonFooterRoutes = {
  create: '',
  update: 'update/:commonFooterId',
  delete: ':commonFooterId',
  view_one: ':commonFooterId',
  view_all: '',
};
