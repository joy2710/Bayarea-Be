import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { CommonFooterStatus } from "./status.enum";

@Entity({ name: 'common-footer'})
export class CommonFooter {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column({type: 'longtext'})
    description: string;

    @Column({ default: CommonFooterStatus.INACTIVE })
    status: CommonFooterStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
}
