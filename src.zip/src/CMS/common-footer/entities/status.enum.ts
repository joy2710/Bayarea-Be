export enum CommonFooterStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}