import { Controller, Get, Post, Body, Param, Delete,UseGuards } from '@nestjs/common';
import { ApiTags,ApiBearerAuth } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CommonFooterParentRoute, CommonFooterRoutes } from './common-footer.http.routes';

import { CommonFooterService } from './common-footer.service';
import { CreateCommonFooterDto } from './dto/request/create-common-footer.dto';
import { UpdateCommonFooterDto } from './dto/request/update-common-footer.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Common-Footer')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CommonFooterParentRoute})
// @ApiBearerAuth()
// @UseGuards(JwtAuthGuard)
@Public()

export class CommonFooterController {
  constructor(private readonly commonFooterService: CommonFooterService) {}

  @Post(CommonFooterRoutes.create)
  createCommonFooter(@Body() body: CreateCommonFooterDto) {
    return this.commonFooterService.create(body);
  }

  @Get(CommonFooterRoutes.view_all)
  findAllCommonFooter() {
    return this.commonFooterService.findAll();
  }

  @Get(CommonFooterRoutes.view_one)
  findCommonFooterById(@Param('commonFooterId') id: string) {
    return this.commonFooterService.findOne(+id);
  }

  @Post(CommonFooterRoutes.update)
  updateCommonFooterById(@Param('commonFooterId') id: string, @Body() body: UpdateCommonFooterDto) {
    return this.commonFooterService.update(+id, body);
  }

  @Delete(CommonFooterRoutes.delete)
  removeCommonFooterById(@Param('commonFooterId') id: string) {
    return this.commonFooterService.remove(+id);
  }
}
