import { Test, TestingModule } from '@nestjs/testing';
import { CommonFooterService } from './common-footer.service';

describe('CommonFooterService', () => {
  let service: CommonFooterService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CommonFooterService],
    }).compile();

    service = module.get<CommonFooterService>(CommonFooterService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
