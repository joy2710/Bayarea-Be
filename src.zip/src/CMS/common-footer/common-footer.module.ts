import { Module } from '@nestjs/common';
import { CommonFooterService } from './common-footer.service';
import { CommonFooterController } from './common-footer.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonFooter } from './entities/common-footer.entity';

@Module({
  imports:[TypeOrmModule.forFeature([CommonFooter])],
  controllers: [CommonFooterController],
  providers: [CommonFooterService]
})
export class CommonFooterModule {}
