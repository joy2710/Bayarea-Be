import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateCommonFooterDto } from './dto/request/create-common-footer.dto';
import { UpdateCommonFooterDto } from './dto/request/update-common-footer.dto';
import { CommonFooterWithMessageResponse } from './dto/response/commonFooterWithResponce';
import { CommonFooter } from './entities/common-footer.entity';

@Injectable()
export class CommonFooterService {
  constructor(
    @InjectRepository(CommonFooter) private commonFooterRepository: Repository<CommonFooter>
  ) { }

  async create(request: CreateCommonFooterDto): Promise<CommonFooterWithMessageResponse> {
    const commonFooter = await this.commonFooterRepository.create(request);
    const result = await this.commonFooterRepository.save(commonFooter);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Common-footer`,
        data: result
      }
    }
  }

  async findAll(): Promise<CommonFooterWithMessageResponse> {
    const result = await this.commonFooterRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Common-footer`,
        data: result
      }
    }
  }

  async findOne(commonFooterId: number): Promise<CommonFooterWithMessageResponse> {
    try {
      const result = await this.commonFooterRepository.findOne(
        {
          where:
            { id: commonFooterId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Common-footer`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Common-footer`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(commonFooterId: number, request: UpdateCommonFooterDto): Promise<CommonFooterWithMessageResponse> {
    const data = await this.commonFooterRepository.findOne(commonFooterId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Common-footer`, HttpStatus.NOT_FOUND);
    }
    await this.commonFooterRepository.update(commonFooterId, request)
    return {
      message: `${Messages.Resource.Updated} : Common-footer`,
    }
  }

  async remove(commonFooterId: number): Promise<CommonFooterWithMessageResponse> {
    try {
      const deleteCommonFooter = await this.commonFooterRepository.delete(commonFooterId);
      if (deleteCommonFooter.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Common-footer`
        }
      }

    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
