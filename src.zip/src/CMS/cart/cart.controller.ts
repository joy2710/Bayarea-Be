import { Controller, Get, Post, Body, Patch, Param, Delete, Request, UseGuards, Query} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CreateClientDto } from 'src/CMS/client/dto/request/create-client.dto';
import { CreateOrderDto } from '../order/dto/request/create-order.dto';
import { CartParentRoute, CartRoutes } from './cart.http.routes';
import { CartService } from './cart.service';
import { CreateCartDto } from './dto/request/create-cart.dto';
import { UpdateCartDto } from './dto/request/update-cart.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Cart')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: CartParentRoute })
@Public()
// @ApiBearerAuth()
// @UseGuards(JwtAuthGuard)

export class CartController {
  constructor(private readonly cartService: CartService) {}

  @Post(CartRoutes.create)
  create(@Body() createCartDto: CreateCartDto, @Request() req: any) {
    createCartDto.clientIp = req.socket.remoteAddress;
    createCartDto.date = new Date();
    createCartDto.totalPrice = createCartDto.price * createCartDto.quantity
    return this.cartService.create(createCartDto);
  }

  @Get(CartRoutes.view_all)
  findAll() {
    return this.cartService.findAll();
  }

  @Get(CartRoutes.view_one)
  findOne(@Param('cartId') id: string) {
    return this.cartService.findOne(+id);
  }

  @Post(CartRoutes.update)
  update(@Param('cartId') id: string, @Body() updateCartDto: UpdateCartDto, @Request() req: any) {
    updateCartDto.clientIp = req.socket.remoteAddress;
    updateCartDto.date = new Date();
    updateCartDto.totalPrice = updateCartDto.price * updateCartDto.quantity
    return this.cartService.update(+id, updateCartDto);
  }

  @Delete(CartRoutes.delete)
  remove(@Param('cartId') id: string) {
    return this.cartService.remove(+id);
  }

  // @Post(CartRoutes.checkout)
  // async checkout(
  //   @Body() request: CreateOrderDto, 
  // ) {
  //   const res = await this.cartService.checkout(request);
  //   return res;
  // }

  @Post('/api/product')
  async product(
    @Query('clientIp') clientIp : string,
  ) {
    const res = await this.cartService.product(clientIp);
    return res;
  }
}
