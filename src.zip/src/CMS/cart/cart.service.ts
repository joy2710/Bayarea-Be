import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ClientService } from 'src/CMS/client/client.service';
import { CreateClientDto } from 'src/CMS/client/dto/request/create-client.dto';
import { Client } from 'src/CMS/client/entities/client.entity';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { OrderDetail } from '../order-detail/entities/order-detail.entity';
import { CreateOrderDto } from '../order/dto/request/create-order.dto';
import { Order } from '../order/entities/order.entity';
import { OrderStatus } from '../order/entities/status.enum';
import { CreateCartDto } from './dto/request/create-cart.dto';
import { UpdateCartDto } from './dto/request/update-cart.dto';
import { CartWithMessageResponse } from './dto/response/cartWithResponce';
import { Cart } from './entities/cart.entity';

@Injectable()
export class CartService {
  constructor(
    @InjectRepository(Cart) private cartRepository: Repository<Cart>,
    @InjectRepository(Client) private clientRepository: Repository<Client>,
    @InjectRepository(Order) private orderRepository: Repository<Order>,
    @InjectRepository(OrderDetail) private orderDetailRepository: Repository<OrderDetail>,
  ) { }

  async create(request: CreateCartDto): Promise<CartWithMessageResponse> {
    const result = await this.cartRepository.save(request);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Cart`,
        data: result
      }
    }
  }

  async findAll(): Promise<CartWithMessageResponse> {
    const result = await this.cartRepository.find({relations: ['product']});
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Cart`,
        data: result
      }
    }
  }

  async findOne(cartId: number): Promise<CartWithMessageResponse> {
    try {
      const result = await this.cartRepository.findOne(
        { 
          relations: ['product'],
          where: { id: cartId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Cart`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Cart`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(cartId: number, request: UpdateCartDto): Promise<CartWithMessageResponse> {
    const data = await this.cartRepository.findOne(cartId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Cart`, HttpStatus.NOT_FOUND);
    }
    await this.cartRepository.update(cartId, request)
    return {
      message: `${Messages.Resource.Updated} : Cart`,
    }

  }

  async remove(cartId: number): Promise<CartWithMessageResponse> {
    try {
      const deleteCart = await this.cartRepository.delete(cartId)
      if (deleteCart.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Cart`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
  //  Not in use 
  // async checkout(request: CreateOrderDto) {
  //   var insert;
  //   let totalPrice = 0;

  //   var cart = await this.cartRepository.createQueryBuilder('cart')
  //     .leftJoinAndSelect('cart.product', 'product')
  //     .getRawMany();
  //   cart.forEach(async (cart) => {
  //     totalPrice += Number(cart.cart_totalPrice);
  //   })

  //   insert = await this.orderRepository.save({
  //     clientId: request.clientId,
  //     totalPrice: totalPrice,
  //     paymentDate: request.paymentDate,
  //     transactionId: request.transactionId,
  //     status: OrderStatus.PENDING,
  //     firstName: request.firstName,
  //     middleName: request.middleName,
  //     lastName: request.lastName,
  //     email: request.email,
  //     phone: request.phone,
  //     administrativeCaseNumber: request.administrativeCaseNumber
  //   });
  //   var order = await this.orderRepository.findOne(insert.id);

  //   cart.forEach(async (product) => {
  //     await this.orderDetailRepository.save({
  //       orderId: order.id,
  //       productId: product.product_id,
  //       quantity: product.cart_quantity,
  //       price: product.product_productPrice,
  //       totalPrice: product.cart_totalPrice
  //     });

  //   })
  //   return {
  //     message: 'success',
  //     data: order
  //   };
  // }

  async product(clientIp: string) {
    const cart = await this.cartRepository.createQueryBuilder('cart')
    .leftJoinAndSelect('cart.product', 'product')
    .where('clientIp = :clientIp', { clientIp: clientIp })
    .groupBy('clientIp')
    .getMany(); 
    return cart;
  }
}
