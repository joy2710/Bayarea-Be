import { ApiProperty } from "@nestjs/swagger"
import { IsNotEmpty, IsOptional } from "class-validator"

export class CreateCartDto {
    @ApiProperty()
    @IsOptional()
    date?: Date;

    @ApiProperty()
    @IsOptional()
    clientIp?: string;

    @ApiProperty()
    @IsNotEmpty()
    productId: number;

    @ApiProperty()
    @IsNotEmpty()
    quantity: number;

    @ApiProperty()
    @IsNotEmpty()
    price: number;

    @ApiProperty()
    @IsNotEmpty()
    totalPrice: number;
}