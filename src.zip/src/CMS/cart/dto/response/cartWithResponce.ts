import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CartResponse } from './cart-response';

export class CartWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CartResponse | CartResponse[];

  constructor(message: string, data: CartResponse | CartResponse[]) {
    this.data = data;
    this.message = message;
  }
}
