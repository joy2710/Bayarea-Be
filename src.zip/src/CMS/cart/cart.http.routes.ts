export const CartParentRoute = 'cart';

export const CartRoutes = {
  create: '',
  update: 'update/:cartId',
  delete: ':cartId',
  view_one: ':cartId',
  view_all: '',
  // checkout: 'checkout'
};
