import { Product } from "src/CMS/product/entities/product.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"

@Entity()
export class Cart {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    date: Date;

    @Column()
    clientIp: string;

    @Column()
    productId: number;

    @ManyToOne(() => Product, (product: Product) => product.cart, {
        eager: false,
        onDelete: 'CASCADE'
    })
    product: Product[];

    @Column()
    quantity: number;

    @Column({type: 'decimal', precision: 10, scale: 2})
    price: number;

    @Column({type: 'decimal', precision: 10, scale: 2})
    totalPrice: number;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
}
