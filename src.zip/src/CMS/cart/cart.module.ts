import { Module } from '@nestjs/common';
import { CartService } from './cart.service';
import { CartController } from './cart.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Cart } from './entities/cart.entity';
import { OrderModule } from '../order/order.module';
import { ClientModule } from 'src/CMS/client/client.module';
import { OrderDetailModule } from '../order-detail/order-detail.module';
import { Order } from '../order/entities/order.entity';
import { Client } from 'src/CMS/client/entities/client.entity';
import { OrderDetail } from '../order-detail/entities/order-detail.entity';
import { ClientService } from 'src/CMS/client/client.service';
import { OrderService } from '../order/order.service';
import { OrderDetailService } from '../order-detail/order-detail.service';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { ProductModule } from '../product/product.module';
import { ManagerServiceForm } from '../manage-service-form/manager-service-form/entities/manager-service-form.entity';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { TaskInstruction } from '../task-instruction/entities/task-instruction.entity';
import { ProductPriceLevel } from '../product-price-level/entities/product-price-level.entity';
import { Setting } from '../setting/entities/setting.entity';
import { Cases } from '../cases/entities/cases.entity';
import { OrderInventor } from '../order-inventors/entities/order-inventor.entity';
import { OrderPriorityClaim } from '../order-priority-claims/entities/order-priority-claim.entity';
import { OrderPaymentService } from '../order-payment/order-payment.service';
import { OrderPayment } from '../order-payment/entities/order-payment.entity';
import { CaseFileService } from '../case-file/case-file.service';
import { CaseFile } from '../case-file/entities/case-file.entity';
import { Folder } from '../folder/entities/folder.entity';
import { StatusLookup } from '../status-lookup/entities/status-lookup.entity';
import { StatusLookupModule } from '../status-lookup/status-lookup.module';
import { StatusLookupService } from '../status-lookup/status-lookup.service';
import { ConfigService } from '@nestjs/config';
import { ClientBillingContact } from '../client-billing-contact/entities/client-billing-contact.entity';
import { EmailTemplateModule } from '../email-template/email-template.module';

@Module({
  imports: [
  TypeOrmModule.forFeature([Cart,ProductPriceLevel,Cases,OrderPayment, Client,CaseFile,Folder, Order,OrderInventor,OrderPriorityClaim, OrderDetail,ManagerServiceForm, ProductOrderDetailForm, TaskInstruction,Setting,StatusLookup,ClientBillingContact]), 
  ClientModule, 
  OrderModule, 
  OrderDetailModule,
  ProductModule,
  StatusLookupModule,
  EmailTemplateModule
  ],
  controllers: [CartController],
  providers: [CartService, ClientService,OrderPaymentService, OrderService, OrderDetailService, MailService,CaseFileService,StatusLookupService,ConfigService]
})
export class CartModule {}
