import { Test, TestingModule } from '@nestjs/testing';
import { HomepageSliderController } from './homepage-slider.controller';
import { HomepageSliderService } from './homepage-slider.service';

describe('HomepageSliderController', () => {
  let controller: HomepageSliderController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [HomepageSliderController],
      providers: [HomepageSliderService],
    }).compile();

    controller = module.get<HomepageSliderController>(HomepageSliderController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
