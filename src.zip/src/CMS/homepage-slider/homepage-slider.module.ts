import { Module } from '@nestjs/common';
import { HomepageSliderService } from './homepage-slider.service';
import { HomepageSliderController } from './homepage-slider.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HomepageSlider } from './entities/homepage-slider.entity';

@Module({
  imports:[TypeOrmModule.forFeature([HomepageSlider])],
  controllers: [HomepageSliderController],
  providers: [HomepageSliderService]
})
export class HomepageSliderModule {}
