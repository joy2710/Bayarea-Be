export const HomepageSliderParentRoute = 'homepage-slider';

export const HomepageSliderRoutes = {
  create: '',
  update: 'update/:homepageSliderId',
  delete: ':homepageSliderId',
  view_one: ':homepageSliderId',
  view_all: '',
  upload_image: 'image-upload',
  updateDragAndDrop: 'dragandDrop'
};
