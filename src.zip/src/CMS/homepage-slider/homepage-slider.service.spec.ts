import { Test, TestingModule } from '@nestjs/testing';
import { HomepageSliderService } from './homepage-slider.service';

describe('HomepageSliderService', () => {
  let service: HomepageSliderService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [HomepageSliderService],
    }).compile();

    service = module.get<HomepageSliderService>(HomepageSliderService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
