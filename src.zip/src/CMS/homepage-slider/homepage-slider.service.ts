import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateHomepageSliderDto } from './dto/request/create-homepage-slider.dto';
import { UpdateHomepageSliderDto } from './dto/request/update-homepage-slider.dto';
import { HomepageSlider } from './entities/homepage-slider.entity';
import { HomepageSliderWithMessageResponse } from './dto/response/homepageSliderWithResponce';

@Injectable()
export class HomepageSliderService {
  constructor(
    @InjectRepository(HomepageSlider) private homepageSliderRepository: Repository<HomepageSlider>
  ) { }

  async create(request: CreateHomepageSliderDto): Promise<HomepageSliderWithMessageResponse> {
    const homepageSlider = await this.homepageSliderRepository.create(request);
    const result = await this.homepageSliderRepository.save(homepageSlider);
    if (result) {
      return {
        message: `${Messages.Resource.Created}:Homepage-Slider`,
        data: result
      }
    }
  }

  async findAll(): Promise<HomepageSliderWithMessageResponse> {
    const result = await this.homepageSliderRepository
    .createQueryBuilder()
    .orderBy('sequenceNumber', "ASC")
    .getMany();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Homepage-Slider`,
        data: result
      }
    }
  }

  async findOne(homepageSliderId: number): Promise<HomepageSliderWithMessageResponse> {
    try {
      const result = await this.homepageSliderRepository.findOne(
        {
          where:
            { id: homepageSliderId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Homepage-Slider`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Homepage-Slider`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(homepageSliderId: number, request: UpdateHomepageSliderDto): Promise<HomepageSliderWithMessageResponse> {
    const data = await this.homepageSliderRepository.findOne(homepageSliderId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Homepage-Slider`, HttpStatus.NOT_FOUND);
    }
    await this.homepageSliderRepository.update(homepageSliderId, request);
    return {
      message: `${Messages.Resource.Updated} : Homepage-Slider`,
    }
  }

  async remove(homepageSliderId: number): Promise<HomepageSliderWithMessageResponse>  {
    try {
      const deleteHomePageSlider = await this.homepageSliderRepository.delete(homepageSliderId);
      if (deleteHomePageSlider.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Homepage-Slider`
        }
      }

    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(HomepageSlider)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(HomepageSlider)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(HomepageSlider)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(HomepageSlider)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(HomepageSlider)
      .set({ sequenceNumber: () => "sequenceNumber - 1" })
      .where('sequenceNumber > :currSequenceNumber AND sequenceNumber <= :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(HomepageSlider)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }
}
