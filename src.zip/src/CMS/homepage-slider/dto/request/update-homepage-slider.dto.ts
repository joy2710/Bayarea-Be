import { ApiProperty } from "@nestjs/swagger"
import { Type } from "class-transformer";
import { IsBoolean, IsEnum, IsNotEmpty, IsOptional } from "class-validator"
import { HomepageSliderStatus } from "../../entities/status.enum";

export class UpdateHomepageSliderDto {
   
    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    titleanimationduaration:number;

    @ApiProperty()
    titleanimationdelay:number;

    @ApiProperty()
    @IsNotEmpty()
    subtitle: string;

    @ApiProperty()
    subtitleanimationduaration:number;

    @ApiProperty()
    subtitleanimationdelay:number;

    @ApiProperty()
    @IsNotEmpty()
    naviagtionurl: string;

    @ApiProperty()
    naviagtionurlanimationduaration:number;

    @ApiProperty()
    naviagtionurlanimationdelay:number;

    @ApiProperty({default:false})
    @IsBoolean()
    @Type(() => Boolean)  
    isanimationDesc:boolean; 

   
    @ApiProperty({ default: HomepageSliderStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(HomepageSliderStatus)
    status: HomepageSliderStatus;
}
