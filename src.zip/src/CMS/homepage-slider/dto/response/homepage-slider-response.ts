import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { HomepageSliderStatus } from '../../entities/status.enum';

export class HomepageSliderResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  titleanimationduaration:number;

  @ApiProperty()
  @Expose()
  titleanimationdelay:number;

  @ApiProperty()
  @Expose()
  isanimationDesc:boolean;


  @ApiProperty()
  @Expose()
  imageurl: string;

  @ApiProperty()
  @Expose()
  sequenceNumber: number;

  @ApiProperty({ example: HomepageSliderStatus.INACTIVE })
  @Expose()
  status: HomepageSliderStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

  @ApiProperty()
  @Expose()
  sliderLeftSideContent: string;

  @ApiProperty()
  @Expose()
  sliderDelay: number;

  
  
} 
