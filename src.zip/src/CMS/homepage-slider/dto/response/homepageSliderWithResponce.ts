import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { HomepageSliderResponse } from './homepage-slider-response';

export class HomepageSliderWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: HomepageSliderResponse | HomepageSliderResponse[];

  constructor(message: string, data: HomepageSliderResponse | HomepageSliderResponse[]) {
    this.data = data;
    this.message = message;
  }
}
