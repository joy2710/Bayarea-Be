import { Controller, Get, Post, Body, Param, Delete,UploadedFile,UseInterceptors,UseGuards, Query } from '@nestjs/common';
import { ApiTags,ApiBearerAuth,ApiBody,ApiConsumes } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { FileInterceptor } from '@nestjs/platform-express';
import { Observable, of } from 'rxjs';

import { HomepageSliderService } from './homepage-slider.service';
import { CreateHomepageSliderDto } from './dto/request/create-homepage-slider.dto';
import { UpdateHomepageSliderDto } from './dto/request/update-homepage-slider.dto';
import { HomepageSliderParentRoute, HomepageSliderRoutes } from './homepage-slider.http.routes';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Homepage-Slider')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:HomepageSliderParentRoute})
  // @Public()
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)

export class HomepageSliderController {
  constructor(private readonly homepageSliderService: HomepageSliderService) {}

  @Post(HomepageSliderRoutes.create)
  createHomepageSlider(@Body() body: CreateHomepageSliderDto) {
    return this.homepageSliderService.create(body);
  }

  @Public()
  @Get(HomepageSliderRoutes.view_all)
  findAllHomepageSlider() {
    return this.homepageSliderService.findAll();
  }

  @Public()
  @Get(HomepageSliderRoutes.view_one)
  findHomepageSliderById(@Param('homepageSliderId') id: string) {
    return this.homepageSliderService.findOne(+id);
  }

  @Post(HomepageSliderRoutes.update)
  updateHomepageSliderById(@Param('homepageSliderId') id: string, @Body() body: UpdateHomepageSliderDto) {
    return this.homepageSliderService.update(+id, body);
  }

  @Delete(HomepageSliderRoutes.delete)
  removeHomepageSliderById(@Param('homepageSliderId') id: string) {
    return this.homepageSliderService.remove(+id);
  }

  @Public()
  @Post(HomepageSliderRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {

    return of({ imagePath: `${file.destination}/${file.filename}` })
  }

  @Post(HomepageSliderRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.homepageSliderService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }
}
