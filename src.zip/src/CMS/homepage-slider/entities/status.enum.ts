export enum HomepageSliderStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}