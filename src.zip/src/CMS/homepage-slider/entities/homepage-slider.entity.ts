import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { HomepageSliderStatus } from "./status.enum";

@Entity({ name:'homepage-slider'})
export class HomepageSlider {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    imageurl: string;

    @Column({type: 'longtext'})
    title: string;

    @Column({ name: 'titleanimationduaration', type: 'decimal', precision: 10, scale: 1, nullable: true })
    titleanimationduaration:number;

    @Column({ name: 'titleanimationdelay', type: 'decimal', precision: 10, scale: 1, nullable: true })
    titleanimationdelay:number;

    @Column({type: 'longtext'})
    subtitle: string;

    @Column({ name: 'subtitleanimationduaration', type: 'decimal', precision: 10, scale: 1, nullable: true })
    subtitleanimationduaration:number;

    @Column({ name: 'subtitleanimationdelay', type: 'decimal', precision: 10, scale: 1, nullable: true })
    subtitleanimationdelay:number;

    @Column()
    naviagtionurl: string;

    @Column({ name: 'naviagtionurlanimationduaration', type: 'decimal', precision: 10, scale: 1, nullable: true })
    naviagtionurlanimationduaration:number;

    @Column({ name: 'naviagtionurlanimationdelay', type: 'decimal', precision: 10, scale: 1, nullable: true })
    naviagtionurlanimationdelay:number;

    @Column()
    isanimationDesc:boolean;
    
    @Column()
    sequenceNumber: number;
    
    @Column({ default: HomepageSliderStatus.INACTIVE })
    status: HomepageSliderStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @Column({type: 'longtext', nullable: true})
    sliderLeftSideContent: string;
    
    @Column()
    sliderDelay: number;
}