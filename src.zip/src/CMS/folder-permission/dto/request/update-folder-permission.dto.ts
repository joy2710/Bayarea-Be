import { CreateFolderPermissionDto } from './create-folder-permission.dto';

export class UpdateFolderPermissionDto extends CreateFolderPermissionDto {}
