import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { FolderPermissionResponse } from './folder-permission-response';

export class FolderPermissionWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: FolderPermissionResponse | FolderPermissionResponse[];

  constructor(message: string, data: FolderPermissionResponse | FolderPermissionResponse[]) {
    this.data = data;
    this.message = message;
  }
}
