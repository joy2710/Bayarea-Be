import { Folder } from "src/CMS/folder/entities/folder.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"

@Entity({ name: 'folder-permission' })
export class FolderPermission {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    roleId: number;

    @Column()
    folderId: number;

    @Column('bool')
    isAccess: boolean;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @ManyToOne(() => Folder, (folder: Folder) => folder.folderPermission,
        {
            eager: false,
            onDelete: 'CASCADE'
        })
    folder: Folder[];
}
