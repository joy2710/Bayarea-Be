import { Controller, Get, Post, Body, Param, UseGuards, Req } from '@nestjs/common';
import { FolderPermissionService } from './folder-permission.service';
import { CreateFolderPermissionDto } from './dto/request/create-folder-permission.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FolderPermissionParentRoute, FolderPermissionRoutes } from './folder-permission.http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Folder-permission')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: FolderPermissionParentRoute })
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class FolderPermissionController {
  constructor(private readonly folderPermissionService: FolderPermissionService) { }

  @Post(FolderPermissionRoutes.create)
  createFolderPermission(@Body() body: CreateFolderPermissionDto,) {
    return this.folderPermissionService.createOrUpdatePermission(body);
  }

  // GET-BY-ROLE-ID
  @Get(FolderPermissionRoutes.get_by_role)
  findFolderPermissionByRoleId(@Param('roleId') id: string) {
    return this.folderPermissionService.findByRoleId(+id);
  }
}
