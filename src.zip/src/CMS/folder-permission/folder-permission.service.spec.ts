import { Test, TestingModule } from '@nestjs/testing';
import { FolderPermissionService } from './folder-permission.service';

describe('FolderPermissionService', () => {
  let service: FolderPermissionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FolderPermissionService],
    }).compile();

    service = module.get<FolderPermissionService>(FolderPermissionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
