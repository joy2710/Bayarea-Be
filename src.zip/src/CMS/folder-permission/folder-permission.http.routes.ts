export const FolderPermissionParentRoute = 'folder-permission';

export const FolderPermissionRoutes = {
  create: '',
  get_by_role:'role-type/:roleId'
};
