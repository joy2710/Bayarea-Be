import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, getManager, getRepository, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateFolderPermissionDto } from './dto/request/create-folder-permission.dto';
import { FolderPermission } from './entities/folder-permission.entity';
import { FolderPermissionWithMessageResponse } from './dto/response/folderPermissionWithResponce';
import { RoleService } from '../role/role.service';
import { FolderService } from '../folder/folder.service';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';

@Injectable()
export class FolderPermissionService {
  constructor(
    @InjectRepository(FolderPermission) private folderPermissionRepository: Repository<FolderPermission>,
    private readonly roleRepository: RoleService,
    private readonly folderRepository: FolderService,
    private readonly mailsService: MailService
    ) { }

  async createOrUpdatePermission(request: CreateFolderPermissionDto): Promise<FolderPermissionWithMessageResponse> {
    var result: any;
    var message:any;
    await this.roleRepository.findOne(request.roleId);
    await this.folderRepository.findOne(request.folderId);

    const folderPermissionExist = await getRepository(FolderPermission)
      .createQueryBuilder()
      .where({ roleId: request.roleId, folderId: request.folderId })
      .getOne();
    if (!folderPermissionExist) {
      const folderPermission = await this.folderPermissionRepository.create(request);
      result = await this.folderPermissionRepository.save(folderPermission);
      message=`${Messages.Resource.Created} : Folder-permission`;
    } else {
      result = await getConnection()
        .createQueryBuilder()
        .update(FolderPermission)
        .set({ isAccess: request.isAccess })
        .where({ roleId: request.roleId, folderId: request.folderId })
        .execute();
        message=`${Messages.Resource.Updated} : Folder-permission`;
    }
      return {
        message: message,
        data: result
      }
  }

  async findByRoleId(roleId: number): Promise<FolderPermissionWithMessageResponse> {
    try {
      var permissionList: any;
      const result = getManager().query('SELECT A.id as ID,A.name ,B.* FROM `folder` AS A left outer join (select * from `folder-permission` where roleId=' + `${roleId}) B on A.id=B.folderId`)
      await result.then((val: any) => {
        permissionList = val;
        return permissionList

      })
      if (!permissionList)
        throw new HttpException(`Folder-permission not found`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Folder-permission`,
        data: permissionList
      }
    } catch (error) {
      throw error;
    }
  }
}
