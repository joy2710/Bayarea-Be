import { Test, TestingModule } from '@nestjs/testing';
import { FolderPermissionController } from './folder-permission.controller';
import { FolderPermissionService } from './folder-permission.service';

describe('FolderPermissionController', () => {
  let controller: FolderPermissionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FolderPermissionController],
      providers: [FolderPermissionService],
    }).compile();

    controller = module.get<FolderPermissionController>(FolderPermissionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
