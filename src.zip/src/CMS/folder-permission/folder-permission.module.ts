import { Module } from '@nestjs/common';
import { FolderPermissionService } from './folder-permission.service';
import { FolderPermissionController } from './folder-permission.controller';
import { FolderPermission } from './entities/folder-permission.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Role } from '../role/entities/role.entity';
import { Folder } from '../folder/entities/folder.entity';
import { RoleModule } from '../role/role.module';
import { FolderModule } from '../folder/folder.module';
import { RoleService } from '../role/role.service';
import { FolderService } from '../folder/folder.service';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { Setting } from '../setting/entities/setting.entity';
import { SettingService } from '../setting/setting.service';
import { SettingModule } from '../setting/setting.module';
import { ConfigService } from '@nestjs/config';

@Module({
  imports:[TypeOrmModule.forFeature([FolderPermission,Role,Folder,Setting]),RoleModule,FolderModule,SettingModule],
  controllers: [FolderPermissionController],
  providers: [FolderPermissionService,RoleService,FolderService,MailService,SettingService,ConfigService],
  exports: [MailService]
})
export class FolderPermissionModule {}
