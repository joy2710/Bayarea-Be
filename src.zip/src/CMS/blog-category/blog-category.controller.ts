import { Controller, Get, Post, Body, Param, Delete,UseGuards } from '@nestjs/common';
import { ApiTags,ApiBearerAuth } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { BlogCategoryParentRoute, BlogCategoryRoutes } from './blog-category.http.routes';

import { BlogCategoryService } from './blog-category.service';
import { CreateBlogCategoryDto } from './dto/request/create-blog-category.dto';
import { UpdateBlogCategoryDto } from './dto/request/update-blog-category.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Blog-Category')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:BlogCategoryParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class BlogCategoryController {
  constructor(private readonly blogCategoryService: BlogCategoryService) {}

  @Post(BlogCategoryRoutes.create)
  createBlogCategory(@Body() body: CreateBlogCategoryDto) {
    return this.blogCategoryService.create(body);
  }

  @Public()
  @Get(BlogCategoryRoutes.view_all)
  findAllBlogCategory() {
    return this.blogCategoryService.findAll();
  }

  @Public()
  @Get(BlogCategoryRoutes.view_one)
  findBlogCategoryById(@Param('blogCategoryId') id: string) {
    return this.blogCategoryService.findOne(+id);
  }

  @Post(BlogCategoryRoutes.update)
  updateBlogCategoryById(@Param('blogCategoryId') id: string, @Body() body: UpdateBlogCategoryDto) {
    return this.blogCategoryService.update(+id, body);
  }

  @Delete(BlogCategoryRoutes.delete)
  removeBlogCategoryById(@Param('blogCategoryId') id: string) {
    return this.blogCategoryService.remove(+id);
  }
  @Get(BlogCategoryRoutes.getDetailsByBlogId)
  findCategoryByBlogId(@Param('blogId') id: string) {
    return this.blogCategoryService.findOneBlog(+id);
  }

  @Delete(BlogCategoryRoutes.deleteByCategoryId)
  removeBlogCategoryByCategoryId(@Param('categoryId') categoryId: string) {
    return this.blogCategoryService.removeByCategoryId(+categoryId);
  }

  @Public()
  @Get(BlogCategoryRoutes.get_blog_by_category_id)
  getBlogByCategoryId(@Param('categoryId') id: string) {
    return this.blogCategoryService.getBlogByCategoryId(+id);
  }
}
