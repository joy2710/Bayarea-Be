export const BlogCategoryParentRoute = 'blog-category';

export const BlogCategoryRoutes = {
  create: '',
  update: 'update/:blogCategoryId',
  delete: ':blogCategoryId',
  view_one: ':blogCategoryId',
  view_all: '',
  getDetailsByBlogId: 'blog/:blogId',
  deleteByCategoryId:'category/:categoryId',
  get_blog_by_category_id: 'getBlogByCategoryId/:categoryId'
};
