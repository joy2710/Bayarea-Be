import {
  HttpException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateBlogCategoryDto } from './dto/request/create-blog-category.dto';
import { UpdateBlogCategoryDto } from './dto/request/update-blog-category.dto';
import { BlogCategoryWithMessageResponse } from './dto/response/blogCategoryWithResponce';
import { BlogCategory } from './entities/blog-category.entity';
import { Category } from 'src/category/entities/category.entity';

@Injectable()
export class BlogCategoryService {
  blogRepository: any;
  constructor(
    @InjectRepository(BlogCategory)
    private blogCategoryRepository: Repository<BlogCategory>,
  ) {}
  async create(
    request: CreateBlogCategoryDto,
  ): Promise<BlogCategoryWithMessageResponse> {
    const blogCategory = await this.blogCategoryRepository.create(request);
    const result = await this.blogCategoryRepository.save(blogCategory);
    if (result) {
      return {
        message: `${Messages.Resource.Created}:Blog-category`,
        data: result,
      };
    }
  }

  async findAll(): Promise<BlogCategoryWithMessageResponse> {
    const result = await this.blogCategoryRepository.
    find({
      relations: ['blog', 'category'],
    });
    if (result) {
      
      return {
        message: `${Messages.Resource.Found} : Blog-category`,
        data: result,
      };
    }
  }

  async findOne(
    blogCategoryId: number,
  ): Promise<BlogCategoryWithMessageResponse> {
    try {
      const result = await this.blogCategoryRepository.findOne({
        relations: ['blog', 'category'],
        where: { id: blogCategoryId },
      });
      if (!result)
        throw new HttpException(
          `${Messages.Resource.NotFound}: Blog-category`,
          HttpStatus.NOT_FOUND,
        );
      return {
        message: `${Messages.Resource.Found} : Blog-category`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }

  async findOneBlog(blogId: number): Promise<BlogCategoryWithMessageResponse> {
    try {
      const result = await this.blogCategoryRepository.find({
        relations: ['blog', 'category'],
        where: { blogId: blogId },
      });
      if (!result)
        throw new HttpException(
          `${Messages.Resource.NotFound}: Blog-category`,
          HttpStatus.NOT_FOUND,
        );
      return {
        message: `${Messages.Resource.Found} : Blog-category`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }

  async update(
    blogCategoryId: number,
    request: UpdateBlogCategoryDto,
  ): Promise<BlogCategoryWithMessageResponse> {
    const data = await this.blogCategoryRepository.findOne(blogCategoryId);
    if (!data) {
      throw new HttpException(
        `${Messages.Resource.NotFound} : Blog-category`,
        HttpStatus.NOT_FOUND,
      );
    }
    await this.blogCategoryRepository.update(blogCategoryId, request);
    return {
      message: `${Messages.Resource.Updated} : Blog-category`,
    };
  }

  async remove(
    blogCategoryId: number,
  ): Promise<BlogCategoryWithMessageResponse> {
    try {
      const deleteBlogCategory = await this.blogCategoryRepository.delete(
        blogCategoryId,
      );
      if (deleteBlogCategory.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Blog-category`,
        };
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async removeByCategoryId(categoryId: number): Promise<any> {
    const deleteByCategory = await getConnection()
      .createQueryBuilder()
      .delete()
      .from(BlogCategory)
      .where('categoryId = :categoryId', { categoryId: categoryId })
      .execute();
    return deleteByCategory;
  }

  async removeByBlogId(blogId: number): Promise<any> {
    const deleteByBlog = await getConnection()
      .createQueryBuilder()
      .delete()
      .from(BlogCategory)
      .where('blogId = :blogId', { blogId: blogId })
      .execute();
    return deleteByBlog;
  }

  async getBlogByCategoryId(categoryId: number) {
    const res = await this.blogCategoryRepository.find({
      relations: ['blog','category'],
      where: {
        categoryId: categoryId
      }
    })
    return res;
  }
}
