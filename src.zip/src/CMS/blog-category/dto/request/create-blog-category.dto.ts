import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty } from "class-validator"
import { BlogCategoryStatus } from "../../entities/status.enum";


export class CreateBlogCategoryDto {

    @ApiProperty()
    @IsNotEmpty()
    blogId: number;

    @ApiProperty()
    @IsNotEmpty()
    categoryId: number;

} 
