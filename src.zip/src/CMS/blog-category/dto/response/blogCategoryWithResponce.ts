import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BlogCategoryResponse } from './blog-category-response';

export class BlogCategoryWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: BlogCategoryResponse | BlogCategoryResponse[];

  constructor(message: string, data: BlogCategoryResponse | BlogCategoryResponse[]) {
    this.data = data;
    this.message = message;
  }
}
