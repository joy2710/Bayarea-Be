export enum BlogCategoryStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}