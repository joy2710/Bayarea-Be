import { Category } from 'src/category/entities/category.entity';
import { Blog } from 'src/CMS/blog/entities/blog.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({ name: 'blog-category' })
export class BlogCategory {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  blogId: number;

 

  @Column()
  categoryId: number;
//category with blog and blog category
  @ManyToOne(() => Category, (category: Category) => category.blogCategory, {
    eager: false,
    onDelete: 'CASCADE',
  })
  category: Category[];

  


//relation with blog and blog category
  @ManyToOne(() => Blog, (blog: Blog) => blog.blogCategory, {
    eager: false,
    onDelete: 'CASCADE',
  })
  blog: Blog[];

  @CreateDateColumn({ name: 'createdDate' })
  createdDate: Date;

  @Column()
  createdBy: number;
}
