export enum HeaderStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}
