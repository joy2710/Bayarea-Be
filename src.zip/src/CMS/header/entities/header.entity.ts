import { Page } from "src/CMS/page/entities/page.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { HeaderStatus } from "./status.enum";
@Entity({ name: 'header' })
export class Header {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string;

    @Column({type: 'longtext'})
    description: string;

    @Column({ default: HeaderStatus.INACTIVE })
    status: HeaderStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @OneToMany(() => Page, (page: Page) => page.header)
    page: Page;
}
