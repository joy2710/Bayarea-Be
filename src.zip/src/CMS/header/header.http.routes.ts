export const HeaderRoute = 'header';

export const HeaderContentRoutes = {
  create: '',
  update: 'update/:headerId',
  delete: ':headerId',
  view_one: ':headerId',
  view_all: '',
};
