import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import {  HeaderStatus } from "../../entities/status.enum";

export class CreateHeaderDto {
    @ApiProperty()
    @IsNotEmpty()
    title: string;

    @ApiProperty()
    @IsNotEmpty()
    description: string;
    
    @ApiProperty({ default: HeaderStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(HeaderStatus)
    status: HeaderStatus;

  
}
