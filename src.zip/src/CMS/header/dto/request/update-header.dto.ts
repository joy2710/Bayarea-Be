import { CreateHeaderDto } from "./create-header.dto";
export class UpdateCaseStudyDto extends CreateHeaderDto {}
