import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { HeaderResponse } from './header-response';


export class HeaderWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: HeaderResponse | HeaderResponse[];

  constructor(message: string, data: HeaderResponse | HeaderResponse[]) {
    this.data = data;
    this.message = message;
  }
}
