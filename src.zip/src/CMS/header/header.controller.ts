import { Controller, Get, Post, Body , Param, Delete, UseGuards } from '@nestjs/common';
import { HeaderService } from './header.service';

import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { HeaderContentRoutes, HeaderRoute } from './header.http.routes';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CreateHeaderDto } from './dto/request/create-header.dto';
import { Public } from 'src/auth/constants';


/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Header')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path: HeaderRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

// @Public()


export class HeaderController {
  constructor(private readonly headerService: HeaderService) {}

  @Post(HeaderContentRoutes.create)
  create(@Body() createHeaderDto: CreateHeaderDto) {
    return this.headerService.create(createHeaderDto);
  }

  @Public()
  @Get(HeaderContentRoutes.view_all)
  findAll() {
    return this.headerService.findAll();
  }

  @Public()
  @Get(HeaderContentRoutes.view_one)
  findOne(@Param('headerId') id: string) {
    return this.headerService.findOne(+id);
  }

  @Post(HeaderContentRoutes.update)
  update(@Param('headerId') id: string, @Body() updateHeaderDto: CreateHeaderDto) {
    return this.headerService.update(+id, updateHeaderDto);
  }

  @Delete(HeaderContentRoutes.delete)
  remove(@Param('headerId') id: string) {
    return this.headerService.remove(+id);
  }
}
