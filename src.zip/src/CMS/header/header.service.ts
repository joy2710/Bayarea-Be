import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';

import { Header } from './entities/header.entity';
import {HeaderWithMessageResponse} from './dto/response/headerWithResponce'
import { CreateHeaderDto } from './dto/request/create-header.dto';

@Injectable()
export class HeaderService {
  constructor(
    @InjectRepository(Header) private headerRepository: Repository<Header>
  ) { }

  async create(request: CreateHeaderDto): Promise<HeaderWithMessageResponse> {
    const Header = await this.headerRepository.create(request);
    const result = await this.headerRepository.save(Header);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Header`,
        data: result
      }
    }
  }
  async findAll(): Promise<HeaderWithMessageResponse> {
    const result = await this.headerRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Header`,
        data: result
      }
    }
  }

  async findOne(headerId: number): Promise<HeaderWithMessageResponse> {
    try {
      const result = await this.headerRepository.findOne(
        {
          where:
            { id: headerId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Header`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Header`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }


  async update(headerId: number, request: CreateHeaderDto): Promise<HeaderWithMessageResponse> {
    const data = await this.headerRepository.findOne(headerId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Header`, HttpStatus.NOT_FOUND);
    }
    await this.headerRepository.update(headerId, request)
    return {
      message: `${Messages.Resource.Updated} : Header`,
    }

  }

  async remove(headerId: number): Promise<HeaderWithMessageResponse> {
    try {
      const deleteCaseStudy = await this.headerRepository.delete(headerId)
      if (deleteCaseStudy.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Header`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
