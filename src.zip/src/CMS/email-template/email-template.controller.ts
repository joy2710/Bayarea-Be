import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { EmailTemplateService } from './email-template.service';
import { CreateEmailTemplateDto } from './dto/request/create-email-template.dto';
import { UpdateEmailTemplateDto } from './dto/request/update-email-template.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { EmailTemplateRoute, EmailTemplateRoutes } from './email-template.http.routes';
import { Public } from 'src/auth/constants';


/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Email-template')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: EmailTemplateRoute })
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class EmailTemplateController {
  constructor(private readonly emailTemplateService: EmailTemplateService) {}

  @Post(EmailTemplateRoutes.create)
  create(@Body() createEmailTemplateDto: CreateEmailTemplateDto) {
    return this.emailTemplateService.create(createEmailTemplateDto);
  }

  @Get(EmailTemplateRoutes.view_all)
  findAll() {
    return this.emailTemplateService.findAll();
  }

  @Public()
  @Get(EmailTemplateRoutes.view_one)
  findOne(@Param('emailTemplateId') id: number) {
    return this.emailTemplateService.findOne(+id);
  }

  @Post(EmailTemplateRoutes.update)
  update(@Param('emailTemplateId') id: number, @Body() updateEmailTemplateDto: UpdateEmailTemplateDto) {
    return this.emailTemplateService.update(+id, updateEmailTemplateDto);
  }

  @Delete(EmailTemplateRoutes.delete)
  remove(@Param('emailTemplateId') id: number) {
    return this.emailTemplateService.remove(+id);
  }

}
