export const EmailTemplateRoute = 'emailTemplate';

export const EmailTemplateRoutes = {
    create: '',
    update: 'update/:emailTemplateId',
    delete: ':emailTemplateId',
    view_one: ':emailTemplateId',
    view_all: '',
}