import { ApiProperty } from "@nestjs/swagger";
import { IsOptional } from "class-validator";

export class CreateEmailTemplateDto {

    @ApiProperty()
    @IsOptional()
    templateName: string;

    @ApiProperty()
    @IsOptional()
    templateTags: string;

    @ApiProperty()
    @IsOptional()
    templateContent: string

}
