import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { EmailTemplateResponse } from './email-template-response';

export class EmailTemplateWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: EmailTemplateResponse | EmailTemplateResponse[];

  constructor(message: string, data: EmailTemplateResponse | EmailTemplateResponse[]) {
    this.data = data;
    this.message = message;
  }
}
    