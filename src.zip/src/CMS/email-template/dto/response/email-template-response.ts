import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { TransformDateToEpoch } from "src/common/helpers/decorators/transformDateToEpoch";

export class EmailTemplateResponse {

    @ApiProperty()
    @Expose()
    id: number;

    @ApiProperty()
    @Expose()
    templateName: string;

    @ApiProperty()
    @Expose()
    templateTags: string;

    @ApiProperty()
    @Expose()
    templateContent: string

    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    createdDate?: Date;

    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    updatedDate?: Date;
}