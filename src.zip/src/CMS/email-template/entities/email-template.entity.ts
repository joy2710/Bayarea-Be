import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity({ name: 'email-template' })
export class EmailTemplate {
        @PrimaryGeneratedColumn()
        id: number;
    
        @Column()
        templateName: string;
    
        @Column()
        templateTags: string;
    
        @Column()
        templateContent: string
    
        @CreateDateColumn({ name: 'createdDate' })
        createdDate: Date;
    
        @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
        updatedDate: Date;

}
