import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { UpdateEmailTemplateDto } from './dto/request/update-email-template.dto';
import { CreateEmailTemplateDto } from './dto/request/create-email-template.dto';
import { Messages } from 'src/common/constants/messages';
import { InjectRepository } from '@nestjs/typeorm';
import { EmailTemplate } from './entities/email-template.entity';
import { Repository } from 'typeorm';
import { EmailTemplateWithMessageResponse } from './dto/response/emailTemplateWithResponse';

@Injectable()
export class EmailTemplateService {
  constructor(
    @InjectRepository(EmailTemplate)
    private emailTemplatetRepository: Repository<EmailTemplate>,
  ) { }

 async create(
  createEmailTemplateDto: CreateEmailTemplateDto,
  ): Promise<EmailTemplateWithMessageResponse> {
    const createEmailTemplate = await this.emailTemplatetRepository.create(createEmailTemplateDto,
    );
    const result = await this.emailTemplatetRepository.save(createEmailTemplate);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Email-Templatet`,
      };
    }
  }

  async findAll(): Promise<any> {
    const result = await this.emailTemplatetRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found}: Email-Templatet`,
        data: result,
      };
    }
  }

  async findOne(emailTemplatetId: number): Promise<EmailTemplateWithMessageResponse> {
    try {
      const result = await this.emailTemplatetRepository.findOne({
        where: {
          id: emailTemplatetId,
        },
      });
      if (!result)
        throw new HttpException(
          `${Messages.Resource.NotFound}: Email-Templatet`,
          HttpStatus.NOT_FOUND,
        );
      return {
        data: result,
        message: `${Messages.Resource.Found}: Email-Templatet`,
      };
    } catch (error) {
      throw error;
    }
  }

  async update(emailTemplatetId: number, updateEmailTemplateDto: UpdateEmailTemplateDto): Promise<EmailTemplateWithMessageResponse> {
    const data = await this.emailTemplatetRepository.findOne(emailTemplatetId)
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Email-Templatet`, HttpStatus.NOT_FOUND);
    }
    await this.emailTemplatetRepository.update(emailTemplatetId, updateEmailTemplateDto)
    return {
      message: `${Messages.Resource.Updated} : Email-Templatet`
    };
  }

  async remove(emailTemplatetId: number): Promise<EmailTemplateWithMessageResponse> {
    try {
      const deleteEmailTemplate = await this.emailTemplatetRepository.delete(emailTemplatetId);
      if (deleteEmailTemplate.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Email-Templatet`
        }
      }
    }
    catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
