import { forwardRef, Module } from '@nestjs/common';
import { CaseAssignService } from './case-assign.service';
import { CaseAssignController } from './case-assign.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CaseAssign } from './entities/case-assign.entity';
import { Cases } from '../cases/entities/cases.entity';
import { Employee } from '../employee/entities/employee.entity';
import { CasesService } from '../cases/cases.service';
import { EmployeeModule } from '../employee/employee.module';
import { CasesModule } from '../cases/cases.module';
import { EmployeeService } from '../employee/employee.service';
import { Client } from '../client/entities/client.entity';
import { ClientService } from '../client/client.service';
import { Order } from '../order/entities/order.entity';
import { TaskInstruction } from '../task-instruction/entities/task-instruction.entity';
import { CaseAssociation } from '../case-association/entities/case-association.entity';
import { OrderPayment } from '../order-payment/entities/order-payment.entity';
import { OrderInventorsService } from '../order-inventors/order-inventors.service';
import { OrderInventor } from '../order-inventors/entities/order-inventor.entity';
import { OrderAssigneeDocument } from '../order-assignee-document/entities/order-assignee-document.entity';
import { OrderAssigneeDocumentService } from '../order-assignee-document/order-assignee-document.service';
import { CaseFile } from '../case-file/entities/case-file.entity';
import { CaseFileService } from '../case-file/case-file.service';
import { Folder } from '../folder/entities/folder.entity';
import { ProductOrderDetailForm } from '../product-order-detail-form/entities/product-order-detail-form.entity';
import { ClientModule } from '../client/client.module';
import { ConfigService } from '@nestjs/config';
import { StatusLookupModule } from '../status-lookup/status-lookup.module';

@Module({
  imports: [TypeOrmModule.forFeature([CaseAssign,OrderInventor,Employee,Cases,OrderAssigneeDocument, Client,Folder,ProductOrderDetailForm, Order,OrderPayment,CaseFile, TaskInstruction,CaseAssociation]),ClientModule,forwardRef(() => EmployeeModule) ,forwardRef(() => CasesModule),forwardRef(() => StatusLookupModule)],
  controllers: [CaseAssignController],
  providers: [CasesService,EmployeeService,CaseAssignService,OrderInventorsService,OrderAssigneeDocumentService,ConfigService],
  exports:[CaseAssignService,EmployeeService,OrderInventorsService]
})
export class CaseAssignModule {}
