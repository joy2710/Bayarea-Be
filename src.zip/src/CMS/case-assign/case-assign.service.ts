import { forwardRef, HttpException, HttpStatus, Inject, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';import { CasesService } from '../cases/cases.service';
import { EmployeeService } from '../employee/employee.service';
import { CreateCaseAssignDto } from './dto/request/create-case-assign.dto';
import { UpdateCaseAssignDto } from './dto/request/update-case-assign.dto';
import { CaseAssignWithMessageResponse } from './dto/response/caseAssignWithResponse';
import { CaseAssign } from './entities/case-assign.entity';

@Injectable()
export class CaseAssignService {
  constructor(
    @InjectRepository(CaseAssign) private caseAssignRepository: Repository<CaseAssign>,
    @Inject(forwardRef(() => CasesService))
    private caseRepository:CasesService,
    @Inject(forwardRef(() => EmployeeService))
   private employeeRepository:EmployeeService,
    ) { }
  
  async create(createCaseAssignDto: CreateCaseAssignDto): Promise<CaseAssignWithMessageResponse> {
   await this.caseRepository.findOne(createCaseAssignDto.caseId);
   await this.employeeRepository.findOne(createCaseAssignDto.employeeId);

    const result = await this.caseAssignRepository.save(createCaseAssignDto);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Case-assign`,
        data: result
      }
    }
    
  }

  async findAll(): Promise<CaseAssignWithMessageResponse> {
    const result = await this.caseAssignRepository.find({ relations:['employee']});
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Case-assign`,
        data: result
      }
    }
  }

  async findOne(caseAssignId: number): Promise<CaseAssignWithMessageResponse> {
    try {
      const result = await this.caseAssignRepository.findOne(
        {
          relations:['employee'],
          where:
            { id: caseAssignId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Case-assign`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Case-assign`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(caseAssignId: number, updateCaseAssignDto: UpdateCaseAssignDto): Promise<CaseAssignWithMessageResponse> {
    await this.caseRepository.findOne(updateCaseAssignDto.caseId);
    await this.employeeRepository.findOne(updateCaseAssignDto.employeeId);
 
    const data = await this.caseAssignRepository.findOne(caseAssignId);
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Case-assign`, HttpStatus.NOT_FOUND);
    }
    await this.caseAssignRepository.update(caseAssignId, updateCaseAssignDto)
    return {
      message: `${Messages.Resource.Updated} : Case-assign`,
    }
  }

  async remove(caseAssignId: number): Promise<CaseAssignWithMessageResponse> {
    try {
      const deleteCaseAssign = await this.caseAssignRepository.delete(caseAssignId)
      if (deleteCaseAssign.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Case-assign`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  
  async findByCaseId(caseId: number): Promise<CaseAssignWithMessageResponse> {
    try {
      const result = await this.caseAssignRepository.find(
        {
          relations:['employee','case'],
          where:
            { caseId: caseId }
        }
      );
    
      if (result)
      return {
        message: `${Messages.Resource.Found} : Case-assign by case-id`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }
}
