import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsOptional } from "class-validator";
import { JobAssigned } from "../../entities/job-assign.enum";
import { CaseAssignStatus } from "../../entities/status.enum";

export class CreateCaseAssignDto {
    @ApiProperty()
    @IsNotEmpty()
    caseId: number;

    @ApiProperty()
    @IsNotEmpty()
    employeeId: number;

    @ApiProperty({ default: JobAssigned.CLAIMS })
    @IsNotEmpty()
    @IsEnum(JobAssigned)
    jobAssigned: JobAssigned;

    @ApiProperty()
    @IsOptional()
    cost: number;

    @ApiProperty()
    @IsOptional()
    dateAssigned: string;

    @ApiProperty()
    @IsOptional()
    notes: string;

    @ApiProperty({ default: CaseAssignStatus.PENDING_ACCEPTANCE })
    @IsNotEmpty()
    @IsEnum(CaseAssignStatus)
    status: CaseAssignStatus;
}

