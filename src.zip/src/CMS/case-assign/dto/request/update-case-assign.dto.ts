import { PartialType } from '@nestjs/swagger';
import { CreateCaseAssignDto } from './create-case-assign.dto';

export class UpdateCaseAssignDto extends PartialType(CreateCaseAssignDto) {}
