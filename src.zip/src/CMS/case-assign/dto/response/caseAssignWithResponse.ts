import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CaseAssignResponse } from './case-assign.response';

export class CaseAssignWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CaseAssignResponse | CaseAssignResponse[];

  constructor(message: string, data: CaseAssignResponse | CaseAssignResponse[]) {
    this.data = data;
    this.message = message;
  }
}
