import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { JobAssigned } from '../../entities/job-assign.enum';
import { CaseAssignStatus } from '../../entities/status.enum';

export class CaseAssignResponse {
    @ApiProperty()
    @Expose()
    id: number;

    @ApiProperty()
    @Expose()
    caseId: number;

    @ApiProperty()
    @Expose()
    employeeId: number;

    @ApiProperty({ example: JobAssigned })
    @Expose()
    jobAssigned: JobAssigned;

    @ApiProperty()
    @Expose()
    cost: number;

    @ApiProperty()
    @Expose()
    dateAssigned: string;

    @ApiProperty()
    @Expose()
    notes: string;

    @ApiProperty({ example: CaseAssignStatus })
    @Expose()
    status: CaseAssignStatus;

    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    createdDate?: Date;

    @ApiProperty()
    @Expose()
    createdby?: string;

    @ApiPropertyOptional({ example: Date.now() / 1000 })
    @TransformDateToEpoch()
    @Expose()
    updatedDate?: Date;

    @ApiProperty()
    @Expose()
    updatedby?: string;
}
