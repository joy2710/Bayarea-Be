import { Controller, Get, Post, Body, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CaseAssignParentRoute, CaseAssignRoutes } from './case-assign.http.routes';
import { CaseAssignService } from './case-assign.service';
import { CreateCaseAssignDto } from './dto/request/create-case-assign.dto';
import { UpdateCaseAssignDto } from './dto/request/update-case-assign.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Case-assign')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CaseAssignParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()

export class CaseAssignController {
  constructor(private readonly caseAssignService: CaseAssignService) {}

  @Post(CaseAssignRoutes.create)
  create(@Body() createCaseAssignDto: CreateCaseAssignDto) {
    return this.caseAssignService.create(createCaseAssignDto);
  }

  @Public()
  @Get(CaseAssignRoutes.view_all)
  findAll() {
    return this.caseAssignService.findAll();
  }

  @Public()
  @Get(CaseAssignRoutes.view_one)
  findOne(@Param('caseAssignId') id: number) {
    return this.caseAssignService.findOne(id);
  }

  @Post(CaseAssignRoutes.update)
  update(@Param('caseAssignId') id: number, @Body() updateCaseAssignDto: UpdateCaseAssignDto) {
    return this.caseAssignService.update(id, updateCaseAssignDto);
  }

  @Delete(CaseAssignRoutes.delete)
  remove(@Param('caseAssignId') id: number) {
    return this.caseAssignService.remove(id);
  }
  @Get(CaseAssignRoutes.get_by_caseId)
  findByCaseId(@Param('caseId') id: number) {
    return this.caseAssignService.findByCaseId(id);
  }
}
