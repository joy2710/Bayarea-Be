import { Test, TestingModule } from '@nestjs/testing';
import { CaseAssignController } from './case-assign.controller';
import { CaseAssignService } from './case-assign.service';

describe('CaseAssignController', () => {
  let controller: CaseAssignController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CaseAssignController],
      providers: [CaseAssignService],
    }).compile();

    controller = module.get<CaseAssignController>(CaseAssignController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
