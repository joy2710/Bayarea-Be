import { Test, TestingModule } from '@nestjs/testing';
import { CaseAssignService } from './case-assign.service';

describe('CaseAssignService', () => {
  let service: CaseAssignService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CaseAssignService],
    }).compile();

    service = module.get<CaseAssignService>(CaseAssignService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
