export const CaseAssignParentRoute = 'case-assign';

export const CaseAssignRoutes = {
  create: '',
  update: 'update/:caseAssignId',
  delete: ':caseAssignId',
  view_one: ':caseAssignId',
  view_all: '',
  get_by_caseId: 'case-id/:caseId',
};
