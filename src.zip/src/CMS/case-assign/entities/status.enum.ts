export enum CaseAssignStatus {
    NOTASSIGNED = 'Not Assigned',
    PENDING_ACCEPTANCE = 'Pending Acceptance',
    ACCEPTED = 'Accepted',
    NOTACCEPTED = 'Not Accepted',
    NOTRESPONSE = 'Not Response',
    LATE = 'Late',
    ONHOLD = 'On Hold',
}