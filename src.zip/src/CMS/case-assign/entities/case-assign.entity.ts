import { Cases } from "src/CMS/cases/entities/cases.entity";
import { Employee } from "src/CMS/employee/entities/employee.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { JobAssigned } from "./job-assign.enum";
import { CaseAssignStatus } from "./status.enum";

@Entity({ name: 'case-assign' })
export class CaseAssign {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    caseId: number;

    @Column()
    employeeId: number;

    @Column({ default: JobAssigned.CLAIMS })
    jobAssigned: JobAssigned;

    @Column()
    cost: number;

    @Column()
    dateAssigned: string;

    @Column()
    notes: string;

    @Column({ default: CaseAssignStatus.PENDING_ACCEPTANCE })
    status: CaseAssignStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;
    
    @ManyToOne(() => Employee, (employee: Employee) => employee.caseAssign,
    {
        eager: false,
        onDelete: 'CASCADE'
    })
    employee: Employee[];

    @ManyToOne(() => Cases, (cases: Cases) => cases.caseAssign,
    {
        eager: false,
        onDelete: 'CASCADE'
    })
    case: Cases[];
}
