export enum JobAssigned {
    CLAIMS = 'claims',
    DRAWINGS = 'drawings',
    FILINGS = 'filings',
    IDS = 'ids',
    SEARCH = 'search',
    SPEC = 'spec'
}
