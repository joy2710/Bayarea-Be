import { Controller, Get, Post, Body, Param, Delete,UseGuards,UseInterceptors, UploadedFile, Query } from '@nestjs/common';
import { ApiTags,ApiBearerAuth, ApiBody, ApiConsumes } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { FileInterceptor } from '@nestjs/platform-express';
import { Observable, of } from 'rxjs';

import { LogoScrollerService } from './logo-scroller.service';
import { CreateLogoScrollerDto } from './dto/request/create-logo-scroller.dto';
import { UpdateLogoScrollerDto } from './dto/request/update-logo-scroller.dto';
import { LogoScrollerParentRoute, LogoScrollerRoutes } from './logo-scroller.http.routes';
import { multerOptions } from 'src/common/helpers/uploadImage/uploadImage';
import { Public } from 'src/auth/constants';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Logo-Scroller')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({path:LogoScrollerParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

// @Public()

export class LogoScrollerController {
  constructor(private readonly logoScrollerService: LogoScrollerService) {}

  @Post(LogoScrollerRoutes.create)
  createLogoScroller(@Body() body: CreateLogoScrollerDto) {
    return this.logoScrollerService.create(body);
  }
 
  @Public()
  @Get(LogoScrollerRoutes.view_all)
  findAllLogoScroller() {
    return this.logoScrollerService.findAll();
  }

  @Public()
  @Get(LogoScrollerRoutes.view_one)
  findLogoScrollerById(@Param('logoScrollerId') id: string) {
    return this.logoScrollerService.findOne(+id);
  }

  @Post(LogoScrollerRoutes.update)
  updateLogoScrollerById(@Param('logoScrollerId') id: string, @Body() body: UpdateLogoScrollerDto) {
    return this.logoScrollerService.update(+id, body);
  }

  @Delete(LogoScrollerRoutes.delete)
  removeLogoScrollerById(@Param('logoScrollerId') id: string) {
    return this.logoScrollerService.remove(+id);
  }

  @Public()
  @Post(LogoScrollerRoutes.upload_image)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { 
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  uploadFile(@UploadedFile() file: Express.Multer.File): Observable<Object> {

    return of({ imagePath: `${file.destination}/${file.filename}` })
  }

  @Public()
  @Post(LogoScrollerRoutes.updateDragAndDrop)
  dragAndDrop(
    @Query('currSequenceNumber') currSequenceNumber: number, 
    @Query('newSequenceNumber') newSequenceNumber: number,
    ) {
    return this.logoScrollerService.dragAndDrop(currSequenceNumber, newSequenceNumber);
  }
}
