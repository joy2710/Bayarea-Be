import { Test, TestingModule } from '@nestjs/testing';
import { LogoScrollerController } from './logo-scroller.controller';
import { LogoScrollerService } from './logo-scroller.service';

describe('LogoScrollerController', () => {
  let controller: LogoScrollerController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [LogoScrollerController],
      providers: [LogoScrollerService],
    }).compile();

    controller = module.get<LogoScrollerController>(LogoScrollerController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
