import { Module } from '@nestjs/common';
import { LogoScrollerService } from './logo-scroller.service';
import { LogoScrollerController } from './logo-scroller.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LogoScroller } from './entities/logo-scroller.entity';

@Module({
  imports:[TypeOrmModule.forFeature([LogoScroller])],
  controllers: [LogoScrollerController],
  providers: [LogoScrollerService]

  
})
export class LogoScrollerModule {}


