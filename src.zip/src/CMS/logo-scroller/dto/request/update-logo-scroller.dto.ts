import { CreateLogoScrollerDto } from './create-logo-scroller.dto';

export class UpdateLogoScrollerDto extends CreateLogoScrollerDto {}
