import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty } from "class-validator";
import { LogoScrollerType } from "../../entities/logo-scroller-type.enum";
import { LogoScrollerStatus } from "../../entities/status.enum";

export class CreateLogoScrollerDto {

    @ApiProperty()
    @IsNotEmpty()
    imageurl: string;

    @ApiProperty()
    @IsNotEmpty()
    navigationurl: string;

    @ApiProperty({ default: LogoScrollerType.MARKETING })
    @IsNotEmpty()
    @IsEnum(LogoScrollerType)
    type: LogoScrollerType;

    @ApiProperty({ default: LogoScrollerStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(LogoScrollerStatus)
    status: LogoScrollerStatus;

    @ApiProperty()
    @IsNotEmpty()
    sequenceNumber: number;
}

