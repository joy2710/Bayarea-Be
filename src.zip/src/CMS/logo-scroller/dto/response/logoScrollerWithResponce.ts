import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { LogoScrollerResponse } from './logo-scroller-response';

export class LogoScrollerWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: LogoScrollerResponse | LogoScrollerResponse[];

  constructor(message: string, data: LogoScrollerResponse | LogoScrollerResponse[]) {
    this.data = data;
    this.message = message;
  }
}
