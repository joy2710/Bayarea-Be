import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { TransformDateToEpoch } from 'src/common/helpers/decorators/transformDateToEpoch';
import { LogoScrollerType } from '../../entities/logo-scroller-type.enum';
import { LogoScrollerStatus } from '../../entities/status.enum';

export class LogoScrollerResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  imageurl: string;

  @ApiProperty()
  @Expose()
  navigationurl: string;

  @ApiProperty({ default: LogoScrollerType })
  @Expose()
  type: LogoScrollerType;

  @ApiProperty({ example: LogoScrollerStatus })
  @Expose()
  status: LogoScrollerStatus;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  createdDate?: Date;

  @ApiProperty()
  @Expose()
  createdby?: string;

  @ApiPropertyOptional({ example: Date.now() / 1000 })
  @TransformDateToEpoch()
  @Expose()
  updatedDate?: Date;

  @ApiProperty()
  @Expose()
  updatedby?: string;

  @ApiProperty()
  @Expose()
  sequenceNumber: number;
}
