export const LogoScrollerParentRoute = 'logo-scroller';

export const LogoScrollerRoutes = {
  create: '',
  update: 'update/:logoScrollerId',
  delete: ':logoScrollerId',
  view_one: ':logoScrollerId',
  view_all: '',
  upload_image: 'image-upload',
  updateDragAndDrop: 'dragandDrop'
};
