import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { LogoScrollerType } from "./logo-scroller-type.enum";
import { LogoScrollerStatus } from "./status.enum";

@Entity({ name:'logo-scroller'})
export class LogoScroller {

    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    imageurl:string;

    @Column()
    navigationurl:string;

    @Column({default:LogoScrollerType.MARKETING})
    type:LogoScrollerType;

    @Column({default:LogoScrollerStatus.INACTIVE})
    status:LogoScrollerStatus;

    @CreateDateColumn({name:'createdDate'})
    createdDate: Date;

    @Column()
    createdBy:number;

    @UpdateDateColumn({name:'updatedDate',nullable:true,default:()=>'null'})
    updatedDate:Date;

    @Column({ nullable:true })
    updatedBy: string;

    @Column()
    sequenceNumber: number;

}

