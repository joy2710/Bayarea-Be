export enum LogoScrollerStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}