export enum LogoScrollerType {
    MARKETING = 'marketing',
    REPUTATION = 'reputation'
}
