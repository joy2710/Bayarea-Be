import { HttpException, HttpStatus,Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateLogoScrollerDto } from './dto/request/create-logo-scroller.dto';
import { UpdateLogoScrollerDto } from './dto/request/update-logo-scroller.dto';
import { LogoScrollerWithMessageResponse } from './dto/response/logoScrollerWithResponce';
import { LogoScroller } from './entities/logo-scroller.entity';

@Injectable()
export class LogoScrollerService {
  constructor(
    @InjectRepository(LogoScroller) private logoScrollerRepository: Repository<LogoScroller>
  ) { }

  async create(request: CreateLogoScrollerDto): Promise<LogoScrollerWithMessageResponse> {
    const logoScroller = await this.logoScrollerRepository.create(request);
    const result = await this.logoScrollerRepository.save(logoScroller);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Logo-scroller`,
        data: result
      }
    }
  }

  async findAll(): Promise<LogoScrollerWithMessageResponse> {
    const result = await this.logoScrollerRepository.find();
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Logo-scroller`,
        data: result
      }
    }
  }

  async findOne(logoScrollerId: number): Promise<LogoScrollerWithMessageResponse> {
    try {
      const result = await this.logoScrollerRepository.findOne(
        {
          where:
            { id: logoScrollerId }
        }
      );
      if (!result) 
        throw new HttpException(`${Messages.Resource.NotFound}: Logo-scroller`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Logo-scroller`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(logoScrollerId: number, request: UpdateLogoScrollerDto): Promise<LogoScrollerWithMessageResponse> {
    const data = await this.logoScrollerRepository.findOne(logoScrollerId)
    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Logo-scroller`,HttpStatus.NOT_FOUND);
    }
    await this.logoScrollerRepository.update(logoScrollerId, request);
    return {
      message: `${Messages.Resource.Updated} : Logo-scroller`,     
    }
  }

  async remove(logoScrollerId: number): Promise<LogoScrollerWithMessageResponse> {
    try {
      const deleteLogoScroller = await this.logoScrollerRepository.delete(logoScrollerId)
      if (deleteLogoScroller.affected > 0) {
        return {
          message:`${Messages.Resource.Deleted} : Logo-scroller`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }

  async dragAndDrop(currSequenceNumber: number, newSequenceNumber: number) {
    var res;
    if(currSequenceNumber > newSequenceNumber) {
      res = await getConnection()         
      .createQueryBuilder()
      .update(LogoScroller)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: currSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(LogoScroller)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :newSequenceNumber AND sequenceNumber < :currSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(LogoScroller)
      .set({ sequenceNumber: newSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    else if(currSequenceNumber < newSequenceNumber){
      res = await getConnection()         
      .createQueryBuilder()
      .update(LogoScroller)
      .set({ sequenceNumber: -1 })
      .where({sequenceNumber: newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(LogoScroller)
      .set({ sequenceNumber: () => "sequenceNumber + 1" })
      .where('sequenceNumber >= :currSequenceNumber AND sequenceNumber < :newSequenceNumber', {currSequenceNumber, newSequenceNumber})
      .execute();
      res = await getConnection()         
      .createQueryBuilder()
      .update(LogoScroller)
      .set({ sequenceNumber: currSequenceNumber })
      .where({sequenceNumber: -1})
      .execute();
    }
    return res;
  }
}
