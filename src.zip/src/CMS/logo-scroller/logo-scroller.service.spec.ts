import { Test, TestingModule } from '@nestjs/testing';
import { LogoScrollerService } from './logo-scroller.service';

describe('LogoScrollerService', () => {
  let service: LogoScrollerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LogoScrollerService],
    }).compile();

    service = module.get<LogoScrollerService>(LogoScrollerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
