import { Module } from '@nestjs/common';
import { MenuPermissionService } from './menu-permission.service';
import { MenuPermissionController } from './menu-permission.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MenuPermission } from './entities/menu-permission.entity';
import { Role } from '../role/entities/role.entity';
import { RoleModule } from '../role/role.module';
import { RoleService } from '../role/role.service';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { Setting } from '../setting/entities/setting.entity';
import { ConfigService } from '@nestjs/config';

@Module({
  imports:[TypeOrmModule.forFeature([MenuPermission,Role,Setting]),RoleModule],
  controllers: [MenuPermissionController],
  providers: [MenuPermissionService,RoleService, MailService,ConfigService],
  exports: [MailService]
})
export class MenuPermissionModule {}
