import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { getConnection, getRepository, Repository } from 'typeorm';

import { Messages } from 'src/common/constants/messages';
import { CreateMenuPermissionDto } from './dto/request/create-menu-permission.dto';
import { MenuPermission } from './entities/menu-permission.entity';
import { MenuPermissionWithMessageResponse } from './dto/response/menuPermissionWithResponce';
import { RoleService } from '../role/role.service';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';

@Injectable()
export class MenuPermissionService {
  constructor(
    @InjectRepository(MenuPermission) private menuPermissionRepository: Repository<MenuPermission>,
    private readonly roleRepository: RoleService,
    private readonly mailsService: MailService
    ) { }

  async createOrUpdatePermission(request: CreateMenuPermissionDto): Promise<MenuPermissionWithMessageResponse> {
    var result: any;
    var message:any;
    await this.roleRepository.findOne(request.roleId);
    
    const menuPermissionExist = await getRepository(MenuPermission)
      .createQueryBuilder()
      .where({ roleId: request.roleId, menuName: request.menuName })
      .getOne();
    if (!menuPermissionExist) {
      const menuPermission = await this.menuPermissionRepository.create(request);
      result = await this.menuPermissionRepository.save(menuPermission);
      message=`${Messages.Resource.Created} : Menu-permission`;
    } else {     
      result = await getConnection()  
        .createQueryBuilder()
        .update(MenuPermission)
        .set({ isAccess: request.isAccess })
        .where({ roleId: request.roleId, menuName: request.menuName })
        .execute();
        message=`${Messages.Resource.Updated} : Menu-permission`;
    }
    
     
      return {
        message: message,
        data: result
      }
 

  }

  async findMenuPermissionByRoleId(roleId: number): Promise<MenuPermissionWithMessageResponse> {
    try {
      const result = await this.menuPermissionRepository.find({
        where:
          { roleId: roleId }
      });

      if (!result)
        throw new HttpException(`Role-id not exist`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Menu-permission by role-id`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }
}
