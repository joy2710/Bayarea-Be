import { Controller, Get, Post, Body, Param, UseGuards, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';

import { MenuPermissionService } from './menu-permission.service';
import { CreateMenuPermissionDto } from './dto/request/create-menu-permission.dto';
import { MenuPermissionParentRoute, MenuPermissionRoutes } from './menu-permission.http.routes';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Menu-permission')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path: MenuPermissionParentRoute })
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)

export class MenuPermissionController {
  constructor(private readonly menuPermissionService: MenuPermissionService) {}

  @Post(MenuPermissionRoutes.create)
  createMenuPermission(@Body() body: CreateMenuPermissionDto) {
    return this.menuPermissionService.createOrUpdatePermission(body);
  }

  // GET-BY-ROLE-ID
  @Get(MenuPermissionRoutes.get_by_role)
  findMenuPermissionByRoleId(@Param('roleId') id: string) {
    return this.menuPermissionService.findMenuPermissionByRoleId(+id);
  }
}
