export const MenuPermissionParentRoute = 'menu-permission';

export const MenuPermissionRoutes = {
  create: '',
  get_by_role:'role-type/:roleId'
};
