import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { MenuPermissionResponse } from './menu-permission-response';

export class MenuPermissionWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: MenuPermissionResponse | MenuPermissionResponse[];

  constructor(message: string, data: MenuPermissionResponse | MenuPermissionResponse[]) {
    this.data = data;
    this.message = message;
  }
}
