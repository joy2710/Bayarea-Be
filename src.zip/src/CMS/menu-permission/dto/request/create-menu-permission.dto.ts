import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsOptional } from "class-validator";

export class CreateMenuPermissionDto {

    @ApiProperty()
    roleId: number;

    @ApiProperty()
    menuName: string;

    @ApiProperty()
    @IsOptional()
    @IsBoolean()
    isAccess: boolean;

}
