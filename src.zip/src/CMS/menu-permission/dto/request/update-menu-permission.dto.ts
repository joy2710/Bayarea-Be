import { CreateMenuPermissionDto } from './create-menu-permission.dto';

export class UpdateMenuPermissionDto extends CreateMenuPermissionDto {}
