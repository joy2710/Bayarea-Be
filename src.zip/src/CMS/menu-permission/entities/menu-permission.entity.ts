import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"

@Entity({ name: 'menu-permission' })
export class MenuPermission {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    roleId: number;

    @Column()
    menuName: string;

    @Column('bool')
    isAccess: boolean;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;
}
