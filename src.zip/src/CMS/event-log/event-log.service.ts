import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateEventLogDto } from './dto/request/create-event-log.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { EventLog } from './entities/event-log.entity';
import { Repository } from 'typeorm';
import { Messages } from 'src/common/constants/messages';
import { EventLogWithMessageResponse } from './dto/response/eventLogWithResponse';


@Injectable()
export class EventLogService {
  constructor(
    @InjectRepository(EventLog) private eventLogRepository: Repository<EventLog>,

  ) { }
  async create(createEventLogDto: CreateEventLogDto): Promise<EventLogWithMessageResponse> {
    const eventLog = await this.eventLogRepository.create(createEventLogDto);
    const result = await this.eventLogRepository.save(eventLog)
      return {
        message: `${Messages.Resource.Created} : Event Log`,
        data: result
    }

  }

  async findAll(): Promise<EventLogWithMessageResponse> {
    const result = await this.eventLogRepository.find()
    if (result) {
      return {
        message: `${Messages.Resource.Found}: Event Log`,
        data: result
      }
    }

  }

  async findOne(eventLogId: number): Promise<EventLogWithMessageResponse> {
    try {
      const result = await this.eventLogRepository.findOne(
        {
          where:
            { id: eventLogId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}:Event Log`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Event Log`,
        data: result
      }
    } catch (error) {
      throw error;
    }

  }

  //Code clean 
  // async update(eventLogId: number, updateRoleDto: UpdateEventLogDto): Promise<EventLogWithMessageResponse> {
  //   const data = await this.eventLogRepository.findOne(eventLogId);

  //   if (!data) {
  //     throw new HttpException(`Event Log-id not exist`, HttpStatus.NOT_FOUND);
  //   }
  //   await this.eventLogRepository.update(eventLogId, updateRoleDto)
  //   return {
  //     message: `${Messages.Resource.Updated} : Event Log`,
  //   }
  // }

  // async remove(eventLogId: number): Promise<EventLogWithMessageResponse> {
  //   try {
  //     const deleteEventLog = await this.eventLogRepository.delete(eventLogId);
  //     if (deleteEventLog.affected > 0) {
  //       return {
  //         message: `${Messages.Resource.Deleted}: Event Log`
  //       }
  //     }
  //   } catch (error) {
  //     throw new InternalServerErrorException(error.message);
  //   }

  // }
}
