import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class CreateEventLogDto {
  
    @ApiProperty()
    @IsNotEmpty()
    moduleName:string;
  
    @ApiProperty()
    @IsNotEmpty()
    eventName:string;
  
    @ApiProperty()
    @IsNotEmpty()
    eventUserId:string;
  
    @ApiProperty()
    @IsNotEmpty()
    eventUserName:string;
  
    @ApiProperty()
    @IsNotEmpty()
    eventDateTime?: Date;
  
    @ApiProperty()
    @IsNotEmpty()
    oldValue:string;
  
    @ApiProperty()
    @IsNotEmpty()
    newValue:string;

    @ApiProperty()
    @IsNotEmpty()
    eventPrimeryKey:number;

    @ApiProperty()
    @IsNotEmpty()
    baseCaseNumber:string;
}
