import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { TransformDateToEpoch } from "src/common/helpers/decorators/transformDateToEpoch";


export class EventLogResponse {

  @ApiProperty()
  @Expose()
  id:number;

  @ApiProperty()
  @Expose()
  moduleName?:string;

  @ApiProperty()
  @Expose()
  eventName?:string;

  @ApiProperty()
  @Expose()
  eventUserId:string;

  @ApiProperty()
  @Expose()
  eventUserName?:string;

  @ApiProperty()
  @Expose()
  eventDateTime?: Date;

  @ApiProperty()
  @Expose()
  oldValue?:string;

  @ApiProperty()
  @Expose()
  newValue?:string;

  @ApiPropertyOptional()
  @TransformDateToEpoch()
  @Expose()
  createdDate: Date;

  @ApiProperty()
  @Expose()
  createdBy: string;

  @ApiPropertyOptional()
  @TransformDateToEpoch()
  @Expose()
  updatedDate: Date;

  @ApiProperty()
  @Expose()
  updatedBy: string;

  @ApiProperty()
  @Expose()
  eventPrimeryKey:number;

  @ApiProperty()
  @Expose()
  baseCaseNumber:string;

}
