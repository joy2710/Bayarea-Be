export enum CisColumnAction {
    ADD_CIS_COLUMN = 'cis column added ',
    UPDATE_CIS_COLUMN = 'cis column updated',
    DELETE_CIS_COLUMN = 'cis column deleted ',
}

export enum ClientColumnAction {
    ADD_CLIENT_COLUMN = 'client column added ',
    UPDATE_CLIENT_COLUMN = 'client column updated',
    DELETE_CLIENT_COLUMN = 'client column deleted',
}

export enum AdminAction {
    ADD_ADMIN_COLUMN = 'admin column added ',
    UPDATE_ADMIN_COLUMN = 'admin column updated',
    DELETE_ADMIN_COLUMN = 'admin column deleted',
}

export enum TaskInstructionAction {
    ADD_TASK_INSTRUCTION = 'task instruction added',
    UPDATE_TASK_INSTRUCTION = 'task instruction updated',
    DELETE_TASK_INSTRUCTION = 'task instruction deleted',
}

export enum DocTypeDropdownAction {
    ADD_DOC_TYPE_DROPDOWN = 'Doc Type Dropdown added',
    UPDATE_DOC_TYPE_DROPDOWN = 'Doc Type Dropdown updated',
    DELETE_DOC_TYPE_DROPDOWN = 'Doc Type Dropdown deleted',
}

export enum FolderAction {
    ADD_FOLDER = 'Folder added',
    UPDATE_FOLDER = 'Folder updated',
    DELETE_FOLDER = 'Folder deleted',
}

export enum RoleAction {
    ADD_ROLE = 'Role added',
    UPDATE_ROLE = 'Role updated',
    DELETE_ROLE = 'Role deleted',
}

export enum EmployeeAction {
    ADD_EMPLOYEE = 'Employee added',
    UPDATE_EMPLOYEE = 'Employee updated',
    DELETE_EMPLOYEE = 'Employee deleted',
}
export enum CaseFiles {
    ADD_CASE_FILE = 'case file added',
    UPDATE_CASE_FILE = 'case file updated',
    DELETE_CASE_FILE = 'case file deleted',
    CASE_FILE_VALIDATE = 'Case File Validated',
    CASE_FILE_APPROVED = 'Client Validated Docs'
}

export enum ClientAction {
 ADD_CLIENT='client added',
 UPDATE_CLIENT = 'client updated',
 DELETE_CLIENT = 'client deleted',
 CHANGE_PASSWORD = 'Change  Password'
} 

export enum ServiceAgreementFiles {
    ADD_SERVICE_AGREEMENT = 'Service Agreement Uploaded',
    ADD_ASSIGNEE_SERVICE_AGEEMENT= 'Assignee Service Agreement Uploaded',
    APPROVE_SERVICE_AGREEMENT= 'Service Agreement Approved',
    APPROVE_ASSIGNEE_SERVICE_AGREEMENT= 'Assignee Service Agreement Approved',
}

export enum ServiceIntakeForms {
    ADD_SERVICE_INTAKE_FORMS = 'Service Intake form Save',
    SUBMIT_SERVICE_INTAKE_FORMS = 'Service Intake Form Submited',
    SERVICE_INTAKE_FORM_APPROVE =  'Service Intake Form Approved'
}