export enum ModuleName {
CIS_COLUMN='cis column',
ADMIN_COLUMN='admin column',
CLIENT_COLUMN='client column',
TASK_INSTRUCTION='task instruction',
DOC_TYPE_DROPDOWN='doc type dropdown',
FOLDER='folder',
ROLE='role',
EMPLOYEE='employee',
CASE_FILE='case file',
CLIENT='Client',
SERVICE_AGREEMENT ='Service agreement',
ASSIGNEE_SERVICE_AGREEMENT = 'Assignee service agreement',
SERVICE_INTAKE_FORMS = 'Service intake forms',
PAYMENT_STATUS_CLIENT = 'Payment Status'
}