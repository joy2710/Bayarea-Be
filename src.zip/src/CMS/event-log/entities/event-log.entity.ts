import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity ({name: 'event-log'})
export class EventLog {

    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    moduleName:string;

    @Column()
    eventName:string;

    @Column()
    eventUserId:string;

    @Column()
    eventUserName:string;

    @Column()
    eventDateTime: Date;

    @Column({type: 'longtext'})
    oldValue:string;

    @Column({type: 'longtext'})
    newValue:string;

    @CreateDateColumn()
    createdDate: Date;

    @Column()
    createdBy: string;

    @UpdateDateColumn()
    updatedDate: Date;

    @Column()
    updatedBy: string;

    @Column()
    eventPrimeryKey:number;

    @Column()
    baseCaseNumber:string
}
