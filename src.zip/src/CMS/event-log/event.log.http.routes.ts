export const EventLogRoute = 'event-Log';

export const EventLogRoutes = {
  create: '',
  //Code clean 
  // update: 'update/:eventLogId',
  // delete: ':eventLogId',
  view_one: ':eventLogId',
  view_all: '',
};