import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { EventLogService } from './event-log.service';
import { CreateEventLogDto } from './dto/request/create-event-log.dto';
import { UpdateEventLogDto } from './dto/request/update-event-log.dto';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { EventLogRoute, EventLogRoutes } from './event.log.http.routes';

@ApiTags('event-log')
@Controller({ path:EventLogRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('event-log')
export class EventLogController {
  constructor(private readonly eventLogService: EventLogService) {}

  @Post(EventLogRoutes.create)
  create(@Body() createEventLogDto: CreateEventLogDto) {
    return this.eventLogService.create(createEventLogDto);
  }

  @Get(EventLogRoutes.view_all)
  findAll() {
    return this.eventLogService.findAll();
  }

  @Get(EventLogRoutes.view_one)
  findOne(@Param('eventLogId') id: string) {
    return this.eventLogService.findOne(+id);
  }

  //Code clean 
  // @Patch(EventLogRoutes.update)
  // update(@Param('eventLogId') id: string, @Body() updateEventLogDto: UpdateEventLogDto) {
  //   return this.eventLogService.update(+id, updateEventLogDto);
  // }

  // @Delete(EventLogRoutes.delete)
  // remove(@Param('eventLogId') id: string) {
  //   return this.eventLogService.remove(+id);
  // }
}
