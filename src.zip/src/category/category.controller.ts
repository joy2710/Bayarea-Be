import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from 'src/auth/constants';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { CategoryParentRoute, CategoryRoutes } from './category.http.routes';
import { CategoryService } from './category.service';
import { CreateCategoryDto } from './dto/request/create-category.dto';
import { UpdateCategoryDto } from './dto/request/update-category.dto';

/* ####################################### SWAGGER DOCUMENTATION : Start ####################################### */
@ApiTags('Category')
/* ######################################## SWAGGER DOCUMENTATION : End ######################################## */

@Controller({ path:CategoryParentRoute})
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
// @Public()
export class CategoryController {
  constructor(private readonly categoryService: CategoryService) {}

  @Post(CategoryRoutes.create)
  create(@Body() createCategoryDto: CreateCategoryDto) {
    return this.categoryService.create(createCategoryDto);
  }

  @Public()
  @Get(CategoryRoutes.view_all)
  findAll() {
    return this.categoryService.findAll();
  }

  @Public()
  @Get(CategoryRoutes.view_one)
  findOne(@Param('categoryId') id: string) {
    return this.categoryService.findOne(+id);
  }

  @Post(CategoryRoutes.update)
  update(@Param('categoryId') id: string, @Body() updateCategoryDto: UpdateCategoryDto) {
    return this.categoryService.update(+id, updateCategoryDto);
  }

  @Delete(CategoryRoutes.delete)
  remove(@Param('categoryId') id: string) {
    return this.categoryService.remove(+id);
  }
}
