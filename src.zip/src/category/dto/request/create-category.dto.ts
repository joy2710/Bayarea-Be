import { ApiProperty } from "@nestjs/swagger"
import { IsEnum, IsNotEmpty } from "class-validator"
import { CategoryStatus } from "src/category/entities/category.enum";

export class CreateCategoryDto {
    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty({ default: CategoryStatus.INACTIVE })
    @IsNotEmpty()
    @IsEnum(CategoryStatus)
    status: CategoryStatus;

}
