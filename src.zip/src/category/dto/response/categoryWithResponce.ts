import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CategoryResponse } from './category-response';

export class CategoryWithMessageResponse {
  @ApiProperty({
    title: 'Message',
    description: 'Specifies a response message',
    example: 'Process Successful',
  })

  @Expose()
  message: string;

  @ApiProperty({
    title: 'Data',
    description: 'Specifies response data',
  })

  @Expose()
  data?: CategoryResponse | CategoryResponse[];

  constructor(message: string, data: CategoryResponse | CategoryResponse[]) {
    this.data = data;
    this.message = message;
  }
}
