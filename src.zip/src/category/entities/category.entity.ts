import { BlogCategory } from "src/CMS/blog-category/entities/blog-category.entity";
import { Blog } from "src/CMS/blog/entities/blog.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm"
import { CategoryStatus } from "./category.enum";

@Entity({ name: 'category' })
export class Category {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column({ default: CategoryStatus.INACTIVE })
    status: CategoryStatus;

    @CreateDateColumn({ name: 'createdDate' })
    createdDate: Date;

    @Column()
    createdBy: number;

    @UpdateDateColumn({ name: 'updatedDate', nullable: true, default: () => 'null' })
    updatedDate: Date;

    @Column({ nullable: true })
    updatedBy: string;

    @OneToMany(() => BlogCategory, (blogCategory: BlogCategory) => blogCategory.category)
    blogCategory: BlogCategory;

    // @ManyToOne(() => Blog, (blog: Blog) => blog.category,
    // {
    //     eager: false,
    //     onDelete: 'CASCADE'
    // })
    // blog: Blog[];



}