export enum CategoryStatus {
    ACTIVE = 'active',
    INACTIVE = 'inActive',
}