import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Messages } from 'src/common/constants/messages';
import { Repository } from 'typeorm';
import { CreateCategoryDto } from './dto/request/create-category.dto';
import { UpdateCategoryDto } from './dto/request/update-category.dto';
import { CategoryWithMessageResponse } from './dto/response/categoryWithResponce';
import { Category } from './entities/category.entity';

@Injectable()
export class CategoryService {
  constructor(
    @InjectRepository(Category) private categoryRepository: Repository<Category>
  ) {}
  async create(createCategoryDto: CreateCategoryDto): Promise<CategoryWithMessageResponse> {
    const category = await this.categoryRepository.create(createCategoryDto);
    const result = await this.categoryRepository.save(category);
    if (result) {
      return {
        message: `${Messages.Resource.Created} : Category`,
        data: result
      }
    }
  }

  async findAll(): Promise<CategoryWithMessageResponse> {
    const result = await this.categoryRepository.find()
    if (result) {
      return {
        message: `${Messages.Resource.Found} : Category`,
        data: result
      }
    }
  }

  async findOne(categoryId: number): Promise<CategoryWithMessageResponse> {
    try {
      const result = await this.categoryRepository.findOne(
        {
          where:
            { id: categoryId }
        }
      );
      if (!result)
        throw new HttpException(`${Messages.Resource.NotFound}: Category`, HttpStatus.NOT_FOUND);
      return {
        message: `${Messages.Resource.Found} : Category`,
        data: result
      }
    } catch (error) {
      throw error;
    }
  }

  async update(categoryId: number, updateCategoryDto: UpdateCategoryDto): Promise<CategoryWithMessageResponse> {
    const data = await this.categoryRepository.findOne(categoryId);

    if (!data) {
      throw new HttpException(`${Messages.Resource.NotFound} : Category`, HttpStatus.NOT_FOUND);
    }
    await this.categoryRepository.update(categoryId, updateCategoryDto)
    return {
      message: `${Messages.Resource.Updated} : Category`,
    }
  }

  async remove(categoryId: number): Promise<CategoryWithMessageResponse> {
    try {
      const deleteCategory = await this.categoryRepository.delete(categoryId);
      if (deleteCategory.affected > 0) {
        return {
          message: `${Messages.Resource.Deleted} : Category`
        }
      }
    } catch (error) {
      throw new InternalServerErrorException(error.message);
    }
  }
}
