export const CategoryParentRoute = 'category';

export const CategoryRoutes = {
  create: '',
  update: 'update/:categoryId',
  delete: ':categoryId',
  view_one: ':categoryId',
  view_all: '',
};