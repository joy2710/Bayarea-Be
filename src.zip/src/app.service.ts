import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, getConnection } from 'typeorm';
import { Notification } from 'src/CMS/notification/entities/notification.entity';
import { OrderStatus } from 'src/CMS/order/entities/status.enum';
import { NotificationStatus } from 'src/CMS/notification/entities/status.enum';
import { IMail } from 'src/common/model/interface/IMail';
import { Order } from 'src/CMS/order/entities/order.entity';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { OrderDetailService } from './CMS/order-detail/order-detail.service';
import { ConfigService } from '@nestjs/config';
import { LeadType } from './CMS/order/entities/lead-type.enum';
import { ClientService } from './CMS/client/client.service';
import { EmailTemplateService } from './CMS/email-template/email-template.service';
import { SettingService } from './CMS/setting/setting.service';
var btoa = require('btoa');
const moment = require('moment');


@Injectable()
export class AppService {

  constructor(
    @InjectRepository(Notification) private notificationRepository: Repository<Notification>,
    @InjectRepository(Order) private orderRepository: Repository<Order>,
    private readonly mailsService: MailService,
    private orderDetailService: OrderDetailService,
    private configService: ConfigService,
    private clientService: ClientService,
    private emailTemplateService: EmailTemplateService,
    private settingService: SettingService,  
  ) { }

  @Cron('30 1 * * *')
  async handleCron() {
    const notification = await this.notificationRepository.createQueryBuilder('notification')
    .where({ mailSentStatus: NotificationStatus.NOTESENT})
    .andWhere(`notification.mailSentTime <= '${moment(new Date()).format('YYYY-MM-DD')}'`)
    .getMany();
    const uniqueNotifications = Array.from(new Map(notification.map(item => [item.orderId, item])).values());
    const order = await this.orderRepository.find();
    if(uniqueNotifications.length > 0) {
      for(let x of uniqueNotifications) {
        for(let y of order) {
          if(x.orderId == y.id && y.status== OrderStatus.PAYMENT_PENDING && y.isDeleted !== true && y.isArchive !== '0' && y.isTemporaryCart !== true ) {
              await getConnection().
              createQueryBuilder().
              update(Notification)
              .set({mailSentTime:moment(x.mailSentTime)
                .add(1, 'days')
                .format('YYYY-MM-DD')})
              .where({orderId: x.orderId})
              .execute();
              const encryptOrderId = btoa(y.id);
              let frontUrl = this.configService.get<string>('FRONT_URL');
              const url = `${frontUrl}/payment/${encryptOrderId}`;
              const emailTemplateData = await this.emailTemplateService.findOne(3) 
              const footerUrl = await this.settingService.findAll();

              const convertedData = emailTemplateData.data['templateContent']
              .replace(/{{name}}/g, y?.firstName || '')
              .replace(/{{url}}/g, url || '')
              .replace(/{{privacyPolicyUrl}}/g, footerUrl.data[0]['privacyPolicyUrl'] || '')
              .replace(/{{legalNoticeUrl}}/g, footerUrl.data[0]['legalNoticeUrl'] || '')
              .replace(/{{termsOfServiceUrl}}/g, footerUrl.data[0]['termsOfServiceUrl'] || '')

              var mail: IMail = {
                to: y.email,
                subject: `Reminder: Register Payment for your legal services shopping cart order #:${y.administrativeCaseNumber?? ''} ${y.firstName + ' ' + y.lastName}  `,
                cc: '',
                html:convertedData
              };
              await this.mailsService.sendHtmlMail(mail);
              
              //OLD WAY
              // var mail: IMail = {
              //   to: y.email,
              //   url: url,
              //   subject: `Reminder: Register Payment for your legal services shopping cart order #:${y.administrativeCaseNumber?? ''} ${y.firstName + ' ' + y.lastName}  `,
              //   data: y,
              //   cc: '',
              // };
              // await this.mailsService.sendingMail(mail, TemplateTypes. payment_reminder);

          }  
        }
        
      } 
    }
    if(notification.length > 0) {
      const filteredData =  notification.filter((a:any) => a.isEnable === true)
      const newOrderData = order.filter((k:any)=> k.isTemporaryCart === true && k.leadType !== LeadType.CREATED_BY_EMPLOYEE)
      for(let x of newOrderData) {
        for(let y of filteredData) {
           if(y.orderId == x.id  ) {
            await getConnection().
            createQueryBuilder().
            update(Notification)
            .set({
              isEnable: false
            })
            .where({orderId: y.orderId})
            .execute();
            const encryptOrderId = btoa(y.id);
            const url = `${this.configService.get<string>('FRONT_URL')}/checkout/${encryptOrderId}`;
            const fronturl= `${this.configService.get<string>('FRONT_URL')}/service`
           const orderDetails= await this.orderDetailService.getOrderDetailsByOrderId(y.id);
           const extractedData =orderDetails.data.map(item => ({
            serviceId: item.serviceId,
            productName: item.product['productName'],
            productImage: item.product['productImage']
          }));
            var mail: IMail = {
              to: x.email,
              url: url,
              subject:
                `Link to Complete your Order for your recent Patent legal services`,
              data: extractedData,
              fronturl:fronturl,
              cc: '',
            };
            await this.mailsService.sendingMail(mail, TemplateTypes.temporary_cart);
          }
        }
        
      } 
    }
   await getConnection()
    .createQueryBuilder()
    .update(Notification)
    .set({ mailSentStatus: NotificationStatus.CANCELLED })
    // .where("DATEDIFF(`mailSentTime`, `createdDate`) >= 7")
    .where("DATEDIFF(CURDATE(), `createdDate`) > 7")
    .andWhere("`mailSentStatus` <> :status", { status: NotificationStatus.CANCELLED })
    .execute();
  }

  // This cron will run every hour for all orders that were created 3 hours ago and have not completed the checkout page.
  @Cron('0 * * * *')
  async temporaryOrderCron() {
    const notification = await this.notificationRepository
    .createQueryBuilder('notification')
    .where('notification.mailSentStatus = :status', { status: NotificationStatus.NOTESENT })
    .andWhere('notification.isEnable = :isEnable', { isEnable:true })
    .andWhere('DATE(notification.createdDate) = :createdDate', { createdDate: moment().format('YYYY-MM-DD') })
    .andWhere('notification.mailSentTime <= :currentTime', { currentTime: moment().format('YYYY-MM-DD HH:mm:ss') })
    .getMany();
    for(let a of notification){
      const orderData = await this.orderRepository.findOne(a.orderId);
      if (orderData.isTemporaryCart === true && orderData.leadType !== LeadType.CREATED_BY_EMPLOYEE){
        await getConnection().
        createQueryBuilder().
        update(Notification)
        .set({isEnable: false})
        .where({id: a.id})
        .execute();
        const encryptOrderId = btoa(a.orderId);
        const url = `${this.configService.get<string>('FRONT_URL')}/checkout/${encryptOrderId}`;
        const fronturl= `${this.configService.get<string>('FRONT_URL')}/service`
       const orderDetails= await this.orderDetailService.getOrderDetailsByOrderId(a.orderId);
       const extractedData =orderDetails.data.map(item => ({
        serviceId: item.serviceId,
        productName: item.product['productName'],
        productImage: item.product['productImage']
      }));
        var mail: IMail = {
          to: orderData.email,
          url: url,
          subject:
            `Link to Complete your Order for your recent Patent legal services`,
          data: extractedData,
          fronturl:fronturl,
          cc: '',
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.temporary_cart);
      }
    }

  
  }

  // This cron will run every day on 2:00 am o clock for client task payment reminder mail
  @Cron('0 2 * * *')
  async clientTasPaymentkReminder() {
    try {
      // Calculate specific dates
      const today = new Date();
      const intervals = [2, 6, 10, 14, 18, 22];
      const specificDates = intervals.map(daysBefore => {
        const targetDate = new Date(today);
        targetDate.setDate(today.getDate() - daysBefore);
        return targetDate.toISOString().split('T')[0];
      });
      // Single query to fetch all orders matching the criteria
      const orders = await this.orderRepository
        .createQueryBuilder('order')
        .leftJoinAndSelect('order.orderPayment', 'orderPayment')
        .innerJoin('client', 'client', 'order.clientId = client.id') 
        .where('client.isPaymentReminder = :isPaymentReminder', { isPaymentReminder: true }) 
        .andWhere('order.isDeleted = :isDeleted', { isDeleted: false })
        .andWhere('order.isTemporaryCart = :isTemporaryCart', { isTemporaryCart: false })
        .andWhere('DATE(order.createdDate) IN (:...specificDates)', { specificDates }) 
        .andWhere('orderPayment.orderId IS NULL') 
        .getMany();
      const formattedArray = orders.map(item => {
        const createdDate = item.createdDate
          ? moment(new Date(item.createdDate)).format('YYYY-MM-DD')
          : null; 
        return { ...item, createdDate: createdDate };
      });
        const groupedOrders:any = formattedArray.reduce((acc, order) => {
          if (!acc[order.clientId]) {
            acc[order.clientId] = [];
          }
          acc[order.clientId].push(order);
        
          return acc;
        }, {} as Record<number, typeof orders>);

      for (const [clientId, orders] of Object.entries(groupedOrders)) {
        const client = await this.clientService.findOne(Number(clientId))
        let frontUrl = this.configService.get<string>('FRONT_URL');
        const url = `${frontUrl}/client/order`;
        const clientName = client.data['firstName'] + 
        (client.data['middleName'] ? ' ' + client.data['middleName'] : '') + 
        ' ' + client.data['lastName'];
        var mail: IMail = {
          to: client.data['email'],
          subject: `Reminder: Register Payment for your legal services shopping cart order :  `,
          url: url,
          data: clientName,
          orderdata: orders,
          cc: '',
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.client_payment_task_reminder);
      }
    } catch (error) {
      console.error('Error in clientTaskReminder:', error);
    }
  }
  
  // this cron will run at 2:15 am daily for the client task admin intake reminder
  @Cron('15 2 * * *')
  async clientTaskIntakeReminder() {
    try {
      const today = new Date();
      const intervals = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28];
      const specificDates = intervals.map(daysBefore => {
        const targetDate = new Date(today);
        targetDate.setDate(today.getDate() - daysBefore);
        return targetDate.toISOString().split('T')[0];
      });
      const orders = await this.orderRepository
        .createQueryBuilder('order')
        .innerJoin('client', 'client', 'order.clientId = client.id') 
        .where('client.isAdminIntakeReminder = :isAdminIntakeReminder', { isAdminIntakeReminder: true }) 
        .andWhere('order.isDeleted = :isDeleted', { isDeleted: false })
        .andWhere('order.isTemporaryCart = :isTemporaryCart', { isTemporaryCart: false })
        .andWhere('DATE(order.createdDate) IN (:...specificDates)', { specificDates })
        .andWhere('order.status = :status', {status: OrderStatus.APPLICATION_PENDING}) 
        .getMany();
      const formattedArray = orders.map(item => {
        const createdDate = item.createdDate
          ? moment(new Date(item.createdDate)).format('YYYY-MM-DD')
          : null; 
        return { ...item, createdDate: createdDate };
      });
        const groupedOrders:any = formattedArray.reduce((acc, order) => {
          
          if (!acc[order.clientId]) {
            acc[order.clientId] = [];
          }
          acc[order.clientId].push(order);
        
          return acc;
        }, {} as Record<number, typeof orders>);  
      for (const [clientId, orders] of Object.entries(groupedOrders)) {
        const client = await this.clientService.findOne(Number(clientId))
        let frontUrl = this.configService.get<string>('FRONT_URL');
        const url = `${frontUrl}/client/order`;
        const clientName = client.data['firstName'] + 
        (client.data['middleName'] ? ' ' + client.data['middleName'] : '') + 
        ' ' + client.data['lastName'];
        var mail: IMail = {
          to: client.data['email'],
          subject: `Reminder : complete the admin intake form for order  ... `,
          url: url,
          data: clientName,
          orderdata: orders,
          cc: '',
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.client_admin_intake_task_reminder);
      }
    } catch (error) {
      console.error('Error in clientTaskReminder:', error);
    }
  }
  
// this cron will run every day at 2:30 am for the client service agreement reminder
  @Cron('30 2 * * *')
  async clientTaskServiceAgreementReminder() {
    try {
      const today = new Date();
      const intervals = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28];
      const specificDates = intervals.map(daysBefore => {
        const targetDate = new Date(today);
        targetDate.setDate(today.getDate() - daysBefore);
        return targetDate.toISOString().split('T')[0];
      });
      const assigneeAgreementPendingOrder = await this.orderRepository
      .createQueryBuilder('order')
      .leftJoinAndSelect('order.orderAssigneeDocument', 'orderAssigneeDocument')
      .innerJoin('client', 'client', 'order.clientId = client.id') 
      .where('client.isAgreementReminder = :isAgreementReminder', { isAgreementReminder: true }) 
      .andWhere('order.isDeleted = :isDeleted', { isDeleted: false })
      .andWhere('order.genAssigneeFullLegalname IS NOT NULL')
      .andWhere('order.isTemporaryCart = :isTemporaryCart', { isTemporaryCart: false })
      .andWhere('DATE(order.createdDate) IN (:...specificDates)', { specificDates }) 
      .andWhere('orderAssigneeDocument.orderId IS NULL') 
      .getMany();

      const inventorAgreementPendingOrder = await this.orderRepository
      .createQueryBuilder('order')
      .leftJoin('order.orderInventor', 'orderInventor')
      .leftJoin('orderInventor.orderInventorDocument', 'orderInventorDocument')
      .innerJoin('client', 'client', 'order.clientId = client.id') 
      .where('client.isAgreementReminder = :isAgreementReminder', { isAgreementReminder: true }) 
      .andWhere('order.isDeleted = :isDeleted', { isDeleted: false }) 
      .andWhere('order.isTemporaryCart = :isTemporaryCart', { isTemporaryCart: false }) 
      .andWhere('DATE(order.createdDate) IN (:...specificDates)', { specificDates }) 
      .andWhere('orderInventor.id IS NOT NULL') // Ensure the order has inventors
      .andWhere('orderInventorDocument.id IS NULL') // Ensure there are no documents
      .getMany();
    
    const combinedOrders = [...assigneeAgreementPendingOrder, ...inventorAgreementPendingOrder];
    const formattedArray = combinedOrders.map(item => {
        const createdDate = item.createdDate
          ? moment(new Date(item.createdDate)).format('YYYY-MM-DD')
          : null; 
        return { ...item, createdDate: createdDate };
      });
        const groupedOrders:any = formattedArray.reduce((acc, order) => {
          if (!acc[order.clientId]) {
            acc[order.clientId] = [];
          }
          acc[order.clientId].push(order);
        
          return acc;
        }, {} as Record<number, typeof combinedOrders>); 
      for (const [clientId, orders] of Object.entries(groupedOrders)) {
        const client = await this.clientService.findOne(Number(clientId))
        let frontUrl = this.configService.get<string>('FRONT_URL');
        const url = `${frontUrl}/client/service-agreement`;
        const clientName = client.data['firstName'] + 
        (client.data['middleName'] ? ' ' + client.data['middleName'] : '') + 
        ' ' + client.data['lastName'];
        var mail: IMail = {
          to: client.data['email'],
          subject: `Reminder : upload the service agreement for order ... `,
          url: url,
          data: clientName,
          orderdata: orders,
          cc: '',
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.client_agreement_task_reminder);
      }
    } catch (error) {
      console.error('Error in clientTaskReminder:', error);
    }
  }
  
  // cron will run every day at 2:45 am to send reminder for service intake form
  @Cron('45 2 * * *')
  async clientTaskServiceIntakeFormReminder() {
    try {
      const today = new Date();
      const intervals = [2, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50, 54];
      const specificDates = intervals.map(daysBefore => {
        const targetDate = new Date(today);
        targetDate.setDate(today.getDate() - daysBefore);
        return targetDate.toISOString().split('T')[0];
      });
      const serviceIntakeFormPendingOrder = await this.orderRepository
      .createQueryBuilder('order')
      .leftJoin('order.orderDetail', 'orderDetail')
      .leftJoin('orderDetail.productOrderDetailForm', 'productOrderDetailForm')
      .innerJoin('client', 'client', 'order.clientId = client.id') 
      .where('client.isServiceFormReminder = :isServiceFormReminder', { isServiceFormReminder: true }) 
      .andWhere('order.isDeleted = :isDeleted', { isDeleted: false }) 
      .andWhere('order.isTemporaryCart = :isTemporaryCart', { isTemporaryCart: false }) 
      .andWhere('DATE(order.createdDate) IN (:...specificDates)', { specificDates }) 
      .andWhere('orderDetail.id IS NOT NULL') 
      .andWhere('productOrderDetailForm.isApprove =:isApprove',{isApprove: 13} ) 
      .getMany();

      const formattedArray = serviceIntakeFormPendingOrder.map(item => {
        const createdDate = item.createdDate
          ? moment(new Date(item.createdDate)).format('YYYY-MM-DD')
          : null; 
        return { ...item, createdDate: createdDate };
      });
        const groupedOrders:any = formattedArray.reduce((acc, order) => {
          if (!acc[order.clientId]) {
            acc[order.clientId] = [];
          }
          acc[order.clientId].push(order);
        
          return acc;
        }, {} as Record<number, typeof serviceIntakeFormPendingOrder>); 
      for (const [clientId, orders] of Object.entries(groupedOrders)) {
        const client = await this.clientService.findOne(Number(clientId))
        let frontUrl = this.configService.get<string>('FRONT_URL');
        const url = `${frontUrl}/client/case-list`;
        const clientName = client.data['firstName'] + 
        (client.data['middleName'] ? ' ' + client.data['middleName'] : '') + 
        ' ' + client.data['lastName'];
        var mail: IMail = {
          to: client.data['email'],
          subject: `Reminder : complete service intake form for order ... `,
          url: url,
          data: clientName,
          orderdata: orders,
          cc: '',
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.client_service_intake_fom_reminder);
      }
    } catch (error) {
      console.error('Error in clientTaskReminder:', error);
    }
  }
  
  // cron will run every day at 3 am to send reminder for the validate doc
  @Cron('0 3 * * *')
  async clientTaskValidateDocumentReminder() {
    try {
      const today = new Date();
      const intervals = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49, 52, 55];
      const specificDates = intervals.map(daysBefore => {
        const targetDate = new Date(today);
        targetDate.setDate(today.getDate() - daysBefore);
        return targetDate.toISOString().split('T')[0];
      });
      const nonValidatedDocumentOrder = await this.orderRepository
      .createQueryBuilder('order')
      .leftJoin('order.orderDetail', 'orderDetail')
      .leftJoin('orderDetail.case', 'case')
      .leftJoin('case.caseFile', 'caseFile')
      .innerJoin('client', 'client', 'order.clientId = client.id') 
      .where('client.isServiceFormReminder = :isServiceFormReminder', { isServiceFormReminder: true }) 
      .andWhere('order.isDeleted = :isDeleted', { isDeleted: false }) 
      .andWhere('order.isTemporaryCart = :isTemporaryCart', { isTemporaryCart: false })
      .andWhere('DATE(order.createdDate) IN (:...specificDates)', { specificDates }) 
      .andWhere('orderDetail.id IS NOT NULL') 
      .andWhere('case.id IS NOT NULL') 
      .andWhere('caseFile.status =:status', {status : 2})
      .getMany();

      const formattedArray = nonValidatedDocumentOrder.map(item => {
        const createdDate = item.createdDate
          ? moment(new Date(item.createdDate)).format('YYYY-MM-DD')
          : null; 
        return { ...item, createdDate: createdDate };
      });
        const groupedOrders:any = formattedArray.reduce((acc, order) => {
          if (!acc[order.clientId]) {
            acc[order.clientId] = [];
          }
          acc[order.clientId].push(order);
        
          return acc;
        }, {} as Record<number, typeof nonValidatedDocumentOrder>); 
      for (const [clientId, orders] of Object.entries(groupedOrders)) {
        const client = await this.clientService.findOne(Number(clientId))
        let frontUrl = this.configService.get<string>('FRONT_URL');
        const url = `${frontUrl}/client/document-validation`;
        const clientName = client.data['firstName'] + 
        (client.data['middleName'] ? ' ' + client.data['middleName'] : '') + 
        ' ' + client.data['lastName'];
        var mail: IMail = {
          to: client.data['email'],
          subject: `Reminder : validate document for order ... `,
          url: url,
          data: clientName,
          orderdata: orders,
          cc: '',
        };
        await this.mailsService.sendingMail(mail, TemplateTypes.client_validate_document_task_reminder);
      }
    } catch (error) {
      console.error('Error in clientTaskReminder:', error);
    }
  }

}