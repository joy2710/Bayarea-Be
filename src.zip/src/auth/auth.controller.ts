import { Body, Controller,Post, Request, UseGuards } from '@nestjs/common';
import { LocalAuthGuard } from './guards/local-auth.guard';
import { AuthService } from './auth.service';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Public } from './constants';
import { LoginDto } from './dto/login.dto';
import { EmployeeAuthGuard } from './guards/employee-auth.guard';
import { ClientAuthGuard } from './guards/client-auth.guard';
import { ClientDto } from './dto/client.dto';

@Controller('auth')
@ApiTags('Auth')
@ApiBearerAuth()
export class AuthController {
  constructor(private authService: AuthService) {}

  @Public()
  @UseGuards(LocalAuthGuard)
  @Post('login')
  async login(@Body() loginDto: LoginDto, @Request() req) {
    let user;
    if (req.user){
      user = req.user;
    }
    return this.authService.login(user);
  }

  @Public()
  @UseGuards(EmployeeAuthGuard)
  @Post('employee-login')
  async employeeLogin(@Request() req) {
    let employee;
    if (req.user){
      employee = req.user;
    }
    return this.authService.employeeLogin(employee);
  }

  @Public()
  @UseGuards(ClientAuthGuard)
  @Post('client-login')
  async clientLogin(@Body() loginDto: ClientDto, @Request() req) {
    let client;
    if (req.user){
      client = req.user;
      client['ipaddress'] = loginDto.ipaddress
      client['newdate'] = new Date()
    }
    
    return this.authService.clientLogin(client);
  }
}
