import { Strategy } from 'passport-local';
import { PassportStrategy } from '@nestjs/passport';
import { Body, HttpException, HttpStatus, Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthService } from '../auth.service';

@Injectable()
export class ClientStrategy extends PassportStrategy(Strategy,'client-login') {
  constructor(private authService: AuthService,
    
  ) {
    super({
      passReqToCallback: true, 
    });
  }

  async validate(req: Request, email: string, password: string): Promise<any> {
    const data: any = req.body
    const ipaddress = data.ipaddress
    const client = await this.authService.validateClient(email, password);
    if (!client) {
      await this.authService.clientLoginFailed(email, password,ipaddress);
      throw new HttpException({
        status: HttpStatus.UNAUTHORIZED,
        error: 'Invalid credential.',
      }, HttpStatus.UNAUTHORIZED);
    }
    return client;
  }
}
