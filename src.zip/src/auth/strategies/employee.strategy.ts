import { Strategy } from 'passport-local';
import { PassportStrategy } from '@nestjs/passport';
import { HttpException, HttpStatus, Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthService } from '../auth.service';

@Injectable()
export class EmployeeStrategy extends PassportStrategy(Strategy,'employee-login') {
  constructor(private authService: AuthService) {
    super();
  }

  async validate(email: string, password: string): Promise<any> {
    const employee = await this.authService.validateEmployeeUser(email, password);
    if (!employee) {
      throw new HttpException({
        status: HttpStatus.UNAUTHORIZED,
        error: 'Invalid credential.',
      }, HttpStatus.UNAUTHORIZED);
    }
    return employee;
  }
}
