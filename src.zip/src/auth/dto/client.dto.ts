import { ApiProperty } from '@nestjs/swagger';

export class ClientDto {
  @ApiProperty()
  username: string;

  @ApiProperty()
  password: string;

  @ApiProperty()
  ipaddress: string;

}
