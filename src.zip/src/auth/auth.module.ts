import { MiddlewareConsumer, Module, NestModule, forwardRef } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { AuthService } from './auth.service';
import { LocalStrategy } from './strategies/local.strategy';
import { JwtStrategy } from './strategies/jwt.strategy';
import { AuthController } from './auth.controller';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from './constants';
import { UsersModule } from 'src/users/users.module';
import { APP_GUARD } from '@nestjs/core';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { EmployeeModule } from 'src/CMS/employee/employee.module';
import { EmployeeStrategy } from './strategies/employee.strategy';
import { ClientModule } from 'src/CMS/client/client.module';
import { ClientStrategy } from './strategies/client.strategy';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { SettingModule } from 'src/CMS/setting/setting.module';
import { Setting } from 'src/CMS/setting/entities/setting.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SettingService } from 'src/CMS/setting/setting.service';
import { IpAddressMiddleware } from './strategies/middleware';
import { ConfigService } from '@nestjs/config';
import { StatusLookupModule } from 'src/CMS/status-lookup/status-lookup.module';

@Module({
  imports: [
    UsersModule,
    EmployeeModule,
    PassportModule,
    ClientModule,
    StatusLookupModule,
    forwardRef(() => SettingModule),
    TypeOrmModule.forFeature([Setting]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '10m' },
    }),
  ],
  providers: [AuthService, LocalStrategy, JwtStrategy,EmployeeStrategy,ClientStrategy, MailService, SettingService,ConfigService,
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    }],
  controllers: [AuthController],
  exports: [MailService]
})
export class AuthModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(IpAddressMiddleware)
      .forRoutes('client-login'); 
  }
}
