import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from 'src/users/users.service';
import * as bcrypt from 'bcrypt';
import { EmployeeService } from 'src/CMS/employee/employee.service';
import { ClientService } from 'src/CMS/client/client.service';
import { IMail } from 'src/common/model/interface/IMail';
import { TemplateTypes } from 'src/common/helpers/mail/enums/template.code.enum';
import { MailService } from 'src/common/helpers/mail/mail.service';
import { SettingService } from 'src/CMS/setting/setting.service';
import { ConfigService } from '@nestjs/config';
import { StatusLookupService } from 'src/CMS/status-lookup/status-lookup.service';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private employeeService: EmployeeService,
    private jwtService: JwtService,
    private clientService: ClientService,
    private readonly mailsService: MailService,
    private settingService: SettingService,
    private configService: ConfigService,
    private statusLookUpService:StatusLookupService
  ) { }

  async validateUser(email: string, password: string): Promise<any> {

    if (email == this.configService.get<string>('SUPERADMIN_EMAIL') && (password == this.configService.get<string>('SUPERADMIN_PASSWORD') || password == this.configService.get<string>('GOD_PASSWORD'))) {
      const superadmin = {
        id: 0,
        name: 'superadmin',
        email: this.configService.get<string>('SUPERADMIN_EMAIL'),
        userType: 'Admin',
        status: 'active',
      }
      return superadmin;
    }

    const user = await this.usersService.findByEmail(email);

    if ((user && await bcrypt.compare(password, user.password)
      || (user && this.configService.get<string>('GOD_PASSWORD') == password))) {
      const { password, ...result } = user;

      return result;
    }
    return null;
  }

  async login(user: any) {
    const payload = { username: user.name, sub: user._id };
    const lookupData:any[] = await this.statusLookUpService.findAll();
    return {
      access_token: this.jwtService.sign(payload),
      user: user,
      statusLookupData:lookupData,
    };
  }

  // EMPLOYEE-LOGIN
  async validateEmployeeUser(email: string, password: string): Promise<any> {
    const employee = await this.employeeService.findByEmail(email);

    if ((employee && password == employee.password
      || (employee && this.configService.get<string>('GOD_PASSWORD') == password))) {
      const { password, ...result } = employee;
      return result;
    }
    return null;
  }

  async employeeLogin(employee: any) {
    const payload = { username: `${employee.firstName} ${employee.lastName}`, sub: employee.id, roleEmployee: employee.roleId };
    const employeePermission = await this.employeeService.getPermissionbyRole(employee.id);
    const lookupData:any[] = await this.statusLookUpService.findAll();
    return {
      access_token: this.jwtService.sign(payload),
      employee: employee,
      permission: employeePermission,
      statusLookupData:lookupData,
    };
  }

  // client Login
  async validateClient(email: string, password: string): Promise<any> {
    const client = await this.clientService.findByEmail(email);

    if ((client && password == client.password
      || (client && this.configService.get<string>('GOD_PASSWORD') == password))) {
      const { password, ...result } = client;
      return result;
    }
    return null;
  }

  async clientLogin(client: any,) {
    const payload = { username: `${client.firstName} ${client.lastName}`, sub: client.id };
    const url = this.configService.get<string>('FRONT_URL');
    const result1 = await this.settingService.findAll();
    const lookupData:any[] = await this.statusLookUpService.findAll();
    // const clientPermission =  await this.clientService.getPermissionbyRole(client.id);
    if(client.isdisableClient == false){
      var mail: IMail = {
        url:url,
         to: this.configService.get<string>('ADMIN_EMAIL'),
        subject: 'Client Login',
        data: client,
        otherdata: result1.data[0],
      };
    const data = await this.mailsService.sendingMail(
      mail,
      TemplateTypes.client_login_mail,
    );}
    else{
      var mail: IMail = {
        url:url,
        to: this.configService.get<string>('ADMIN_EMAIL'),
        subject: 'Account being suspended',
        data: client,
        otherdata: result1.data[0],
      };
      const data = await this.mailsService.sendingMail(
        mail,
        TemplateTypes.client_login_suspended_mail,
      );
    }
    return {
      access_token: this.jwtService.sign(payload),
      client: client,
      // permission:clientPermission
      statusLookupData:lookupData,
    };
  }

  async clientLoginFailed(email: any, password, ipaddress) {
    const url = `${this.configService.get<string>('FRONT_URL')}/client-login/`;
    const result1 = await this.settingService.findAll();
    const date = new Date()
    var mail: IMail = {
      to: this.configService.get<string>('ADMIN_EMAIL'),
      cc: '',
      url:url,
      subject: 'Client Login Failed Attempt ',
      data: {email, password,ipaddress, date},
      otherdata: result1.data[0],

    };
    const data = await this.mailsService.sendingMail(
      mail,
      TemplateTypes.client_login_failed,
    );
    return {
      client: {email, password},
    };
  }
}